#include "ChimeraJIT.h"
//#define JIT
//void name(const ctx_t* ctx, const ctx_t* const instructions, ChimeraVirtualMachine* const vm)
//extern size_t tos;
size_t tos = 0;
int_c ctx_t::fetchX(ChimeraVirtualMachine* const vm) const
{
    if (mode2 == 0) return x;
    else if (mode2 == 1) return vm->blocks[addr2].data.i;
    else if (mode2 == 2) return vm->blocks[vm->blocks[addr2].data.i].data.i;
    else return (*vm->callStack->peek())[addr2]->data.i;
}

int_c ctx_t::fetchXSecure(ChimeraVirtualMachine* const vm) const
{
    if (mode2 == 0) return x;
    else if (mode2 == 1)
    {
        object_cref block = vm->blocks[addr2];
        if (block.type == Object::INT) return block.data.i;
        else return (int_c) block.data.f;
    }
    else if (mode2 == 2)
    {
        object_cref block = vm->blocks[vm->blocks[addr2].data.i];
        if (block.type == Object::INT) return block.data.i;
        else return (int_c) block.data.f;
    }
    else
    {
        object_cref block = *(*vm->callStack->peek())[addr2];
        if (block.type == Object::INT) return block.data.i;
        else return (int_c) block.data.f;
    }
}

int_c ctx_t::fetchY(ChimeraVirtualMachine* const vm) const
{
    if (mode3 == 0) return y;
    else if (mode3 == 1) return vm->blocks[addr3].data.i;
    else if (mode3 == 2) return vm->blocks[vm->blocks[addr3].data.i].data.i;
    else return (*vm->callStack->peek())[addr3]->data.i;
}

int_c ctx_t::fetchYSecure(ChimeraVirtualMachine* const vm) const
{
    if (mode3 == 0) return y;
    else if (mode3 == 1)
    {
        object_cref block = vm->blocks[addr3];
        if (block.type == Object::INT) return block.data.i;
        else return (int_c) block.data.f;
    }
    else if (mode3 == 2)
    {
        object_cref block = vm->blocks[vm->blocks[addr3].data.i];
        if (block.type == Object::INT) return block.data.i;
        else return (int_c) block.data.f;
    }
    else
    {
        object_cref block = *(*vm->callStack->peek())[addr3];
        if (block.type == Object::INT) return block.data.i;
        else return (int_c) block.data.f;
    }
}

object_ref ctx_t::fetchWriteback(ChimeraVirtualMachine* const vm) const
{
    if (mode1 == 1) return vm->blocks[addr1];
    else if (mode1 == 2) return vm->blocks[vm->blocks[addr1].data.i];
    else return *(*vm->callStack->peek())[addr1];
}

CETFunction(ChimeraJIT::jaddi)
{
    LOG("CET addi");
    object_ref dest = ctx->fetchWriteback(vm);
    dest.readyOverwrite();
    dest.data.i = ctx->fetchXSecure(vm) + ctx->fetchYSecure(vm);
    dest.type = Object::INT;
    const ctx_t* next = &instructions[ctx->next];
    if (next->enabled && tos - (size_t) &next < STACK_SIZE) return next->instr(next, instructions, vm);
    else vm->programCounter = ctx->next;
    return;
}

CETFunction(ChimeraJIT::jmulti)
{
    LOG("CET multi");
    object_ref dest = ctx->fetchWriteback(vm);
    dest.readyOverwrite();
    dest.data.i = ctx->fetchXSecure(vm) * ctx->fetchYSecure(vm);
    dest.type = Object::INT;
    const ctx_t* next = &instructions[ctx->next];
    if (next->enabled && tos - (size_t) &next < STACK_SIZE) return next->instr(next, instructions, vm);
    else vm->programCounter = ctx->next;
    return;
}

CETFunction(ChimeraJIT::jstoreint)
{
    LOG("CET storeint");
    LOG("mode1 " << (int) ctx->mode1);
    LOG("mode2 " << (int) ctx->mode2);
    LOG("addr1 " << ctx->addr1);
    LOG("addr2 " << ctx->addr2);
    object_ref dest = ctx->fetchWriteback(vm);
    dest.readyOverwrite();
    dest.data.i = ctx->fetchXSecure(vm);
    dest.type = Object::INT;
    const ctx_t* next = &instructions[ctx->next];
    if (next->enabled && tos - (size_t) &next < STACK_SIZE) return next->instr(next, instructions, vm);
    else vm->programCounter = ctx->next;
    return;
}

CETFunction(ChimeraJIT::jjump)
{
    LOG("CET jump");
    const ctx_t* next = &instructions[ctx->l1];
    if (next->enabled && tos - (size_t) &next < STACK_SIZE) return next->instr(next, instructions, vm);
    else vm->programCounter = ctx->l1;
    return;
}

CETFunction(ChimeraJIT::jjcmp)
{
    LOG("CET jjcmp");
    // This needs some work
    if (vm->compare)
    {
        const ctx_t* next = &instructions[ctx->l1];
        if (next->enabled && tos - (size_t) &next < STACK_SIZE) return next->instr(next, instructions, vm);
        else vm->programCounter = ctx->l1;
        return;
    }
    else
    {
        const ctx_t* next = &instructions[ctx->next];
        if (next->enabled) return next->instr(next, instructions, vm);
        else vm->programCounter = ctx->next;
        return;
    }
}

CETFunction(ChimeraJIT::jlti)
{
    LOG("CET lti");
    int_c x = ctx->fetchX(vm);
    LOG("x " << x);
    int_c y = ctx->fetchY(vm);
    LOG("y " << y);
    vm->compare = x < y;
    LOG("cmp " << vm->compare);
    const ctx_t* next = &instructions[ctx->next];
    if (next->enabled && tos - (size_t) &next < STACK_SIZE) return next->instr(next, instructions, vm);
    else vm->programCounter = ctx->next;
    return;
}

CETFunction(ChimeraJIT::jinc)
{
    LOG("CET inc");
    LOG("mode1 " << (int) ctx->mode1);
    LOG("addr1 " << ctx->addr1);
    ++ctx->fetchWriteback(vm).data.i;
    const ctx_t* next = &instructions[ctx->next];
    if (next->enabled && tos - (size_t) &next < STACK_SIZE) return next->instr(next, instructions, vm);
    else vm->programCounter = ctx->next;
    return;
}

#undef JIT
#ifdef JIT
extern size_t tos;
#define JIT_COMPI_NC(name, op, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    object_cref b2 = *b(2);\
    CHECK_TYPE(b1, INT);\
    CHECK_TYPE(b2, INT);\
    vm->compare = b1.data.i op b2.data.i;\
    DISPATCH(ctx->next)\
}

#define JIT_COMPI_C1(name, op, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(2);\
    CHECK_TYPE(b1, INT);\
    vm->compare = ctx->x op b1.data.i;\
    DISPATCH(ctx->next)\
}

#define JIT_COMPI_C2(name, op, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    CHECK_TYPE(b1, INT);\
    vm->compare = b1.data.i op ctx->y;\
    DISPATCH(ctx->next)\
}

#define JIT_COMPI_CC(name, op, n)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    vm->compare = ctx->x op ctx->y;\
    DISPATCH(ctx->next)\
}

#define JIT_STORE_NC(name, t, TYPE, v, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    b1.readyOverwrite();\
    b1.type = Object::TYPE;\
    switch(b2.type)\
    {\
    case Object::INT: b1.data.t = b2.data.i; DISPATCH(ctx->next)\
    case Object::FLOAT: b1.data.t = (int_c) b2.data.f; DISPATCH(ctx->next)\
    default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)b2.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
    }\
}

#define JIT_STORE_C2(name, t, TYPE, v, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    b1.readyOverwrite();\
    b1.type = Object::TYPE;\
    b1.data.t = ctx->v;\
    DISPATCH(ctx->next)\
}

#define JIT_INCDEC(name, op, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    op a(1)->data.i;\
    DISPATCH(ctx->next)\
}\

#define JIT_COND_JUMP_NO(name, op, n)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    if (op vm->compare) DISPATCH(ctx->l1)\
    else DISPATCH(ctx->next)\
}

#define JIT_COND_JUMP_WO(name, op, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    CHECK_TYPE(b1, BOOL);\
    vm->compare = b1.data.b;\
    if (op vm->compare) DISPATCH(ctx->l1)\
    else DISPATCH(ctx->next)\
}

#define JIT_VAL_JUMP(name, op, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    CHECK_TYPE(b1, INT);\
    if (b1.data.i op) DISPATCH(ctx->l1)\
    else DISPATCH(ctx->next)\
}

#define JIT_CMP(name, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    b1.readyOverwrite();\
    b1.type = Object::BOOL;\
    b1.data.b = vm->compare;\
    DISPATCH(ctx->next)\
}

#define JIT_LOGIC_C1NO(name, op, n1, n2, n)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    vm->compare = n1 ctx->p op n2 vm->compare;\
    DISPATCH(ctx->next)\
}

#define JIT_LOGIC_NO(name, op, n1, n2, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    CHECK_TYPE(b1, BOOL);\
    vm->compare = n1 b1.data.b op n2 vm->compare;\
    DISPATCH(ctx->next)\
}

#define JIT_LOGIC_NC(name, op, n1, n2, n, a, c)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    object_cref b2 = *c(2);\
    CHECK_TYPE(b1, BOOL);\
    CHECK_TYPE(b2, BOOL);\
    vm->compare = n1 b1.data.b op n2 b2.data.b;\
    DISPATCH(ctx->next)\
}

#define JIT_LOGIC_C1(name, op, n1, n2, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(2);\
    CHECK_TYPE(b1, BOOL);\
    vm->compare = n1 ctx->p op n2 b1.data.b;\
    DISPATCH(ctx->next)\
}

#define JIT_LOGIC_C2(name, op, n1, n2, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    CHECK_TYPE(b1, BOOL);\
    vm->compare = n1 b1.data.b op n2 ctx->q;\
    DISPATCH(ctx->next)\
}

#define JIT_LOGIC_CC(name, op, n1, n2, n)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    vm->compare = ctx->p;\
    DISPATCH(ctx->next)\
}

#define JIT_SWAP(name, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    a(1).swap(b(2));\
    DISPATCH(ctx->next)\
}

#define JIT_PUTARG(name, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    vm->nextFrame->putArgument(a(1));\
    DISPATCH(ctx->next)\
}

#define JIT_PUTMETHOD_NC(name, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    object_cref b2 = *b(2);\
    MethodOrInt moi;\
    moi.i = ctx->l1;\
    b1.data.o->putMethod(*b2.data.s, moi);\
    DISPATCH(ctx->next)\
}

#define JIT_PUTMETHOD_C2(name, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_cref b1 = *a(1);\
    MethodOrInt moi;\
    moi.i = ctx->l1;\
    b1.data.o->putMethod(ctx->s1, moi);\
    DISPATCH(ctx->next)\
}

#define JIT_INVOKE_CNO(name, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    CHECK_TYPE(b1, OBJECT);\
    vm->nextFrame->callingLine = ctx->next;\
    (*vm->nextFrame)[0] << b1;\
    vm->callStack->push();\
    vm->nextFrame = vm->callStack->allocNextPush();\
    object_c obj = b1.data.o;\
    if (ChimeraStandardLibrary::includes(obj))\
    {\
        obj->getMethod(ctx->s2).m(obj, vm->callStack->peek());\
        vm->nextFrame = vm->callStack->pop();\
        vm->nextFrame->reset();\
        DISPATCH(ctx->next)\
    }\
    counter_c method = obj->getMethod(ctx->s2).i;\
    DISPATCH(method)\
}

#define JIT_INVOKE_NO(name, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    CHECK_TYPE(b1, OBJECT);\
    CHECK_TYPE(b2, STRING);\
    vm->nextFrame->callingLine = ctx->next;\
    (*vm->nextFrame)[0] << b1;\
    vm->callStack->push();\
    vm->nextFrame = vm->callStack->allocNextPush();\
    object_c obj = b1.data.o;\
    if (ChimeraStandardLibrary::includes(obj))\
    {\
        obj->getMethod(*b2.data.s).m(obj, vm->callStack->peek());\
        vm->nextFrame = vm->callStack->pop();\
        vm->nextFrame->reset();\
        DISPATCH(ctx->next)\
    }\
    counter_c method = obj->getMethod(*b2.data.s).i;\
    DISPATCH(method)\
}

#define JIT_INVOKE_CA(name, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    CHECK_TYPE(b1, OBJECT);\
    vm->nextFrame->callingLine = ctx->next;\
    (*vm->nextFrame)[0] << b1;\
    vm->nextFrame->returnAddr = ctx->addr3;\
    vm->nextFrame->returnIntoBlock = true;\
    vm->callStack->push();\
    vm->nextFrame = vm->callStack->allocNextPush();\
    object_c obj = b1.data.o;\
    if (ChimeraStandardLibrary::includes(obj))\
    {\
        obj->getMethod(ctx->s2).m(obj, vm->callStack->peek());\
        vm->nextFrame = vm->callStack->pop();\
        vm->nextFrame->reset();\
        DISPATCH(ctx->next)\
    }\
    counter_c method = obj->getMethod(ctx->s2).i;\
    DISPATCH(method)\
}

#define JIT_INVOKE_CB(name, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    CHECK_TYPE(b1, OBJECT);\
    vm->nextFrame->callingLine = ctx->next;\
    (*vm->nextFrame)[0] << b1;\
    vm->nextFrame->returnAddr = block(3)->data.i;\
    vm->nextFrame->returnIntoBlock = true;\
    vm->callStack->push();\
    vm->nextFrame = vm->callStack->allocNextPush();\
    object_c obj = b1.data.o;\
    if (ChimeraStandardLibrary::includes(obj))\
    {\
        obj->getMethod(ctx->s2).m(obj, vm->callStack->peek());\
        vm->nextFrame = vm->callStack->pop();\
        vm->nextFrame->reset();\
        DISPATCH(ctx->next)\
    }\
    counter_c method = obj->getMethod(ctx->s2).i;\
    DISPATCH(method)\
}

#define JIT_INVOKE_NCA(name, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    CHECK_TYPE(b1, OBJECT);\
    CHECK_TYPE(b2, STRING);\
    vm->nextFrame->callingLine = ctx->next;\
    (*vm->nextFrame)[0] << b1;\
    vm->nextFrame->returnAddr = ctx->addr3;\
    vm->nextFrame->returnIntoBlock = true;\
    vm->callStack->push();\
    vm->nextFrame = vm->callStack->allocNextPush();\
    object_c obj = b1.data.o;\
    if (ChimeraStandardLibrary::includes(obj))\
    {\
        obj->getMethod(*b2.data.s).m(obj, vm->callStack->peek());\
        vm->nextFrame = vm->callStack->pop();\
        vm->nextFrame->reset();\
        DISPATCH(ctx->next)\
    }\
    counter_c method = obj->getMethod(*b2.data.s).i;\
    DISPATCH(method)\
}

#define JIT_INVOKE_NCB(name, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    CHECK_TYPE(b1, OBJECT);\
    CHECK_TYPE(b2, STRING);\
    vm->nextFrame->callingLine = ctx->next;\
    (*vm->nextFrame)[0] << b1;\
    vm->nextFrame->returnAddr = block(3)->data.i;\
    vm->nextFrame->returnIntoBlock = true;\
    vm->callStack->push();\
    vm->nextFrame = vm->callStack->allocNextPush();\
    object_c obj = b1.data.o;\
    if (ChimeraStandardLibrary::includes(obj))\
    {\
        obj->getMethod(*b2.data.s).m(obj, vm->callStack->peek());\
        vm->nextFrame = vm->callStack->pop();\
        vm->nextFrame->reset();\
        DISPATCH(ctx->next)\
    }\
    counter_c method = obj->getMethod(*b2.data.s).i;\
    DISPATCH(method)\
}

// CET Factory

// CET Functions
JIT_4(JIT_INCDEC, inc, ++) // Incorporated
JIT_4(JIT_INCDEC, dec, --) // Incorporated
//JIT_4_4(JIT_COMP, eq, ==)
//JIT_4_4(JIT_COMP, lt, <)
//JIT_4_4(JIT_COMP, leq, <=)
//JIT_4_4(JIT_COMP, neq, ==)
JIT_5_5(JIT_COMPI, eqi, ==) // Incorporated
JIT_5_5(JIT_COMPI, lti, <) // Incorporated
JIT_5_5(JIT_COMPI, leqi, <=) // Incorporated
JIT_5_5(JIT_COMPI, neqi, !=) // Incorporated
JIT_4(JIT_CMP, cmp) // Incorporated
//JIT_5O(JIT_NOT, not)
JIT_5_5O(JIT_LOGIC, and, and, , )
JIT_5_5O(JIT_LOGIC, or, or, , )
JIT_5_5O(JIT_LOGIC, eqb, ==, , )
JIT_5_5O(JIT_LOGIC, xor, ^, , )
JIT_5_5O(JIT_LOGIC, implies, or, !, )
JIT_5_5O(JIT_LOGIC, nand, and, !, !)
JIT_5_5O(JIT_LOGIC, nor, or, !, !)
//JIT_4_5_5(JIT_ADDS, adds)
//JIT_4_5_5(JIT_MULTS, mults)
//JIT_5(JIT_ORD, ord)
//JIT_5(JIT_CHAR, char)
JIT_4_5(JIT_STORE, storeint, i, INT, x)
JIT_4_5(JIT_STORE, storefloat, f, FLOAT, f)
//JIT_4_5(JIT_STORE, storestring, s, STRING, s1) // Doesn't work the same way!
JIT_4_5(JIT_STORE, storebool, b, BOOL, p)
//JIT_4_4(JIT_COPY, copy)
JIT_4_4(JIT_SWAP, swap) // Incorporated
//JIT_5(JIT_ALLOC, alloc)
//JIT_5(JIT_DEALLOC, dealloc)

CETFunction(ChimeraJIT::jjump) // Incorporated
{
    LOG("CET jump");
    DISPATCH(ctx->l1)
}

JIT_4O(JIT_COND_JUMP, jcmp, ) // Incorporated
JIT_4O(JIT_COND_JUMP, jnc, !) // Incorporated
JIT_4(JIT_VAL_JUMP, jnqz, != 0) // Incorporated
JIT_4(JIT_VAL_JUMP, jneg, < 0) // Incorporated
//JIT_4(JIT_JMPT, jmpt)

// TODO: call can be split into more, including versions which don't perform stretch
CETFunction(ChimeraJIT::jcall1) // Incorporated
{
    LOG("CET call 1");
    vm->nextFrame->callingLine = ctx->next;
    if (ctx->x > 0) vm->nextFrame->stretch(ctx->x);
    vm->callStack->push();
    vm->nextFrame = vm->callStack->allocNextPush();
    DISPATCH(ctx->l1)
}

CETFunction(ChimeraJIT::jcall2) // Incorporated
{
    LOG("CET call 2");
    vm->nextFrame->callingLine = ctx->next;
    if (ctx->x > 0) vm->nextFrame->stretch(ctx->x);
    vm->nextFrame->returnAddr = ctx->addr1;
    vm->nextFrame->returnIntoBlock = true;
    vm->callStack->push();
    vm->nextFrame = vm->callStack->allocNextPush();
    DISPATCH(ctx->l1)
}

CETFunction(ChimeraJIT::jcall3) // Incorporated
{
    LOG("CET call 3");
    vm->nextFrame->callingLine = ctx->next;
    if (ctx->x > 0) vm->nextFrame->stretch(ctx->x);
    vm->nextFrame->returnAddr = block(1)->data.i;
    vm->nextFrame->returnIntoBlock = true;
    vm->callStack->push();
    vm->nextFrame = vm->callStack->allocNextPush();
    DISPATCH(ctx->l1)
}

CETFunction(ChimeraJIT::jcall4) // Incorporated
{
    LOG("CET call 4");
    vm->nextFrame->callingLine = ctx->next;
    if (ctx->x > 0) vm->nextFrame->stretch(ctx->x);
    vm->nextFrame->returnAddr = ctx->addr1;
    vm->nextFrame->returnIntoBlock = false;
    vm->callStack->push();
    vm->nextFrame = vm->callStack->allocNextPush();
    DISPATCH(ctx->l1)
}

CETFunction(ChimeraJIT::jreturn1) // Incorporated
{
    unused(ctx);
    LOG("CET return 1");
    vm->nextFrame = vm->callStack->pop();
    addr_c returnAddress = vm->nextFrame->returnAddr;
    if (returnAddress != (addr_c) -1) vm->out << "Attempting to collect return value from void function" << endl;
    counter_c returnLine = vm->nextFrame->callingLine;
    vm->nextFrame->reset();
    DISPATCH(returnLine)
}

CETFunction(ChimeraJIT::jreturn2) // Incorporated
{
    LOG("CET return 2");
    vm->nextFrame = vm->callStack->pop();
    addr_c returnAddress = vm->nextFrame->returnAddr;
    if (returnAddress != (addr_c) -1) (vm->nextFrame->returnIntoBlock ? vm->blocks[returnAddress] : (*vm->callStack->peek())[returnAddress]) << block(1);
    counter_c returnLine = vm->nextFrame->callingLine;
    vm->nextFrame->reset();
    DISPATCH(returnLine)
}

CETFunction(ChimeraJIT::jreturn3) // Incorporated
{
    LOG("CET return 3");
    vm->nextFrame = vm->callStack->pop();
    addr_c returnAddress = vm->nextFrame->returnAddr;
    if (returnAddress != (addr_c) -1) (vm->nextFrame->returnIntoBlock ? vm->blocks[returnAddress] : (*vm->callStack->peek())[returnAddress]) << pointer(1);
    counter_c returnLine = vm->nextFrame->callingLine;
    vm->nextFrame->reset();
    DISPATCH(returnLine)
}

CETFunction(ChimeraJIT::jreturn4) // Incorporated
{
    LOG("CET return 4");
    vm->nextFrame = vm->callStack->pop();
    addr_c returnAddress = vm->nextFrame->returnAddr;
    if (returnAddress != (addr_c) -1) (vm->nextFrame->returnIntoBlock ? vm->blocks[returnAddress] : (*vm->callStack->peek())[returnAddress]) << vm->nextFrame->arguments[ctx->addr1];
    counter_c returnLine = vm->nextFrame->callingLine;
    vm->nextFrame->reset();
    DISPATCH(returnLine)
}

JIT_4(JIT_PUTARG, putarg) // Incorporated
//JIT_2_4_4O(JIT_PACK, pack)
//JIT_4_4O(JIT_UNPACK, unpack)
//JIT_5(JIT_UPSCOPE, upscope)
//JIT_5(JIT_DOWNSCOPE, downscope)
CETFunction(ChimeraJIT::jstretch) // Incorporated
{
    LOG("CET stretch");
    vm->callStack->peek()->stretch(ctx->x);
    DISPATCH(ctx->next)
}
//JIT_4_5O(JIT_NEW, new) // To change soon?
//JIT_4_5_4(JIT_PUTATTR, putattr)
//JIT_4_5_4(JIT_PULLATTR, pullattr)
JIT_4_5(JIT_PUTMETHOD, putmethod)
//JIT_4_5_2O(JIT_INVOKE, invoke) // Incorporated
//JIT_4O(JIT_PRINT, print)

// SI Functions

#endif
