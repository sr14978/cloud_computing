#ifndef CHIMERAJIT_HEADER
#define CHIMERAJIT_HEADER
#include "ChimeraStandardLibrary.h"

// Consider allowing modification of ctx, so that we can perform easy strength reductions
// Only if it doesn't slow everything down though
#define CETFunction(name) void name(const ctx_t* ctx, const ctx_t* const instructions, ChimeraVirtualMachine* const vm)
/*
#ifdef JIT
#define PUT_CTX(x, y) ctx.x = y
#define SET_INSTR(f) ctx.instr = ChimeraJIT::f; ctx.enabled = true
//#define JIT_ENABLE() ctx.enabled = true
#else
*/
#define PUT_CTX(x, y)
//#define PUT_CTX(x, y) ctx.x = y
#define SET_INSTR(f)
//#endif // JIT

struct ctx_t;
class ChimeraJIT;
typedef void JITInstruction(const ctx_t* ctx, const ctx_t* const instructions, ChimeraVirtualMachine* const vm);

struct ctx_t
{
    bool enabled = 0;
    uint_fast8_t mode1, mode2, mode3;
    addr_c addr1, addr2, addr3;
    int_c x, y;
    float_c f, g;
    bool p, q;
    counter_c next, l1, l2, l3, l4, l5;
    string s1, s2, s3; // These are local names but also the string variables
    JITInstruction* instr;

    int_c fetchX(ChimeraVirtualMachine* const vm) const;
    int_c fetchXSecure(ChimeraVirtualMachine* const vm) const;
    int_c fetchY(ChimeraVirtualMachine* const vm) const;
    int_c fetchYSecure(ChimeraVirtualMachine* const vm) const;
    object_ref fetchWriteback(ChimeraVirtualMachine* const vm) const;
};

/* A word on JIT

The Chimera JIT scheme involves compiling sections of a Chimera Byte-Code file down into
C++ functions (a.k.a. JITInstruction). The hope is that performing this operation we can
provide a general speed-up of a program. There are three stages of JIT compilation

Stage 1 - Cached Execution Threads (CETs)
As a program runs, the virtual machine should automatically convert the Chimera Bytecode
into Cached Execution Instructions. These rely on an instruction context and an operation
to perform. Crucially once you execute a CE Instruction you enter the CET. That is to say
execution does not leave the JIT's control until an unconverted instruction is encountered.

Thanks to threaded execution implemented by tail call recursion, this JIT is both very fast
and very portable. Benchmarks suggest it could be twice as fast as regular Chimera.

Stage 2 - SuperInstructions (SIs)
Despite making use of threaded execution we still have a problem; branch prediction is
still less than ideal. To combat this we can use compound many common idiomatic instruction
sequences together into a single superinstruction. Once this is done the JIT-engine must
search through the code and find these sequences, then replace them in the execution contexts.

The advantage to this is a clear one, less context switches are performed and less branching.

Stage 3 - Native Structural Transforms (NSTs)
This one is a little less convincing. If we can manually stop a CET from running, then
we can use that chance to perform a small amount of native code that should run very
fast. Think while loops. However, whether stopping and restarting CETs will overcome the
benefits to the branch prediction is another story!
*/

class ChimeraJIT
{
    friend class ChimeraVirtualMachine;

private:
    ctx_t* instructions;

public:

    ChimeraJIT(counter_c programSize)
    {
        instructions = new ctx_t[programSize+1];
    }

    ~ChimeraJIT()
    {
        delete [] instructions;
    }

    static CETFunction(jjump);
    static CETFunction(jaddi);
    static CETFunction(jstoreint);
    static CETFunction(jmulti);
    static CETFunction(jinc);
    static CETFunction(jlti);
    static CETFunction(jjcmp);
    /*
#ifdef JIT

    // CET Makers
    #define SET_ARITHI(instr, i)\
    switch(instr)\
    {\
    case Instruction::ADDI: SET_INSTR(jaddi##i); break;\
    case Instruction::SUBI: SET_INSTR(jsubi##i); break;\
    case Instruction::MULTI: SET_INSTR(jmulti##i); break;\
    case Instruction::DIVI: SET_INSTR(jdivi##i); break;\
    default: break;\
    }

    #define SET_COMPI(instr, i)\
    switch(instr)\
    {\
    case Instruction::LTI: SET_INSTR(jlti##i); break;\
    case Instruction::LEQI: SET_INSTR(jleqi##i); break;\
    case Instruction::EQI: SET_INSTR(jeqi##i); break;\
    case Instruction::NEQI: SET_INSTR(jneqi##i); break;\
    default: break;\
    }

    // CET Functions
    // Macros
    #define DECLARE_3(f)\
    static CETFunction(f##1);\
    static CETFunction(f##2);\
    static CETFunction(f##3)
    #define DECLARE_4(f)\
    DECLARE_3(f);\
    static CETFunction(f##4)
    #define DECLARE_5(f)\
    DECLARE_4(f);\
    static CETFunction(f##5)
    #define DECLARE_6(f)\
    DECLARE_5(f);\
    static CETFunction(f##6)
    #define DECLARE_16(f)\
    DECLARE_6(f);\
    static CETFunction(f##7);\
    static CETFunction(f##8);\
    static CETFunction(f##9);\
    static CETFunction(f##10);\
    static CETFunction(f##11);\
    static CETFunction(f##12);\
    static CETFunction(f##13);\
    static CETFunction(f##14);\
    static CETFunction(f##15);\
    static CETFunction(f##16)
    #define DECLARE_20(f)\
    DECLARE_16(f);\
    static CETFunction(f##17);\
    static CETFunction(f##18);\
    static CETFunction(f##19);\
    static CETFunction(f##20)
    #define DECLARE_24(f)\
    DECLARE_20(f);\
    static CETFunction(f##21);\
    static CETFunction(f##22);\
    static CETFunction(f##23);\
    static CETFunction(f##24)
    #define DECLARE_25(f)\
    DECLARE_24(f);\
    static CETFunction(f##25)
    #define DECLARE_30(f)\
    DECLARE_25(f);\
    static CETFunction(f##26);\
    static CETFunction(f##27);\
    static CETFunction(f##28);\
    static CETFunction(f##29);\
    static CETFunction(f##30)
    #define DECLARE_40(f)\
    DECLARE_30(f);\
    static CETFunction(f##31);\
    static CETFunction(f##32);\
    static CETFunction(f##33);\
    static CETFunction(f##34);\
    static CETFunction(f##35);\
    static CETFunction(f##36);\
    static CETFunction(f##37);\
    static CETFunction(f##38);\
    static CETFunction(f##39);\
    static CETFunction(f##40)
    #define DECLARE_60(f)\
    DECLARE_40(f);\
    static CETFunction(f##41);\
    static CETFunction(f##42);\
    static CETFunction(f##43);\
    static CETFunction(f##44);\
    static CETFunction(f##45);\
    static CETFunction(f##46);\
    static CETFunction(f##47);\
    static CETFunction(f##48);\
    static CETFunction(f##49);\
    static CETFunction(f##50);\
    static CETFunction(f##51);\
    static CETFunction(f##52);\
    static CETFunction(f##53);\
    static CETFunction(f##54);\
    static CETFunction(f##55);\
    static CETFunction(f##56);\
    static CETFunction(f##57);\
    static CETFunction(f##58);\
    static CETFunction(f##59);\
    static CETFunction(f##60)
    #define DECLARE_64(f)\
    DECLARE_60(f);\
    static CETFunction(f##61);\
    static CETFunction(f##62);\
    static CETFunction(f##63);\
    static CETFunction(f##64)
    #define DECLARE_80(f)\
    DECLARE_64(f);\
    static CETFunction(f##65);\
    static CETFunction(f##66);\
    static CETFunction(f##67);\
    static CETFunction(f##68);\
    static CETFunction(f##69);\
    static CETFunction(f##70);\
    static CETFunction(f##71);\
    static CETFunction(f##72);\
    static CETFunction(f##73);\
    static CETFunction(f##74);\
    static CETFunction(f##75);\
    static CETFunction(f##76);\
    static CETFunction(f##77);\
    static CETFunction(f##78);\
    static CETFunction(f##79);\
    static CETFunction(f##80)
    #define DECLARE_100(f)\
    DECLARE_80(f);\
    static CETFunction(f##81);\
    static CETFunction(f##82);\
    static CETFunction(f##83);\
    static CETFunction(f##84);\
    static CETFunction(f##85);\
    static CETFunction(f##86);\
    static CETFunction(f##87);\
    static CETFunction(f##88);\
    static CETFunction(f##89);\
    static CETFunction(f##90);\
    static CETFunction(f##91);\
    static CETFunction(f##92);\
    static CETFunction(f##93);\
    static CETFunction(f##94);\
    static CETFunction(f##95);\
    static CETFunction(f##96);\
    static CETFunction(f##97);\
    static CETFunction(f##98);\
    static CETFunction(f##99);\
    static CETFunction(f##100)

    // Declarations
    DECLARE_64(jadd);
    DECLARE_64(jsub);
    DECLARE_64(jmult);
    DECLARE_64(jdiv);
    DECLARE_100(jaddi);
    DECLARE_100(jsubi);
    DECLARE_100(jmulti);
    DECLARE_100(jdivi);
    DECLARE_4(jinc);
    DECLARE_4(jdec);
    DECLARE_100(jaddf);
    DECLARE_100(jsubf);
    DECLARE_100(jmultf);
    DECLARE_100(jdivf);
    DECLARE_16(jeq);
    DECLARE_16(jlt);
    DECLARE_16(jleq);
    DECLARE_16(jneq);
    DECLARE_25(jeqi);
    DECLARE_25(jlti);
    DECLARE_25(jleqi);
    DECLARE_25(jneqi);
    DECLARE_4(jcmp);
    DECLARE_6(jnot);
    DECLARE_30(jand);
    DECLARE_30(jor);
    DECLARE_30(jeqb);
    DECLARE_30(jxor);
    DECLARE_30(jimplies);
    DECLARE_30(jnand);
    DECLARE_30(jnor);
    DECLARE_100(jadds);
    DECLARE_100(jmults);
    DECLARE_5(jord);
    DECLARE_5(jchar);
    DECLARE_20(jstoreint);
    DECLARE_20(jstorefloat);
    DECLARE_20(jstorestring);
    DECLARE_20(jstorebool);
    DECLARE_16(jcopy);
    DECLARE_16(jswap);
    DECLARE_5(jalloc);
    DECLARE_5(jdealloc);
    static CETFunction(jjump);
    DECLARE_5(jjcmp);
    DECLARE_5(jjnc);
    DECLARE_4(jjnqz);
    DECLARE_4(jjneg);
    DECLARE_4(jjmpt);
    DECLARE_4(jcall);
    DECLARE_4(jreturn);
    DECLARE_4(jputarg);
    DECLARE_40(jpack);
    DECLARE_20(junpack);
    DECLARE_5(jupscope);
    DECLARE_5(jdownscope);
    static CETFunction(jstretch);
    DECLARE_25(jnew);
    DECLARE_80(jputattr);
    DECLARE_80(jpullattr);
    DECLARE_20(jputmethod);
    DECLARE_60(jinvoke);
    DECLARE_5(jprint);

    // SI Functions
#else*/
    #define SET_ARITHI(instr, i)
    #define SET_COMPI(instr, i)
/*#endif // JIT
*/
};
/*
#ifdef JIT
// Macros
#define block(j)   vm->blocks[ctx->addr##j]
#define pointer(j) vm->blocks[block(j)->data.i]
#define arg(j)     (*vm->callStack->peek())[ctx->addr##j]
#define isPowerOfTwo(x) (x != 0 && x & (~x + 1) == x)
#ifdef JIT_SAFE_STACK
#ifdef DEBUG
#define DIAGNOSE_STACK else if (tos - (size_t) &next >= STACK_SIZE) { vm->programCounter = pc; LOG("Falling back due to suspected stack overflow"); }
#else
#define DIAGNOSE_STACK
#endif //DEBUG
#define DISPATCH(pc)\
{\
    const ctx_t* next = &instructions[pc];\
    if (next->enabled && tos - (size_t) &next < STACK_SIZE) next->instr(next, instructions, vm);\
    DIAGNOSE_STACK\
    else vm->programCounter = pc;\
    return;\
}
#else
#define DISPATCH(pc)\
{\
    const ctx_t* next = &instructions[pc];\
    if (next->enabled) next->instr(next, instructions, vm);\
    else vm->programCounter = pc;\
    return;\
}
#endif //JIT_SAFE_STACK

#define JIT_4(instr, ...)\
instr(__VA_ARGS__, 1, block)\
instr(__VA_ARGS__, 2, pointer)\
instr(__VA_ARGS__, 3, arg)

#define JIT_4O(instr, ...)\
instr ## _NO(__VA_ARGS__, 1)\
instr ## _WO(__VA_ARGS__, 2, block)\
instr ## _WO(__VA_ARGS__, 3, pointer)\
instr ## _WO(__VA_ARGS__, 4, arg)

#define JIT_5(instr, ...)\
instr ## _C1(__VA_ARGS__, 1)\
instr ## _NC(__VA_ARGS__, 2, block)\
instr ## _NC(__VA_ARGS__, 3, pointer)\
instr ## _NC(__VA_ARGS__, 4, arg)

#define JIT_5O(instr, ...)\
instr ## _NO(__VA_ARGS__, 1)\
instr ## _C1(__VA_ARGS__, 2)\
instr ## _NC(__VA_ARGS__, 3, block)\
instr ## _NC(__VA_ARGS__, 4, pointer)\
instr ## _NC(__VA_ARGS__, 5, arg)

#define JIT_4_4(instr, ...)\
instr(__VA_ARGS__, 1, block, block)\
instr(__VA_ARGS__, 2, block, pointer)\
instr(__VA_ARGS__, 3, block, arg)\
instr(__VA_ARGS__, 5, pointer, block)\
instr(__VA_ARGS__, 6, pointer, pointer)\
instr(__VA_ARGS__, 7, pointer, arg)\
instr(__VA_ARGS__, 9, arg, block)\
instr(__VA_ARGS__, 10, arg, pointer)\
instr(__VA_ARGS__, 11, arg, arg)

#define JIT_4_4O(instr, ...)\
instr ## _NO(__VA_ARGS__, 1, block)\
instr ## _NO(__VA_ARGS__, 2, pointer)\
instr ## _NO(__VA_ARGS__, 3, arg)\
instr ## _WO(__VA_ARGS__, 5, block, block)\
instr ## _WO(__VA_ARGS__, 6, block, pointer)\
instr ## _WO(__VA_ARGS__, 7, block, arg)\
instr ## _WO(__VA_ARGS__, 9, pointer, block)\
instr ## _WO(__VA_ARGS__, 10, pointer, pointer)\
instr ## _WO(__VA_ARGS__, 11, pointer, arg)\
instr ## _WO(__VA_ARGS__, 13, arg, block)\
instr ## _WO(__VA_ARGS__, 14, arg, pointer)\
instr ## _WO(__VA_ARGS__, 16, arg, arg)

#define JIT_4_5(instr, ...)\
instr ## _C2(__VA_ARGS__, 1, block)\
instr ## _C2(__VA_ARGS__, 2, pointer)\
instr ## _C2(__VA_ARGS__, 3, arg)\
instr ## _NC(__VA_ARGS__, 5, block, block)\
instr ## _NC(__VA_ARGS__, 6, block, pointer)\
instr ## _NC(__VA_ARGS__, 7, block, arg)\
instr ## _NC(__VA_ARGS__, 9, pointer, block)\
instr ## _NC(__VA_ARGS__, 10, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 11, pointer, arg)\
instr ## _NC(__VA_ARGS__, 13, arg, block)\
instr ## _NC(__VA_ARGS__, 14, arg, pointer)\
instr ## _NC(__VA_ARGS__, 16, arg, arg)

#define JIT_4_5O(instr, ...)\
instr ## _NO(__VA_ARGS__, 1, block)\
instr ## _NO(__VA_ARGS__, 2, pointer)\
instr ## _NO(__VA_ARGS__, 3, arg)\
instr ## _C2(__VA_ARGS__, 5, block)\
instr ## _C2(__VA_ARGS__, 6, pointer)\
instr ## _C2(__VA_ARGS__, 7, arg)\
instr ## _NC(__VA_ARGS__, 9, block, block)\
instr ## _NC(__VA_ARGS__, 10, block, pointer)\
instr ## _NC(__VA_ARGS__, 11, block, arg)\
instr ## _NC(__VA_ARGS__, 13, pointer, block)\
instr ## _NC(__VA_ARGS__, 14, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 15, pointer, arg)\
instr ## _NC(__VA_ARGS__, 17, arg, block)\
instr ## _NC(__VA_ARGS__, 18, arg, pointer)\
instr ## _NC(__VA_ARGS__, 20, arg, arg)

#define JIT_5_5(instr, ...)\
instr ## _CC(__VA_ARGS__, 1)\
instr ## _C1(__VA_ARGS__, 2, block)\
instr ## _C1(__VA_ARGS__, 3, pointer)\
instr ## _C1(__VA_ARGS__, 4, arg)\
instr ## _C2(__VA_ARGS__, 6, block)\
instr ## _NC(__VA_ARGS__, 7, block, block)\
instr ## _NC(__VA_ARGS__, 8, block, pointer)\
instr ## _NC(__VA_ARGS__, 9, block, arg)\
instr ## _C2(__VA_ARGS__, 11, pointer)\
instr ## _NC(__VA_ARGS__, 12, pointer, block)\
instr ## _NC(__VA_ARGS__, 13, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 14, pointer, arg)\
instr ## _C2(__VA_ARGS__, 16, arg)\
instr ## _NC(__VA_ARGS__, 17, arg, block)\
instr ## _NC(__VA_ARGS__, 18, arg, pointer)\
instr ## _NC(__VA_ARGS__, 19, arg, arg)

#define JIT_5_5O(instr, ...)\
instr ## _C1NO(__VA_ARGS__, 1)\
instr ## _NO(__VA_ARGS__, 2, block)\
instr ## _NO(__VA_ARGS__, 3, pointer)\
instr ## _NO(__VA_ARGS__, 4, arg)\
instr ## _CC(__VA_ARGS__, 6)\
instr ## _C1(__VA_ARGS__, 7, block)\
instr ## _C1(__VA_ARGS__, 8, pointer)\
instr ## _C1(__VA_ARGS__, 9, arg)\
instr ## _C2(__VA_ARGS__, 11, block)\
instr ## _NC(__VA_ARGS__, 12, block, block)\
instr ## _NC(__VA_ARGS__, 13, block, pointer)\
instr ## _NC(__VA_ARGS__, 14, block, arg)\
instr ## _C2(__VA_ARGS__, 16, pointer)\
instr ## _NC(__VA_ARGS__, 17, pointer, block)\
instr ## _NC(__VA_ARGS__, 18, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 19, pointer, arg)\
instr ## _C2(__VA_ARGS__, 21, arg)\
instr ## _NC(__VA_ARGS__, 22, arg, block)\
instr ## _NC(__VA_ARGS__, 23, arg, pointer)\
instr ## _NC(__VA_ARGS__, 24, arg, arg)

#define JIT_2_4_4O(instr, ...)\

#define JIT_4_4_4(instr, ...)\
instr(__VA_ARGS__, 1, block, block, block)\
instr(__VA_ARGS__, 2, block, block, pointer)\
instr(__VA_ARGS__, 3, block, block, arg)\
instr(__VA_ARGS__, 5, block, pointer, block)\
instr(__VA_ARGS__, 6, block, pointer, pointer)\
instr(__VA_ARGS__, 7, block, pointer, arg)\
instr(__VA_ARGS__, 9, block, arg, block)\
instr(__VA_ARGS__, 10, block, arg, pointer)\
instr(__VA_ARGS__, 11, block, arg, arg)\
instr(__VA_ARGS__, 17, pointer, block, block)\
instr(__VA_ARGS__, 18, pointer, block, pointer)\
instr(__VA_ARGS__, 19, pointer, block, arg)\
instr(__VA_ARGS__, 21, pointer, pointer, block)\
instr(__VA_ARGS__, 22, pointer, pointer, pointer)\
instr(__VA_ARGS__, 23, pointer, pointer, arg)\
instr(__VA_ARGS__, 25, pointer, arg, block)\
instr(__VA_ARGS__, 26, pointer, arg, pointer)\
instr(__VA_ARGS__, 27, pointer, arg, arg)\
instr(__VA_ARGS__, 33, arg, block, block)\
instr(__VA_ARGS__, 34, arg, block, pointer)\
instr(__VA_ARGS__, 35, arg, block, arg)\
instr(__VA_ARGS__, 37, arg, pointer, block)\
instr(__VA_ARGS__, 38, arg, pointer, pointer)\
instr(__VA_ARGS__, 39, arg, pointer, arg)\
instr(__VA_ARGS__, 41, arg, arg, block)\
instr(__VA_ARGS__, 42, arg, arg, pointer)\
instr(__VA_ARGS__, 43, arg, arg, arg)

#define JIT_4_5_4(instr, ...)\
instr ## _C(__VA_ARGS__, 1, block, block)\
instr ## _C(__VA_ARGS__, 2, block, pointer)\
instr ## _C(__VA_ARGS__, 3, block, arg)\
instr ## _NC(__VA_ARGS__, 5, block, block, block)\
instr ## _NC(__VA_ARGS__, 6, block, block, pointer)\
instr ## _NC(__VA_ARGS__, 7, block, block, arg)\
instr ## _NC(__VA_ARGS__, 9, block, pointer, block)\
instr ## _NC(__VA_ARGS__, 10, block, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 11, block, pointer, arg)\
instr ## _NC(__VA_ARGS__, 13, block, arg, block)\
instr ## _NC(__VA_ARGS__, 14, block, arg, pointer)\
instr ## _NC(__VA_ARGS__, 15, block, arg, arg)\
instr ## _C(__VA_ARGS__, 21, pointer, block)\
instr ## _C(__VA_ARGS__, 22, pointer, pointer)\
instr ## _C(__VA_ARGS__, 23, pointer, arg)\
instr ## _NC(__VA_ARGS__, 25, pointer, block, block)\
instr ## _NC(__VA_ARGS__, 26, pointer, block, pointer)\
instr ## _NC(__VA_ARGS__, 27, pointer, block, arg)\
instr ## _NC(__VA_ARGS__, 29, pointer, pointer, block)\
instr ## _NC(__VA_ARGS__, 30, pointer, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 31, pointer, pointer, arg)\
instr ## _NC(__VA_ARGS__, 33, pointer, arg, block)\
instr ## _NC(__VA_ARGS__, 34, pointer, arg, pointer)\
instr ## _NC(__VA_ARGS__, 35, pointer, arg, arg)\
instr ## _C(__VA_ARGS__, 41, arg, block)\
instr ## _C(__VA_ARGS__, 42, arg, pointer)\
instr ## _C(__VA_ARGS__, 43, arg, arg)\
instr ## _NC(__VA_ARGS__, 45, arg, block, block)\
instr ## _NC(__VA_ARGS__, 46, arg, block, pointer)\
instr ## _NC(__VA_ARGS__, 47, arg, block, arg)\
instr ## _NC(__VA_ARGS__, 49, arg, pointer, block)\
instr ## _NC(__VA_ARGS__, 50, arg, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 51, arg, pointer, arg)\
instr ## _NC(__VA_ARGS__, 53, arg, arg, block)\
instr ## _NC(__VA_ARGS__, 54, arg, arg, pointer)\
instr ## _NC(__VA_ARGS__, 55, arg, arg, arg)

#define JIT_4_5_4O(instr, ...)\
instr ## _CNO(__VA_ARGS__, 1, block)\
instr ## _NO(__VA_ARGS__, 2, block, block)\
instr ## _NO(__VA_ARGS__, 3, block, pointer)\
instr ## _NO(__VA_ARGS__, 4, block, arg)\
instr ## _CNO(__VA_ARGS__, 6, pointer)\
instr ## _NO(__VA_ARGS__, 7, pointer, block)\
instr ## _NO(__VA_ARGS__, 8, pointer, pointer)\
instr ## _NO(__VA_ARGS__, 9, pointer, arg)\
instr ## _CNO(__VA_ARGS__, 11, arg)\
instr ## _NO(__VA_ARGS__, 12, arg, block)\
instr ## _NO(__VA_ARGS__, 13, arg, pointer)\
instr ## _NO(__VA_ARGS__, 14, arg, arg)\
instr ## _C(__VA_ARGS__, 21, block, block)\
instr ## _C(__VA_ARGS__, 22, block, pointer)\
instr ## _C(__VA_ARGS__, 23, block, arg)\
instr ## _NC(__VA_ARGS__, 25, block, block, block)\
instr ## _NC(__VA_ARGS__, 26, block, block, pointer)\
instr ## _NC(__VA_ARGS__, 27, block, block, arg)\
instr ## _NC(__VA_ARGS__, 29, block, pointer, block)\
instr ## _NC(__VA_ARGS__, 30, block, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 31, block, pointer, arg)\
instr ## _NC(__VA_ARGS__, 33, block, arg, block)\
instr ## _NC(__VA_ARGS__, 34, block, arg, pointer)\
instr ## _NC(__VA_ARGS__, 35, block, arg, arg)\
instr ## _C(__VA_ARGS__, 41, pointer, block)\
instr ## _C(__VA_ARGS__, 42, pointer, pointer)\
instr ## _C(__VA_ARGS__, 43, pointer, arg)\
instr ## _NC(__VA_ARGS__, 45, pointer, block, block)\
instr ## _NC(__VA_ARGS__, 46, pointer, block, pointer)\
instr ## _NC(__VA_ARGS__, 47, pointer, block, arg)\
instr ## _NC(__VA_ARGS__, 49, pointer, pointer, block)\
instr ## _NC(__VA_ARGS__, 50, pointer, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 51, pointer, pointer, arg)\
instr ## _NC(__VA_ARGS__, 53, pointer, arg, block)\
instr ## _NC(__VA_ARGS__, 54, pointer, arg, pointer)\
instr ## _NC(__VA_ARGS__, 55, pointer, arg, arg)\
instr ## _C(__VA_ARGS__, 61, arg, block)\
instr ## _C(__VA_ARGS__, 62, arg, pointer)\
instr ## _C(__VA_ARGS__, 63, arg, arg)\
instr ## _NC(__VA_ARGS__, 65, arg, block, block)\
instr ## _NC(__VA_ARGS__, 66, arg, block, pointer)\
instr ## _NC(__VA_ARGS__, 67, arg, block, arg)\
instr ## _NC(__VA_ARGS__, 69, arg, pointer, block)\
instr ## _NC(__VA_ARGS__, 70, arg, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 71, arg, pointer, arg)\
instr ## _NC(__VA_ARGS__, 73, arg, arg, block)\
instr ## _NC(__VA_ARGS__, 74, arg, arg, pointer)\
instr ## _NC(__VA_ARGS__, 75, arg, arg, arg)

#define JIT_4_5_2O(instr, ...)\
instr ## _CNO(__VA_ARGS__, 1, block)\
instr ## _NO(__VA_ARGS__, 2, block, block)\
instr ## _NO(__VA_ARGS__, 3, block, pointer)\
instr ## _NO(__VA_ARGS__, 4, block, arg)\
instr ## _CNO(__VA_ARGS__, 6, pointer)\
instr ## _NO(__VA_ARGS__, 7, pointer, block)\
instr ## _NO(__VA_ARGS__, 8, pointer, pointer)\
instr ## _NO(__VA_ARGS__, 9, pointer, arg)\
instr ## _CNO(__VA_ARGS__, 11, arg)\
instr ## _NO(__VA_ARGS__, 12, arg, block)\
instr ## _NO(__VA_ARGS__, 13, arg, pointer)\
instr ## _NO(__VA_ARGS__, 14, arg, arg)\
instr ## _CA(__VA_ARGS__, 21, block)\
instr ## _CB(__VA_ARGS__, 22, block)\
instr ## _NCA(__VA_ARGS__, 23, block, block)\
instr ## _NCB(__VA_ARGS__, 24, block, block)\
instr ## _NCA(__VA_ARGS__, 25, block, pointer)\
instr ## _NCB(__VA_ARGS__, 26, block, pointer)\
instr ## _NCA(__VA_ARGS__, 27, block, arg)\
instr ## _NCB(__VA_ARGS__, 28, block, arg)\
instr ## _CA(__VA_ARGS__, 31, pointer)\
instr ## _CB(__VA_ARGS__, 32, pointer)\
instr ## _NCA(__VA_ARGS__, 33, pointer, block)\
instr ## _NCB(__VA_ARGS__, 34, pointer, block)\
instr ## _NCA(__VA_ARGS__, 35, pointer, pointer)\
instr ## _NCB(__VA_ARGS__, 36, pointer, pointer)\
instr ## _NCA(__VA_ARGS__, 37, pointer, arg)\
instr ## _NCB(__VA_ARGS__, 38, pointer, arg)\
instr ## _CA(__VA_ARGS__, 41, arg)\
instr ## _CB(__VA_ARGS__, 42, arg)\
instr ## _NCA(__VA_ARGS__, 43, arg, block)\
instr ## _NCB(__VA_ARGS__, 44, arg, block)\
instr ## _NCA(__VA_ARGS__, 45, arg, pointer)\
instr ## _NCB(__VA_ARGS__, 46, arg, pointer)\
instr ## _NCA(__VA_ARGS__, 47, arg, arg)\
instr ## _NCB(__VA_ARGS__, 48, arg, arg)

#define JIT_4_5_5(instr, ...)\
instr ## _CC(__VA_ARGS__, 1, block)\
instr ## _C1(__VA_ARGS__, 2, block, block)\
instr ## _C1(__VA_ARGS__, 3, block, pointer)\
instr ## _C1(__VA_ARGS__, 4, block, arg)\
instr ## _C2(__VA_ARGS__, 6, block, block)\
instr ## _NC(__VA_ARGS__, 7, block, block, block)\
instr ## _NC(__VA_ARGS__, 8, block, block, pointer)\
instr ## _NC(__VA_ARGS__, 9, block, block, arg)\
instr ## _C2(__VA_ARGS__, 11, block, pointer)\
instr ## _NC(__VA_ARGS__, 12, block, pointer, block)\
instr ## _NC(__VA_ARGS__, 13, block, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 14, block, pointer, arg)\
instr ## _C2(__VA_ARGS__, 16, block, arg)\
instr ## _NC(__VA_ARGS__, 17, block, arg, block)\
instr ## _NC(__VA_ARGS__, 18, block, arg, pointer)\
instr ## _NC(__VA_ARGS__, 19, block, arg, arg)\
instr ## _CC(__VA_ARGS__, 26, pointer)\
instr ## _C1(__VA_ARGS__, 27, pointer, block)\
instr ## _C1(__VA_ARGS__, 28, pointer, pointer)\
instr ## _C1(__VA_ARGS__, 29, pointer, arg)\
instr ## _C2(__VA_ARGS__, 31, pointer, block)\
instr ## _NC(__VA_ARGS__, 32, pointer, block, block)\
instr ## _NC(__VA_ARGS__, 33, pointer, block, pointer)\
instr ## _NC(__VA_ARGS__, 34, pointer, block, arg)\
instr ## _C2(__VA_ARGS__, 36, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 37, pointer, pointer, block)\
instr ## _NC(__VA_ARGS__, 38, pointer, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 39, pointer, pointer, arg)\
instr ## _C2(__VA_ARGS__, 41, pointer, arg)\
instr ## _NC(__VA_ARGS__, 42, pointer, arg, block)\
instr ## _NC(__VA_ARGS__, 43, pointer, arg, pointer)\
instr ## _NC(__VA_ARGS__, 44, pointer, arg, arg)\
instr ## _CC(__VA_ARGS__, 51, arg)\
instr ## _C1(__VA_ARGS__, 52, arg, block)\
instr ## _C1(__VA_ARGS__, 53, arg, pointer)\
instr ## _C1(__VA_ARGS__, 54, arg, arg)\
instr ## _C2(__VA_ARGS__, 56, arg, block)\
instr ## _NC(__VA_ARGS__, 57, arg, block, block)\
instr ## _NC(__VA_ARGS__, 58, arg, block, pointer)\
instr ## _NC(__VA_ARGS__, 59, arg, block, arg)\
instr ## _C2(__VA_ARGS__, 61, arg, pointer)\
instr ## _NC(__VA_ARGS__, 62, arg, pointer, block)\
instr ## _NC(__VA_ARGS__, 63, arg, pointer, pointer)\
instr ## _NC(__VA_ARGS__, 64, arg, pointer, arg)\
instr ## _C2(__VA_ARGS__, 66, arg, arg)\
instr ## _NC(__VA_ARGS__, 67, arg, arg, block)\
instr ## _NC(__VA_ARGS__, 68, arg, arg, pointer)\
instr ## _NC(__VA_ARGS__, 69, arg, arg, arg)
#endif // JIT
*/
#endif // CHIMERAJIT_HEADER
