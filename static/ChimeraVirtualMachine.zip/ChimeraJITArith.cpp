#include "ChimeraJIT.h"
#undef JIT
#ifdef JIT
extern size_t tos;
#define JIT_ARITHI_NC(name, op, n, a, b, c)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    object_cref b3 = *c(3);\
    b1.readyOverwrite();\
    b1.type = Object::INT;\
    switch(b2.type)\
    {\
    case Object::INT:\
        switch(b3.type)\
        {\
        case Object::INT: b1.data.i = b2.data.i op b3.data.i; DISPATCH(ctx->next)\
        case Object::FLOAT: b1.data.i = b2.data.i op (int_c) b3.data.f; DISPATCH(ctx->next)\
        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int) b3.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
        }\
    case Object::FLOAT:\
        switch(b3.type)\
        {\
        case Object::INT: b1.data.i = (int_c) b2.data.f op b3.data.i; DISPATCH(ctx->next)\
        case Object::FLOAT: b1.data.i = (int_c) b2.data.f op (int_c) b3.data.f; DISPATCH(ctx->next)\
        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int) b3.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
        }\
    default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int) b2.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
    }\
}

#define JIT_ARITHI_C1(name, op, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(3);\
    b1.readyOverwrite();\
    b1.type = Object::INT;\
    switch(b2.type)\
    {\
    case Object::INT: b1.data.i = ctx->x op b2.data.i; DISPATCH(ctx->next)\
    case Object::FLOAT: b1.data.i = ctx->x op (int_c) b2.data.f; DISPATCH(ctx->next)\
    default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)b2.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
    }\
}

#define JIT_ARITHI_C2(name, op, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    b1.readyOverwrite();\
    b1.type = Object::INT;\
    switch(b2.type)\
    {\
    case Object::INT: b1.data.i = b2.data.i op ctx->y; DISPATCH(ctx->next)\
    case Object::FLOAT: b1.data.i = (int_c) b2.data.f op ctx->y; DISPATCH(ctx->next)\
    default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)b2.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
    }\
}

// This still does the computation of x # y, which is undesirable
// We can perform further chaining here
#define JIT_ARITHI_CC(name, op, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    b1.readyOverwrite();\
    b1.type = Object::INT;\
    /*ctx->x op##= ctx->y;\
    b1.data.i = ctx->x;\
    ctx->instr = ChimeraJIT::j ## name ## _eval ## n;*/\
    b1.data.i = ctx->x op ctx->y;\
    DISPATCH(ctx->next)\
}/*\
CETFunction(ChimeraJIT::j ## name ## _eval ## n)\
{\
    LOG("CET "#name" "#n" optimised");\
    object_ref b1 = *a(1);\
    b1.readyOverwrite();\
    b1.type = Object::INT;\
    b1.data.i = ctx->x;\
    DISPATCH(ctx->next)\
}*/

#define JIT_ARITHF_NC(name, op, n, a, b, c)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    object_cref b3 = *c(3);\
    b1.readyOverwrite();\
    b1.type = Object::FLOAT;\
    switch(b2.type)\
    {\
    case Object::INT:\
        switch(b3.type)\
        {\
        case Object::INT: b1.data.f = (float_c) b2.data.i op (float_c) b3.data.i; DISPATCH(ctx->next)\
        case Object::FLOAT: b1.data.f = (float_c) b2.data.i op b3.data.f; DISPATCH(ctx->next)\
        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int) b3.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
        }\
    case Object::FLOAT:\
        switch(b3.type)\
        {\
        case Object::INT: b1.data.f = b2.data.f op (float_c) b3.data.i; DISPATCH(ctx->next)\
        case Object::FLOAT: b1.data.f = b2.data.f op b3.data.f; DISPATCH(ctx->next)\
        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int) b3.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
        }\
    default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int) b2.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
    }\
}

#define JIT_ARITHF_C1(name, op, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(3);\
    b1.readyOverwrite();\
    b1.type = Object::FLOAT;\
    switch(b2.type)\
    {\
    case Object::INT: b1.data.f = ctx->f + (float_c) b2.data.i; DISPATCH(ctx->next)\
    case Object::FLOAT: b1.data.f = ctx->f + b2.data.f; DISPATCH(ctx->next)\
    default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)b2.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
    }\
}

#define JIT_ARITHF_C2(name, op, n, a, b)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    object_cref b2 = *b(2);\
    b1.readyOverwrite();\
    b1.type = Object::FLOAT;\
    switch(b2.type)\
    {\
    case Object::INT: b1.data.f = (float_c) b2.data.i + ctx->g; DISPATCH(ctx->next)\
    case Object::FLOAT: b1.data.f = b2.data.f + ctx->g; DISPATCH(ctx->next)\
    default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)b2.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1); DISPATCH(ctx->next)\
    }\
}

#define JIT_ARITHF_CC(name, op, n, a)\
CETFunction(ChimeraJIT::j ## name ## n)\
{\
    LOG("CET "#name" "#n);\
    object_ref b1 = *a(1);\
    b1.readyOverwrite();\
    b1.type = Object::FLOAT;\
    b1.data.f = ctx->f op ctx->g;\
    DISPATCH(ctx->next)\
}

// CET Functions
//JIT_4_4_4(JIT_ARITH, add, +)
//JIT_4_4_4(JIT_ARITH, sub, -)
//JIT_4_4_4(JIT_ARITH, mult, *)
//JIT_4_4_4(JIT_ARITH, div, /)
JIT_4_5_5(JIT_ARITHI, addi, +) // Incorporated
JIT_4_5_5(JIT_ARITHI, subi, -) // Incorporated
JIT_4_5_5(JIT_ARITHI, multi, *) // Incorporated
JIT_4_5_5(JIT_ARITHI, divi, /) // Incorporated
JIT_4_5_5(JIT_ARITHF, addf, +)
JIT_4_5_5(JIT_ARITHF, subf, -)
JIT_4_5_5(JIT_ARITHF, multf, *)
JIT_4_5_5(JIT_ARITHF, divf, /)
#endif
