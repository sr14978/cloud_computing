#include "ChimeraStandardLibrary.h"
#define args currentFrame->arguments
#define RETURN_VOID self->returnVoid(currentFrame); return nullptr

unordered_map<string, STDCLEnum> ChimeraStandardLibrary::standardLibraryClassMap =
{
    {"ChimeraUtils", STDCLEnum::CHIMERA_UTILS},
    {"ScopeObject", STDCLEnum::SCOPE_OBJECT},
    {"StringUtils", STDCLEnum::STRING_UTILS},
    {"TypeUtils", STDCLEnum::TYPE_UTILS},
    {"File", STDCLEnum::FILE},
    {"BitwiseOperatorUtils", STDCLEnum::BITWISE_OPERATOR_UTILS},
    {"List", STDCLEnum::LIST},
    {"Map", STDCLEnum::MAP},
    {"Table", STDCLEnum::TABLE},
    {"KeyedTable", STDCLEnum::KEYED_TABLE},
    {"Stack", STDCLEnum::STACK},
    {"RegexUtils", STDCLEnum::REGEX_UTILS},
    {"Math", STDCLEnum::MATH},
    {"TaskManager", STDCLEnum::TASK_MANAGER}
};

bool ChimeraStandardLibrary::includes(string& tag)
{
    return standardLibraryClassMap.find(tag) != standardLibraryClassMap.end();
}

bool ChimeraStandardLibrary::includes(object_c chimeraObject)
{
    return standardLibraryClassMap.find(chimeraObject->getTag()) != standardLibraryClassMap.end();
}

object_c ChimeraStandardLibrary::getInstance(string& tag, ChimeraVirtualMachine* vm, Frame* const frame)
{
    switch(standardLibraryClassMap[tag])
    {
    case STDCLEnum::CHIMERA_UTILS: return new ChimeraUtils(vm, frame);
    case STDCLEnum::SCOPE_OBJECT: return new ChimeraScopeObject(vm, frame);
    case STDCLEnum::STRING_UTILS: return new ChimeraStringUtils(vm, frame);
    case STDCLEnum::TYPE_UTILS: return new ChimeraTypeUtils(vm, frame);
    case STDCLEnum::FILE: return new ChimeraFile(vm, frame);
    case STDCLEnum::BITWISE_OPERATOR_UTILS: return new ChimeraBitwiseOperatorUtils(vm, frame);
    case STDCLEnum::LIST: return new ChimeraList(vm, frame);
    case STDCLEnum::MAP: return new ChimeraMap(vm, frame);
    case STDCLEnum::TABLE: return new ChimeraTable(vm, frame);
    case STDCLEnum::KEYED_TABLE: return new ChimeraKeyedTable(vm, frame);
    case STDCLEnum::STACK: return new ChimeraStack(vm, frame);
    case STDCLEnum::REGEX_UTILS: return new ChimeraRegexUtils(vm, frame);
    case STDCLEnum::MATH: return new ChimeraMath(vm, frame);
    case STDCLEnum::TASK_MANAGER: return new ChimeraTaskManager(vm, frame);
    default: return nullptr;
    }
}

void IChimeraStandardLibraryObject::putMethod(const string& name, method m)
{
    MethodOrInt moi;
    moi.m = m;
    methods[name] = moi;
}

void IChimeraStandardLibraryObject::putMethod(const string& name, MethodOrInt startLine)
{
    unused(name);
    unused(startLine);
    std::cerr << "Cannot insert methods into a standard library class"; exit(1);
}

object_ref IChimeraStandardLibraryObject::returnRef(const Frame* const frame) const
{
    return frame->returnIntoBlock ? vm->blocks[frame->returnAddr] : *(*vm->callStack->peek())[frame->returnAddr];
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, int_c x) const
{
    if (frame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = this->returnRef(frame);
        returnRef.readyOverwrite();
        returnRef.data.i = x;
        returnRef.type = Object::INT;
        return true;
    }
    return false;
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, bool_c b) const
{
    if (frame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = this->returnRef(frame);
        returnRef.readyOverwrite();
        returnRef.data.b = b;
        returnRef.type = Object::BOOL;
        return true;
    }
    return false;
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, float_c f) const
{
    if (frame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = this->returnRef(frame);
        returnRef.readyOverwrite();
        returnRef.data.f = f;
        returnRef.type = Object::FLOAT;
        return true;
    }
    return false;
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, const char* s) const
{
    return returnSTDCL(frame, new string(s));
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, string& s) const
{
    return returnSTDCL(frame, new string(s));
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, string_c s) const
{
    if (frame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = this->returnRef(frame);
        returnRef.readyOverwrite();
        returnRef.data.s = s;
        returnRef.type = Object::STRING;
        return true;
    }
    else
    {
        // This is pretty bad waste of allocations, we should try and fix this
        delete s;
        return false;
    }
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, object_c o) const
{
    if (frame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = this->returnRef(frame);
        returnRef.readyOverwrite();
        returnRef.data.o = o;
        returnRef.type = Object::OBJECT;
        o->acquire();
        return true;
    }
    return false;
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame, object_ptr obj) const
{
    if (frame->returnAddr != (addr_c) -1)
    {
        returnRef(frame) << *obj;
        return true;
    }
    return false;
}

bool IChimeraStandardLibraryObject::returnSTDCL(const Frame* const frame) const
{
    if (frame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = this->returnRef(frame);
        returnRef.readyOverwrite();
        returnRef.type = Object::NOTYPE;
        return true;
    }
    return false;
}

void IChimeraStandardLibraryObject::returnVoid(const Frame* const frame) const
{
    if (frame->returnAddr != (addr_c) -1) std::cerr << "Attempt to return from void function" << endl;
}

// ChimeraBitwiseOperatorUtils
STDCLMethod(ChimeraBitwiseOperatorUtils::bitwiseOr)
{
    LOG("BitwiseOperatorUtils.bitwise_or called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    self->returnSTDCL(currentFrame, args[1]->data.i | args[2]->data.i);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::bitwiseAnd)
{
    LOG("BitwiseOperatorUtils.bitwise_and called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    self->returnSTDCL(currentFrame, args[1]->data.i & args[2]->data.i);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::bitwiseXor)
{
    LOG("BitwiseOperatorUtils.bitwise_xor called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    self->returnSTDCL(currentFrame, args[1]->data.i ^ args[2]->data.i);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::bitwiseNot)
{
    LOG("BitwiseOperatorUtils.bitwise_not called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    self->returnSTDCL(currentFrame, ~args[1]->data.i);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::bitshiftLeft)
{
    LOG("BitwiseOperatorUtils.bitshift_left called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    self->returnSTDCL(currentFrame, args[1]->data.i << args[2]->data.i);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::bitshiftRight)
{
    LOG("BitwiseOperatorUtils.bitshift_right called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    int_c x = args[1]->data.i;
    int_c y = args[2]->data.i;
    self->returnSTDCL(currentFrame, (int_c) (x < 0 ? ((unsigned) x) >> y | (((1 << y) - 1) << (sizeof(int_c)*8 - y)) : x >> y));
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::bitshiftRightZero)
{
    LOG("BitwiseOperatorUtils.bitshift_right_zero called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    self->returnSTDCL(currentFrame, (int_c) (((unsigned) args[1]->data.i) >> args[2]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::toBinaryString)
{
    LOG("BitwiseOperatorUtils.to_binary_string called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], BOOL);
    bool negative = args[1]->data.i < 0;
    int_c value = negative ? -args[1]->data.i : args[1]->data.i;
    string result = "";
    if (value == 0) result = "0";
    else for(; value != 0; value >>= 1)
    {
        result = ((value & 1) ? "1" : "0") + result;
    }
    if (args[2]->data.b)
    {
        while (result.size() % 8)
        {
            result = "0" + result;
        }
    }
    result = (negative ? "-0b" : "0b") + result;
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::toHexString)
{
    LOG("BitwiseOperatorUtils.to_hex_string called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    bool negative = args[1]->data.i < 0;
    int_c value = negative ? -args[1]->data.i : args[1]->data.i;
    string result = "";
    if (value == 0) result = "0";
    else for(; value != 0; value >>= 4)
    {
        result = (char) ((value & 0x0F) > 9 ? (value & 0x0F) - 10 + 'A' : (value & 0x0F) + '0') + result;
    }
    if (result.size() % 2) result = "0" + result;
    result = (negative ? "-0x" : "0x") + result;
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::fromBinaryString)
{
    LOG("BitwiseOperatorUtils.from_binary_string called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], BOOL);
    int_c result = 0;
    string* input = args[1]->data.s;
    if (args[2]->data.b)
    {
        // UNSIGNED
        // if -: negative number
        bool negative = input->at(0) == '-';
        size_t bitstringStart = input->find_first_of('b');
        if (bitstringStart+1 != string::npos)
        {
            string bitstring = input->substr(bitstringStart+1);
            for (char bit : bitstring)
            {
                result <<= 1;
                result |= bit-'0';
            }
            if (negative) result = -result;
        }
    }
    else
    {
        // SIGNED
        // if -: treat as leading 1
        // if +: treat as leading 0
        // if 1: negative number
        // if 0: positive number
        bool negative = input->at(0) == '-';
        bool positive = input->at(0) == '+';
        size_t bitstringStart = input->find_first_of('b');
        if (bitstringStart+1 != string::npos)
        {
            string bitstring = input->substr(bitstringStart+1);
            if (negative) bitstring = "1" + bitstring;
            else if (positive) bitstring = "0" + bitstring;
            if (bitstring[0] == '1') result = -1;
            for (char bit : bitstring)
            {
                result <<= 1;
                result |= bit-'0';
            }
        }
    }
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}

STDCLMethod(ChimeraBitwiseOperatorUtils::fromHexString)
{
    LOG("BitwiseOperatorUtils.from_hex_string called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], BOOL);
    int_c result = 0;
    string* input = args[1]->data.s;
    if (args[2]->data.b)
    {
        // UNSIGNED
        // if -: negative number
        bool negative = input->at(0) == '-';
        size_t hexstringStart = input->find_first_of('x');
        if (hexstringStart+1 != string::npos)
        {
            string hexstring = input->substr(hexstringStart+1);
            for (char digit : hexstring)
            {
                result <<= 4;
                result |= digit > '9' ? 10 + digit - 'A' : digit - '0';
            }
            if (negative) result = -result;
        }
    }
    else
    {
        // SIGNED
        // if -: treat as leading F
        // if +: treat as leading 0
        // if 1: negative number
        // if 0: positive number
        bool negative = input->at(0) == '-';
        bool positive = input->at(0) == '+';
        size_t hexstringStart = input->find_first_of('x');
        if (hexstringStart+1 != string::npos)
        {
            string hexstring = input->substr(hexstringStart+1);
            if (negative) hexstring = "F" + hexstring;
            else if (positive) hexstring = "0" + hexstring;
            if (hexstring[0] > '7') result = -1;
            for (char digit : hexstring)
            {
                result <<= 4;
                result |= digit > '9' ? 10 + digit - 'A' : digit - '0';
            }
        }
    }
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}

// ChimeraList
STDCLMethod(ChimeraList::add)
{
    LOG("List.add called");
    CHECK_ARGS(currentFrame, 1);
    object_ptr element = make_shared<Object>();
    *element << *args[1];
    //if (element->type == Object::OBJECT) link(element->data.o);
    ((ChimeraList*) self)->list.push_back(element);
    RETURN_VOID;
}

STDCLMethod(ChimeraList::get)
{
    LOG("List.get called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    object_ptr& returnValue = ((ChimeraList*) self)->list.at(args[1]->data.i);
    if (!self->returnSTDCL(currentFrame, returnValue)) return returnValue;
    return nullptr;
}

STDCLMethod(ChimeraList::remove)
{
    LOG("List.remove called");
    CHECK_ARGS(currentFrame, 1);
    ((ChimeraList*) self)->list.erase(((ChimeraList*) self)->list.begin() + (size_t) args[1]->data.i);
    RETURN_VOID;
}

STDCLMethod(ChimeraList::set)
{
    LOG("List.set called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    *((ChimeraList*) self)->list[args[1]->data.i] << *args[2];
    RETURN_VOID;
}

STDCLMethod(ChimeraList::insert)
{
    LOG("List.insert called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    object_ptr element = make_shared<Object>();
    *element << *args[2];
    ((ChimeraList*) self)->list.insert(((ChimeraList*) self)->list.begin() + (size_t) args[1]->data.i, element);
    RETURN_VOID;
}

STDCLMethod(ChimeraList::contains)
{
    LOG("List.contains called");
    CHECK_ARGS(currentFrame, 1);
    bool contains = false;
    for (object_ptr obj : ((ChimeraList*)self)->list)
    {
        if (obj == args[1]) { contains = true; break; }
    }
    self->returnSTDCL(currentFrame, contains);
    return nullptr;
}

STDCLMethod(ChimeraList::size)
{
    LOG("List.size called");
    unused_args();
    self->returnSTDCL(currentFrame, (int_c) ((ChimeraList*) self)->list.size());
    return nullptr;
}

STDCLMethod(ChimeraList::isEmpty)
{
    LOG("List.is_empty called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraList*) self)->list.empty());
    return nullptr;
}

STDCLMethod(ChimeraList::clear)
{
    LOG("List.clear called");
    unused_args();
    ((ChimeraList*) self)->list.clear();
    RETURN_VOID;
}

// ChimeraMap
STDCLMethod(ChimeraMap::put)
{
    LOG("Map.put called");
    CHECK_ARGS(currentFrame, 2);
    object_ptr key = make_shared<Object>();
    *key << *args[1];
    object_ptr value = make_shared<Object>();
    *value << *args[2];
    ((ChimeraMap*) self)->map[key] = value;
    RETURN_VOID;
}

STDCLMethod(ChimeraMap::get)
{
    LOG("Map.get called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, ((ChimeraMap*) self)->map.at(args[1]));
    return nullptr;
}

STDCLMethod(ChimeraMap::remove)
{
    LOG("Map.remove called");
    CHECK_ARGS(currentFrame, 1);
    ((ChimeraMap*) self)->map.erase(args[1]);
    RETURN_VOID;
}

STDCLMethod(ChimeraMap::containsKey)
{
    LOG("Map.contains_key called");
    CHECK_ARGS(currentFrame, 1);
    bool contains = ((ChimeraMap*) self)->map.find(args[1]) != ((ChimeraMap*) self)->map.end();
    self->returnSTDCL(currentFrame, contains);
    return nullptr;
}

STDCLMethod(ChimeraMap::containsValue)
{
    LOG("Map.contains_value called");
    CHECK_ARGS(currentFrame, 1);
    bool contains = false;
    for (auto entry : ((ChimeraMap*)self)->map)
    {
        if (entry.second == args[1]) contains = true;
    }
    self->returnSTDCL(currentFrame, contains);
    return nullptr;
}

STDCLMethod(ChimeraMap::size)
{
    LOG("Map.size called");
    unused_args();
    self->returnSTDCL(currentFrame, (int_c) ((ChimeraMap*) self)->map.size());
    return nullptr;
}

STDCLMethod(ChimeraMap::isEmpty)
{
    LOG("Map.is_empty called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraMap*) self)->map.empty());
    return nullptr;
}

STDCLMethod(ChimeraMap::clear)
{
    LOG("Map.clear called");
    unused_args();
    ((ChimeraMap*) self)->map.clear();
    RETURN_VOID;
}

// ChimeraRegexUtils
STDCLMethod(ChimeraRegexUtils::fullMatch)
{
    LOG("RegexUtils.full_match called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    auto& patternCache = ((ChimeraRegexUtils*) self)->patternCache;
    auto& capturedCache = ((ChimeraRegexUtils*) self)->capturedCache;
    capturedCache.clear();
    if (patternCache.find(*args[2]->data.s) == patternCache.end()) patternCache[*args[2]->data.s] = std::regex(*args[2]->data.s);
    std::regex& pattern = patternCache[*args[2]->data.s];
    std::smatch match;
    bool matches = std::regex_match(*args[1]->data.s, match, pattern);
    if (matches)
    {
        auto& cacheLine = capturedCache[match[0]];
        cacheLine.resize(match.size()-1);
        for (size_t i = 1; i < match.size(); i++) cacheLine[i-1] = match[i];
    }
    self->returnSTDCL(currentFrame, matches);
    return nullptr;
}

STDCLMethod(ChimeraRegexUtils::containsMatch)
{
    LOG("RegexUtils.contains_match called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    auto& patternCache = ((ChimeraRegexUtils*) self)->patternCache;
    if (patternCache.find(*args[2]->data.s) == patternCache.end()) patternCache[*args[2]->data.s] = std::regex(*args[2]->data.s);
    std::regex& pattern = patternCache[*args[2]->data.s];
    self->returnSTDCL(currentFrame, std::regex_search(*args[1]->data.s, pattern));
    return nullptr;
}

STDCLMethod(ChimeraRegexUtils::findMatches)
{
    LOG("RegexUtils.find_matches called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    auto& patternCache = ((ChimeraRegexUtils*) self)->patternCache;
    auto& capturedCache = ((ChimeraRegexUtils*) self)->capturedCache;
    capturedCache.clear();
    if (patternCache.find(*args[2]->data.s) == patternCache.end()) patternCache[*args[2]->data.s] = std::regex(*args[2]->data.s);
    std::regex& pattern = patternCache[*args[2]->data.s];
    std::smatch match;
    ChimeraList* list = new ChimeraList(((ChimeraRegexUtils*) self)->vm, nullptr);
    for (string searchString = *args[1]->data.s; std::regex_search(searchString, match, pattern); searchString = match.suffix().str())
    {
        auto& cacheLine = capturedCache[match[0]];
        cacheLine.resize(match.size()-1);
        for (size_t i = 1; i < match.size(); i++) cacheLine[i-1] = match[i];
        list->list.push_back(Object::make(new string(match[0])));
    }
    self->returnSTDCL(currentFrame, list);
    return nullptr;
}

STDCLMethod(ChimeraRegexUtils::getCaptured)
{
    LOG("RegexUtils.get_captured called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], STRING);
    auto& capturedCache = ((ChimeraRegexUtils*) self)->capturedCache;
    self->returnSTDCL(currentFrame, capturedCache[*args[2]->data.s][args[1]->data.i]);
    return nullptr;
}

STDCLMethod(ChimeraRegexUtils::replace)
{
    LOG("RegexUtils.replace called");
    CHECK_ARGS(currentFrame, 3);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    CHECK_TYPE(*args[3], STRING);
    auto& patternCache = ((ChimeraRegexUtils*) self)->patternCache;
    if (patternCache.find(*args[2]->data.s) == patternCache.end()) patternCache[*args[2]->data.s] = std::regex(*args[2]->data.s);
    std::regex& pattern = patternCache[*args[2]->data.s];
    self->returnSTDCL(currentFrame, new string(std::regex_replace(*args[1]->data.s, pattern, *args[3]->data.s)));
    return nullptr;
}

STDCLMethod(ChimeraRegexUtils::split)
{
    LOG("RegexUtils.split called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    auto& patternCache = ((ChimeraRegexUtils*) self)->patternCache;
    if (patternCache.find(*args[2]->data.s) == patternCache.end()) patternCache[*args[2]->data.s] = std::regex(*args[2]->data.s);
    std::regex& pattern = patternCache[*args[2]->data.s];
    std::smatch match;
    ChimeraList* list = new ChimeraList(((ChimeraRegexUtils*) self)->vm, nullptr);
    string searchString;
    for (searchString = *args[1]->data.s; std::regex_search(searchString, match, pattern); searchString = match.suffix().str())
    {
        list->list.push_back(Object::make(new string(match.prefix().str())));
    }
    list->list.push_back(Object::make(new string(searchString)));
    self->returnSTDCL(currentFrame, list);
    return nullptr;
}

// ChimeraScopeObject
STDCLMethod(ChimeraScopeObject::getLocal)
{
    LOG("ScopeObject.get_local called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    string& name = *args[1]->data.s;
    auto depthMap = ((ChimeraScopeObject*) self)->localTable.find(name);
    if (depthMap == ((ChimeraScopeObject*) self)->localTable.end())
    {
        std::cerr << "MissingVariableException: Attempting to access local variable " << name << " that hasn't been declared in scope" << endl;
        exit(1);
    }
    auto mapping = depthMap->second.rbegin();
    if (mapping->first < ((ChimeraScopeObject*) self)->scopeSearchLimit.back())
    {
        std::cerr << "IllegalVariableException: Attempting to access local variable " << name << " that isn't accessible in scope" << endl;
        exit(1);
    }
    self->returnSTDCL(currentFrame, mapping->second);
    return nullptr;
}

STDCLMethod(ChimeraScopeObject::putLocal)
{
    LOG("ScopeObject.put_local called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    string& name = *args[1]->data.s;
    auto depthMap = ((ChimeraScopeObject*) self)->localTable[name];
    if (depthMap.empty())
    {
        ((ChimeraScopeObject*) self)->localTable[name][((ChimeraScopeObject*) self)->currentDepth] = make_shared<Object>();
        *((ChimeraScopeObject*) self)->localTable[name][((ChimeraScopeObject*) self)->currentDepth] << *args[2];
    }
    else
    {
        uint_fast32_t depth = depthMap.rbegin()->first;
        if (depth >= ((ChimeraScopeObject*) self)->scopeSearchLimit.back()) *((ChimeraScopeObject*) self)->localTable[name][depth] << *args[2];
        else
        {
            ((ChimeraScopeObject*) self)->localTable[name][((ChimeraScopeObject*) self)->currentDepth] = make_shared<Object>();
            *((ChimeraScopeObject*) self)->localTable[name][((ChimeraScopeObject*) self)->currentDepth] << *args[2];
        }
    }
    RETURN_VOID;
}

STDCLMethod(ChimeraScopeObject::upScope)
{
    LOG("ScopeObject.up_scope called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], BOOL);
    ((ChimeraScopeObject*) self)->currentDepth++;
    if (args[1]->data.b) ((ChimeraScopeObject*) self)->scopeSearchLimit.push_back(((ChimeraScopeObject*) self)->scopeSearchLimit.back());
    else ((ChimeraScopeObject*) self)->scopeSearchLimit.push_back(((ChimeraScopeObject*) self)->currentDepth);
    RETURN_VOID;
}

STDCLMethod(ChimeraScopeObject::downScope)
{
    LOG("ScopeObject.down_scope called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    int_c downs = args[1]->data.i;
    while (downs --> 0)
    {
        for (auto mapping = ((ChimeraScopeObject*) self)->localTable.begin(); mapping != ((ChimeraScopeObject*) self)->localTable.end();)
        {
            auto& scopeMap = mapping->second;
            auto scopeMapping = scopeMap.end();
            --scopeMapping;
            if (scopeMapping->first == ((ChimeraScopeObject*) self)->currentDepth) scopeMap.erase(scopeMapping);
            if (scopeMap.size() == 0) ((ChimeraScopeObject*) self)->localTable.erase(mapping++);
            else ++mapping;
        }
        if (((ChimeraScopeObject*) self)->currentDepth-- == 0)
        {
            std::cerr << "DownScopeException: Attempting to go too far down scope" << endl;
            exit(1);
        }
        ((ChimeraScopeObject*) self)->scopeSearchLimit.pop_back();
    }
    RETURN_VOID;
}

STDCLMethod(ChimeraScopeObject::printScopeList)
{
    LOG("ScopeObject.print_scope_list called");
    unused_args();
    auto& out = ((ChimeraScopeObject*) self)->vm->out;
    out << "[\n";
    vector<std::map<string, object_ptr>> rows;
    for (auto& var : ((ChimeraScopeObject*) self)->localTable)
    {
        for (auto& levelObj : var.second)
        {
            if (rows.size() < levelObj.first)
            {
                rows.resize((size_t) levelObj.first+1);
            }
            rows[levelObj.first][var.first] = levelObj.second;
        }
    }
    Frame frame;
    frame.arguments.resize(2);
    frame.nextArgIndex = 2;
    for (std::map<string, object_ptr> level : rows)
    {
        out << "  ";
        bool first = true;
        for (auto& var : level)
        {
            if (first) first = false;
            else out << ", ";
            out << var.first << "=";
            frame.arguments[1] = var.second;
            out << *ChimeraStringUtils::stringify(self, &frame)->data.s;
        }
        out << "\n";
    }
    out << "]\n";
    RETURN_VOID;
}

// ChimeraStack
STDCLMethod(ChimeraStack::push)
{
    LOG("Stack.push called");
    CHECK_ARGS(currentFrame, 1);
    object_ptr element = make_shared<Object>();
    *element << *args[1];
    ((ChimeraStack*) self)->stack.push_back(element);
    RETURN_VOID;
}

STDCLMethod(ChimeraStack::peek)
{
    LOG("Stack.peek called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraStack*) self)->stack.back());
    return nullptr;
}

STDCLMethod(ChimeraStack::pop)
{
    LOG("Stack.pop called");
    unused_args();
    // OPTIMISATION
    // Since pop() consumes the element on the top of the stack, it is safe to perform a shallow copy here
    if (currentFrame->returnAddr != (addr_c) -1)
    {
        if (currentFrame->returnIntoBlock)
        {
            ((ChimeraStack*) self)->vm->blocks[currentFrame->returnAddr] = *((ChimeraStack*) self)->stack.back();
        }
        else (*((ChimeraStack*) self)->vm->callStack->peek())[currentFrame->returnAddr] = ((ChimeraStack*) self)->stack.back();
    }
    ((ChimeraStack*) self)->stack.pop_back();
    return nullptr;
}

STDCLMethod(ChimeraStack::size)
{
    LOG("Stack.size called");
    unused_args();
    self->returnSTDCL(currentFrame, (int_c) ((ChimeraStack*) self)->stack.size());
    return nullptr;
}

STDCLMethod(ChimeraStack::isEmpty)
{
    LOG("Stack.is_empty called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraStack*) self)->stack.empty());
    return nullptr;
}

STDCLMethod(ChimeraStack::clear)
{
    LOG("Stack.clear called");
    unused_args();
    while (not ((ChimeraStack*) self)->stack.empty())
    {
        ((ChimeraStack*) self)->stack.pop_back();
    }
    RETURN_VOID;
}

// ChimeraTable
// Implementation details; for efficiency, empty entries are left as nullptr until they are accessed
// They remain nullptr after access, but the return block is set to NOTYPE
STDCLMethod(ChimeraTable::put)
{
    CHECK_ARGS(currentFrame, 3);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    vector<vector<object_ptr>>& table = ((ChimeraTable*) self)->table;
    const int_c& row = args[1]->data.i;
    const int_c& col = args[2]->data.i;
    if (table.size() <= (unsigned) row)
    {
        table.resize(row+1);
        table[row].resize(col+1, nullptr);
    }
    else if (table[row].size() <= (unsigned) col) table[row].resize(col+1, nullptr);
    if (table[row][col] == nullptr)
    {
        table[row][col] = make_shared<Object>();
    }
    *table[row][col] << *args[3];
    ++(((ChimeraTable*) self)->numEntries);
    RETURN_VOID;
}

STDCLMethod(ChimeraTable::get)
{
    LOG("Table.get called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    const int_c& row = args[1]->data.i;
    const int_c& col = args[2]->data.i;
    object_ptr& returnValue = ((ChimeraTable*) self)->table.at(row).at(col);
    if (currentFrame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = self->returnRef(currentFrame);
        if (returnValue != nullptr) returnRef << *returnValue;
        else
        {
            returnRef.readyOverwrite();
            returnRef.type = Object::NOTYPE;
        }
    }
    return nullptr;
}

STDCLMethod(ChimeraTable::getRow)
{
    LOG("Table.get_row called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], BOOL);
    vector<vector<object_ptr>> table = ((ChimeraTable*) self)->table;
    const int_c& row = args[1]->data.i;
    const bool_c& leaveNull = args[2]->data.b;
    ChimeraList* list = new ChimeraList(((ChimeraTable*) self)->vm, nullptr);
    for (object_ptr& element : table.at(row))
    {
        if (element != nullptr or leaveNull)
        {
            object_ptr newElement = make_shared<Object>();
            if (element != nullptr) *newElement << *element;
            list->list.push_back(newElement);
        }
    }
    self->returnSTDCL(currentFrame, list);
    return nullptr;
}

STDCLMethod(ChimeraTable::getCol)
{
    LOG("Table.get_col called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], BOOL);
    vector<vector<object_ptr>> table = ((ChimeraTable*) self)->table;
    const int_c& col = args[1]->data.i;
    const bool_c& leaveNull = args[2]->data.b;
    ChimeraList* list = new ChimeraList(((ChimeraTable*) self)->vm, nullptr);
    for (vector<object_ptr>& row : table)
    {
        object_ptr& element = row.at(col);
        if (element != nullptr or leaveNull)
        {
            object_ptr newElement = make_shared<Object>();
            if (element != nullptr) *newElement << *element;
            list->list.push_back(newElement);
        }
    }
    self->returnSTDCL(currentFrame, list);
    return nullptr;
}

STDCLMethod(ChimeraTable::remove)
{
    LOG("Table.remove called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    vector<vector<object_ptr>>& table = ((ChimeraTable*) self)->table;
    const int_c& row = args[1]->data.i;
    const int_c& col = args[2]->data.i;
    object_ptr entry = table.at(row).at(col);
    if (entry != nullptr)
    {
        // We shouldn't insert nullptr, that is a waste of an allocation, instead we set the type
        entry->readyOverwrite();
        entry->type = Object::NOTYPE;
        --(((ChimeraTable*) self)->numEntries);
    }
    RETURN_VOID;
}

STDCLMethod(ChimeraTable::removeRow)
{
    LOG("Table.remove_row called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    const int_c& rowNum = args[1]->data.i;
    int_c& numEntries = ((ChimeraTable*) self)->numEntries;
    vector<vector<object_ptr>>& table = ((ChimeraTable*) self)->table;
    vector<object_ptr>& row = table[rowNum];
    for (object_ptr& element : row)
    {
        if (element != nullptr and element->type != Object::NOTYPE)
        {
            --numEntries;
        }
    }
    table.erase(table.begin() + rowNum);
    RETURN_VOID;
}

STDCLMethod(ChimeraTable::removeCol)
{
    LOG("Table.remove_col called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    const int_c& col = args[1]->data.i;
    int_c& numEntries = ((ChimeraTable*) self)->numEntries;
    vector<vector<object_ptr>>& table = ((ChimeraTable*) self)->table;
    for (vector<object_ptr>& row : table)
    {
        const object_ptr& element = row[col];
        if (element != nullptr and element->type != Object::NOTYPE)
        {
            --numEntries;
        }
        row.erase(row.begin() + col);
    }
    RETURN_VOID;
}

STDCLMethod(ChimeraTable::trim)
{
    LOG("Table.trim called");
    unused_args();
    vector<vector<object_ptr>>& table = ((ChimeraTable*) self)->table;
    bool foundNonEmptyRow = false;
#ifdef _MSC_VER
    for (int i = table.size()-1; i >= 0; --i)
    {
        vector<object_ptr>& row = table[i];
        bool foundNonEmptyElement = false;
        for (int j = row.size()-1; j >= 0; --j)
        {
            object_ptr& element = row[j];
            if (not foundNonEmptyElement)
            {
                if (element == nullptr or element->type == Object::NOTYPE)
                {
                    row.erase(row.begin() + j);
                }
                else foundNonEmptyElement = true;
            }
        }
        if (not foundNonEmptyRow)
        {
            if (row.empty()) table.erase(table.begin() + i);
            else foundNonEmptyElement = true;
        }
    }
#else
    for (auto i = table.rbegin(), endi = table.rend(); i != endi; ++i)
    {
        vector<object_ptr>& row = *i;
        bool foundNonEmptyElement = false;
        for (auto j = row.rbegin(), endj = row.rend(); j != endj; ++j)
        {
            object_ptr& element = *j;
            if (not foundNonEmptyElement)
            {
                if (element == nullptr or element->type == Object::NOTYPE)
                {
                    row.erase(std::next(j).base());
                }
                else foundNonEmptyElement = true;
            }
        }
        if (not foundNonEmptyRow)
        {
            if (row.empty()) table.erase(std::next(i).base());
            else foundNonEmptyRow = true;
        }
    }
#endif
    RETURN_VOID;
}

STDCLMethod(ChimeraTable::contains)
{
    LOG("Table.contains called");
    CHECK_ARGS(currentFrame, 1);
    const vector<vector<object_ptr>>& table = ((ChimeraTable*) self)->table;
    bool contains = false;
    for (const vector<object_ptr>& row : table)
    {
        for (const object_ptr& element : row)
        {
            if (element == args[1]) { contains = true; break; }
        }
    }
    self->returnSTDCL(currentFrame, contains);
    return nullptr;
}

STDCLMethod(ChimeraTable::numRows)
{
    LOG("Table.num_rows called");
    unused_args();
    self->returnSTDCL(currentFrame, (int_c) ((ChimeraTable*) self)->table.size());
    return nullptr;
}

STDCLMethod(ChimeraTable::numCols)
{
    LOG("Table.num_cols called");
    unused_args();
    const vector<vector<object_ptr>>& table = ((ChimeraTable*) self)->table;
    int_c maxColSize = 0;
    for (const vector<object_ptr>& row : table)
    {
        maxColSize = row.size() > (unsigned) maxColSize ? row.size() : maxColSize;
    }
    self->returnSTDCL(currentFrame, maxColSize);
    return nullptr;
}

STDCLMethod(ChimeraTable::size)
{
    LOG("Table.size called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraTable*) self)->numEntries);
    return nullptr;
}

STDCLMethod(ChimeraTable::isEmpty)
{
    LOG("Table.is_empty called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraTable*) self)->numEntries == 0);
    return nullptr;
}

STDCLMethod(ChimeraTable::isMatrix)
{
    LOG("Table.is_matrix called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraTable*) self)->isMatrix());
    return nullptr;
}

STDCLMethod(ChimeraTable::transpose)
{
    LOG("Table.transpose called");
    unused_args();
    ChimeraTable* tableSelf = (ChimeraTable*) self;
    if (tableSelf->isMatrix())
    {
        vector<vector<object_ptr>>& table = tableSelf->table;
        const size_t n = table.size();
        if (tableSelf->isSquare())
        {
            // This one can be done more optimally
            for (size_t i = 0; i < n; ++i)
            {
                for (size_t j = i + 1; j < n; ++j)
                {
                    table[i][j].swap(table[j][i]);
                }
            }
        }
        else if (n > 0)
        {
            const size_t m = table[0].size();
            vector<vector<object_ptr>> transposed(m, vector<object_ptr>(n));
            for (size_t i = 0; i < n; ++i)
            {
                for (size_t j = 0; j < m; ++j)
                {
                    std::swap(table[i][j], transposed[j][i]);
                }
            }
            tableSelf->table = transposed;
        }
    }
    RETURN_VOID;
}

STDCLMethod(ChimeraTable::clear)
{
    LOG("Table.clear called");
    unused_args();
    ((ChimeraTable*) self)->table.clear();
    ((ChimeraTable*) self)->numEntries = 0;
    RETURN_VOID;
}

// ChimeraStringUtils
STDCLMethod(ChimeraStringUtils::stringable)
{
    LOG("StringUtils.stringable called");
    CHECK_ARGS(currentFrame, 1);
    bool_c stringable;
    switch(args[1]->type)
    {
    case Object::INT: stringable = true; break;
    case Object::FLOAT: stringable = true; break;
    case Object::BOOL: stringable = true; break;
    case Object::STRING: stringable = true; break;
    case Object::OBJECT:
    {
        object_c object = args[1]->data.o;
        stringable = object->getTag() == "List" or object->getTag() == "Map" or object->getTag() == "Table" or object->getTag() == "KeyedTable";
        break;
    }
    default: stringable = false; break;
    }
    self->returnSTDCL(currentFrame, stringable);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::stringify)
{
    LOG("StringUtils.stringify called");
    CHECK_ARGS(currentFrame, 1);
    std::stringstream str;
    switch(args[1]->type)
    {
    case Object::INT: str << args[1]->data.i; break;
    case Object::FLOAT: str << chimeraFloatRepresentation(args[1]->data.f); break;
    case Object::BOOL: str << args[1]->data.b; break;
    case Object::STRING: str << *args[1]->data.s; break;
    case Object::OBJECT:
    {
        object_c object = args[1]->data.o;
        if (object->getTag() == "List")
        {
            str << "[";
            bool comma = false;
            Frame frame;
            frame.arguments.resize(2);
            frame.nextArgIndex = 2;
            for (object_ptr element : ((ChimeraList*) object)->list)
            {
                if (comma) str << ", ";
                frame[1] = element;
                str << *stringify(self, &frame)->data.s;
                comma = true;
            }
            str << "]";
        }
        else if (object->getTag() == "Map")
        {
            str << "[";
            bool comma = false;
            Frame frame;
            frame.arguments.resize(2);
            frame.nextArgIndex = 2;
            for (std::pair<object_ptr, object_ptr> entry : ((ChimeraMap*) object)->map)
            {
                if (comma) str << ", ";
                frame[1] = entry.first;
                str << *stringify(self, &frame)->data.s;
                str << ":";
                frame[1] = entry.second;
                str << *stringify(self, &frame)->data.s;
                comma = true;
            }
            str << "]";
        }
        else if (object->getTag() == "Table")
        {
            str << "[";
            bool comma1 = false;
            Frame frame;
            frame.arguments.resize(2);
            frame.nextArgIndex = 2;
            vector<vector<object_ptr>>& table = ((ChimeraTable*) object)->table;
            for (vector<object_ptr>& row : table)
            {
                if (comma1) str << ", ";
                comma1 = true;
                str << "[";
                bool comma2 = false;
                for (object_ptr& entry : row)
                {
                    if (comma2) str << ", ";
                    comma2 = true;
                    frame[1] = entry;
                    str << *stringify(self, &frame)->data.s;
                }
                str << "]";
            }
            str << "]";
        }
        //else if (object->getTag() == "KeyedTable")
        //{
        //
        //}
        //else if (object->getTag() == "Stack")
        //{
        //
        //}
        else str << object->getTag() << " object #" << object->getId();
        break;
    }
    default:
        // In future raise an error, when the exception standard is written
        break;
    }
    if (!self->returnSTDCL(currentFrame, new string(str.str()))) return Object::make(new string(str.str()));
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::toInt)
{
    LOG("StringUtils.to_int called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    self->returnSTDCL(currentFrame, (int_c) std::stol(*args[1]->data.s));
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::toFloat)
{
    LOG("StringUtils.to_float called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    self->returnSTDCL(currentFrame, std::stod(*args[1]->data.s));
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::toBoolean)
{
    LOG("StringUtils.to_boolean called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    self->returnSTDCL(currentFrame, *args[1]->data.s == "true" or *args[1]->data.s == "1");
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::format)
{
    LOG("StringUtils.format called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    Frame frame;
    frame.arguments.resize(3);
    frame.nextArgIndex = 3;
    frame.arguments[1] = args[1];
    object_ptr delimeter = make_shared<Object>();
    delimeter->data.s = new string("%s");
    delimeter->type = Object::STRING;
    frame.arguments[2] = delimeter;
    object_ptr splitReturn = split(self, &frame);
    vector<object_ptr> splitString = ((ChimeraList*) splitReturn->data.o)->list;

    std::stringstream str;
    size_t currentIndex = 1;
    frame.nextArgIndex = 2;
    for (size_t i = 0; i < splitString.size()-1; i++)
    {
        str << *splitString[i]->data.s;
        size_t index = splitString[i+1]->data.s->find_first_not_of("0123456789");
        if (index == 0 or splitString[i+1]->data.s->size() == 0)
        {
            frame.arguments[1] = args[1+currentIndex++];
            str << *stringify(self, &frame)->data.s;
        }
        else
        {
            if (index == string::npos) index = splitString[i+1]->data.s->size();
            int nextArg = std::stoi(splitString[i+1]->data.s->substr(0, index));
            frame.arguments[1] = args[nextArg+1];
            str << *stringify(self, &frame)->data.s;
            // Need to slice off the front of the next segment
            string* nextSegment = new string(*splitString[i+1]->data.s, index);
            splitString[i+1]->readyOverwrite();
            splitString[i+1]->data.s = nextSegment;
        }
    }
    str << *splitString[splitString.size()-1]->data.s;
    self->returnSTDCL(currentFrame, new string(str.str()));
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::reverseString)
{
    LOG("StringUtils.reverse_string called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    string_c reversed = new string(*args[1]->data.s);
    std::reverse(reversed->begin(), reversed->end());
    self->returnSTDCL(currentFrame, reversed);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::stringCompare)
{
    LOG("StringUtils.string_compare called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    int compare = 0;
    const string& str1 = *args[1]->data.s;
    const string& str2 = *args[2]->data.s;
    if (str1.size() != str2.size()) compare = str1.size() - str2.size();
    if (not compare)
    {
        for (unsigned int i = 0; i < str1.size(); i++)
        {
            if (str1[i] != str2[i])
            {
                compare = str1[i] - str2[i];
                break;
            }
        }
    }
    self->returnSTDCL(currentFrame, compare);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::lowercase)
{
    LOG("StringUtils.lowercase called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    string_c lowercaseString = new string();
    for (char c : *args[1]->data.s) lowercaseString->push_back(tolower(c));
    self->returnSTDCL(currentFrame, lowercaseString);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::uppercase)
{
    LOG("StringUtils.uppercase called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    string_c uppercaseString = new string();
    for (char c : *args[1]->data.s) uppercaseString->push_back(toupper(c));
    self->returnSTDCL(currentFrame, uppercaseString);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::capitalize)
{
    LOG("StringUtils.capitalize called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    string_c capitalizedString = new string();
    capitalizedString->push_back(toupper((*args[1]->data.s)[0]));
    for (unsigned int i = 1; i < args[1]->data.s->size(); i++)
    {
        capitalizedString->push_back(tolower((*args[1]->data.s)[i]));
    }
    self->returnSTDCL(currentFrame, capitalizedString);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::split)
{
    LOG("StringUtils.split called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    ChimeraList* list = new ChimeraList(((ChimeraStringUtils*) self)->vm, nullptr);
    string str = *args[1]->data.s;
    const string& delimeter = *args[2]->data.s;
    size_t i = 0, j;
    do
    {
        j = str.find(delimeter, i);
        if (i == j)
        {
            object_ptr substring = make_shared<Object>();
            substring->data.s = new string("");
            substring->type = Object::STRING;
            list->list.push_back(substring);
        }
        else
        {
            object_ptr substring = make_shared<Object>();
            substring->data.s = new string(str, i, j == string::npos ? j : j - i);
            substring->type = Object::STRING;
            list->list.push_back(substring);
        }
        i = j + delimeter.size();
        if (i == str.size())
        {
            object_ptr substring = make_shared<Object>();
            substring->data.s = new string("");
            substring->type = Object::STRING;
            list->list.push_back(substring);
            break;
        }
    } while (j != string::npos);
    if (!self->returnSTDCL(currentFrame, list)) return Object::make(list);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::replace)
{
    LOG("StringUtils.replace called");
    CHECK_ARGS(currentFrame, 3);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    CHECK_TYPE(*args[3], STRING);
    string str = *args[1]->data.s;
    const string& replace = *args[2]->data.s;
    const string& with = *args[3]->data.s;
    size_t startPosition = 0;
    while ((startPosition = str.find(replace, startPosition)) != string::npos)
    {
        str.replace(startPosition, replace.length(), with);
        startPosition += with.length();
    }
    self->returnSTDCL(currentFrame, str);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::strip)
{
    LOG("StringUtils.strip called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    const string& str = *args[1]->data.s;
    size_t start = str.find_first_not_of(" \t\r\n");
    size_t end = str.find_last_not_of(" \t\r\n");
    self->returnSTDCL(currentFrame, start == string::npos ? new string() : new string(str, start, end - start + 1));
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::count)
{
    LOG("StringUtils.count called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], STRING);
    const string_c str = args[1]->data.s;
    const string& delimeter =*args[2]->data.s;
    int_c count = -1;
    size_t i = 0, j = 0;
    do
    {
        j = str->find(delimeter, i);
        i = j + delimeter.size();
        ++count;
    } while (j != string::npos);
    self->returnSTDCL(currentFrame, count);
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::length)
{
    LOG("StringUtils.length called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], STRING);
    self->returnSTDCL(currentFrame, (int_c) args[1]->data.s->size());
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::substring)
{
    LOG("StringUtils.substring called");
    CHECK_ARGS(currentFrame, 3);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], INT);
    CHECK_TYPE(*args[3], INT);
    self->returnSTDCL(currentFrame, new string(*args[1]->data.s, args[2]->data.i, args[3]->data.i - args[2]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraStringUtils::get)
{
    LOG("StringUtils.get called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], STRING);
    CHECK_TYPE(*args[2], INT);
    self->returnSTDCL(currentFrame, new string(1, args[1]->data.s->at(args[2]->data.i)));
    return nullptr;
}

// TypeUtils
STDCLMethod(ChimeraTypeUtils::isNull)
{
    LOG("TypeUtils.is_null called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, args[1]->type == Object::NOTYPE);
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::null)
{
    LOG("TypeUtils.null called");
    unused_args();
    self->returnSTDCL(currentFrame);
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::getId)
{
    LOG("TypeUtils.get_id called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], OBJECT);
    self->returnSTDCL(currentFrame, (int_c) args[1]->data.o->getId());
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::hasMethod)
{
    LOG("TypeUtils.has_method called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], OBJECT);
    self->returnSTDCL(currentFrame, args[1]->data.o->hasMethod(*args[2]->data.s));
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::hasAttribute)
{
    LOG("TypeUtils.has_attribute called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], OBJECT);
    self->returnSTDCL(currentFrame, args[1]->data.o->hasAttribute(*args[2]->data.s));
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::getName)
{
    LOG("TypeUtils.get_name called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], OBJECT);
    self->returnSTDCL(currentFrame, args[1]->data.o->getTag());
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::getType)
{
    LOG("TypeUtils.get_type called");
    CHECK_ARGS(currentFrame, 1);
    const char* type;
    switch(args[1]->type)
    {
    case Object::INT: type = "int"; break;
    case Object::FLOAT: type = "float"; break;
    case Object::BOOL: type = "bool"; break;
    case Object::STRING: type = "string"; break;
    case Object::OBJECT: type = "object"; break;
    case Object::NOTYPE: type = "null"; break;
    default: type = "notype"; break;
    }
    self->returnSTDCL(currentFrame, type);
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::isInstance)
{
    LOG("TypeUtils.is_instance called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], OBJECT);
    CHECK_TYPE(*args[2], STRING);
    self->returnSTDCL(currentFrame, args[1]->data.o->getTag() == *args[2]->data.s);
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::toInt)
{
    LOG("TypeUtils.to_int called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], BOOL);
    self->returnSTDCL(currentFrame, args[1]->data.b ? 1 : 0);
    return nullptr;
}

STDCLMethod(ChimeraTypeUtils::toBool)
{
    LOG("TypeUtils.to_bool called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    self->returnSTDCL(currentFrame, args[1]->data.i != 0);
    return nullptr;
}

// ChimeraUtils
STDCLMethod(ChimeraUtils::deepCopy)
{
    LOG("ChimeraUtils.deep_copy called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], OBJECT);
    CHECK_TYPE(*args[2], BOOL);
    object_c object = args[1]->data.o;
    object_c copiedObject;
    if (object->getTag() == "List") copiedObject = ((ChimeraList*) object)->deepCopy(args[2]->data.b);
    else if (object->getTag() == "Map") copiedObject = ((ChimeraMap*) object)->deepCopy(args[2]->data.b);
    else if (object->getTag() == "Table") copiedObject = ((ChimeraTable*) object)->deepCopy(args[2]->data.b);
    else if (object->getTag() == "KeyedTable") copiedObject = ((ChimeraKeyedTable*) object)->deepCopy(args[2]->data.b);
    else copiedObject = object->deepCopy(args[2]->data.b);
    self->returnSTDCL(currentFrame, copiedObject);
    return nullptr;
}

STDCLMethod(ChimeraUtils::randInt)
{
    LOG("ChimeraUtils.rand_int called");
    CHECK_ARGS(currentFrame, 2);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    const int_c& minValue = args[1]->data.i;
    const int_c& maxValue = args[2]->data.i;
    srand(time(self, currentFrame)->data.i);
    self->returnSTDCL(currentFrame, rand() % (maxValue-minValue+1) + minValue);
    return nullptr;
}

STDCLMethod(ChimeraUtils::blockCopy)
{
    LOG("ChimeraUtils.block_copy called");
    CHECK_ARGS(currentFrame, 3);
    CHECK_TYPE(*args[1], INT);
    CHECK_TYPE(*args[2], INT);
    CHECK_TYPE(*args[3], INT);
    const int_c& from = args[1]->data.i;
    const int_c& to = args[2]->data.i;
    const int_c& length = args[3]->data.i;
    for (int i = 0; i < length; i++)
    {
        ((ChimeraUtils*) self)->vm->blocks[to+i] << ((ChimeraUtils*) self)->vm->blocks[from+i];
    }
    RETURN_VOID;
}

STDCLMethod(ChimeraUtils::mabs)
{
    LOG("ChimeraUtils.mabs called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraUtils*) self)->vm->mabs);
    return nullptr;
}

STDCLMethod(ChimeraUtils::mrel)
{
    LOG("ChimeraUtils.mrel called");
    unused_args();
    self->returnSTDCL(currentFrame, ((ChimeraUtils*) self)->vm->mrel);
    return nullptr;
}

STDCLMethod(ChimeraUtils::time)
{
    LOG("ChimeraUtils.time called");
    unused_args();
    using namespace std::chrono;
    std::tm timeinfo = std::tm();
    timeinfo.tm_year = 70;
    timeinfo.tm_mon = 0;
    timeinfo.tm_mday = 1;
    std::time_t epoch = std::mktime(&timeinfo);
    if (!self->returnSTDCL(currentFrame, (int_c) duration_cast<milliseconds>(system_clock::now() - system_clock::from_time_t(epoch)).count()))
    {
        return Object::make((int_c) duration_cast<milliseconds>(system_clock::now() - system_clock::from_time_t(epoch)).count());
    }
    return nullptr;
}

STDCLMethod(ChimeraUtils::read)
{
    LOG("ChimeraUtils.read called");
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);
    const int_c& n = args[1]->data.i;
    char* buffer = new char [n+1];
    std::cin.read(buffer, n);
    buffer[n] = '\0';
    self->returnSTDCL(currentFrame, buffer);
    return nullptr;
}

STDCLMethod(ChimeraUtils::readLine)
{
    LOG("ChimeraUtils.read_line called");
    unused_args();
    string buffer;
    std::getline(std::cin, buffer);
    self->returnSTDCL(currentFrame, buffer);
    return nullptr;
}

STDCLMethod(ChimeraUtils::readInt)
{
    LOG("ChimeraUtils.read_int called");
    unused_args();
    if (currentFrame->returnAddr != (addr_c) -1)
    {
        object_ref returnRef = self->returnRef(currentFrame);
        returnRef.readyOverwrite();
        std::cin >> returnRef.data.i;
        returnRef.type = Object::INT;
    }
    return nullptr;
}

STDCLMethod(ChimeraUtils::flush)
{
    LOG("ChimeraUtils.flush called");
    unused_self();
    unused_args();
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    RETURN_VOID;
}

STDCLMethod(ChimeraUtils::fileExists)
{
    PLOG("ChimeraUtils.file_exists called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, false);
    return nullptr;
}

// ChimeraFile
STDCLMethod(ChimeraFile::close)
{
    PLOG("File.close called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::seek)
{
    PLOG("File.seek called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::tell)
{
    PLOG("File.tell called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, 0);
    return nullptr;
}

STDCLMethod(ChimeraFile::get)
{
    PLOG("File.get called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, 0);
    return nullptr;
}

STDCLMethod(ChimeraFile::put)
{
    PLOG("File.put called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::peek)
{
    PLOG("File.peek called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, 0);
    return nullptr;
}

STDCLMethod(ChimeraFile::deleteFile)
{
    PLOG("File.delete called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::read)
{
    PLOG("File.read called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, "");
    return nullptr;
}

STDCLMethod(ChimeraFile::write)
{
    PLOG("File.write called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::seekEnd)
{
    PLOG("File.seek_end called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::seekBegin)
{
    PLOG("File.seek_begin called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::readInt)
{
    PLOG("File.read_int called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, 0);
    return nullptr;
}

STDCLMethod(ChimeraFile::writeInt)
{
    PLOG("File.write_int called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::readFloat)
{
    PLOG("File.read_float called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, 0.0);
    return nullptr;
}

STDCLMethod(ChimeraFile::writeFloat)
{
    PLOG("File.write_float called");
    unused_self();
    unused_args();
    RETURN_VOID;
}

STDCLMethod(ChimeraFile::getLine)
{
    PLOG("File.get_line called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, "");
    return nullptr;
}

STDCLMethod(ChimeraFile::getContents)
{
    PLOG("File.get_contents called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, "");
    return nullptr;
}

STDCLMethod(ChimeraFile::getPath)
{
    PLOG("File.get_path called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, "");
    return nullptr;
}

STDCLMethod(ChimeraFile::getName)
{
    PLOG("File.get_name called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, "");
    return nullptr;
}

STDCLMethod(ChimeraFile::getExtension)
{
    PLOG("File.get_extension called");
    unused_self();
    unused_args();
    self->returnSTDCL(currentFrame, "");
    return nullptr;
}

// ChimeraMath
STDCLMethod(ChimeraMath::floatCompare)
{
    LOG("Math.float_compare called");
    CHECK_ARGS(currentFrame, 4);
    const float_c& f1 = args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i;
    const float_c& f2 = args[2]->type == Object::FLOAT ? args[2]->data.f : (float_c) args[2]->data.i;
    const float_c& mabs = args[3]->type == Object::FLOAT ? args[3]->data.f : (float_c) args[3]->data.i;
    const float_c& mrel = args[4]->type == Object::FLOAT ? args[4]->data.f : (float_c) args[4]->data.i;
    const float_c diff = f1 - f2;
    const float_c absDiff = fabs(diff);
    int result = 0;
    if (absDiff <= mabs or absDiff <= f1*mrel or absDiff <= f2*mrel)
    {
        result = 0;
    }
    else result = diff < 0 ? -1 : 1;
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}

STDCLMethod(ChimeraMath::pow)
{
    LOG("Math.pow called");
    CHECK_ARGS(currentFrame, 2);
    self->returnSTDCL(currentFrame, std::pow(args[1]->type == Object::FLOAT ?
                                             args[1]->data.f : (float_c) args[1]->data.i,
                                             args[2]->type == Object::FLOAT ?
                                             args[2]->data.f : (float_c) args[2]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::intPow)
{
    LOG("Math.int_pow called");
    CHECK_ARGS(currentFrame, 2);
    int_c result = 1;
    int_c exp = args[2]->type == Object::INT ? args[2]->data.i : (int_c) args[2]->data.f;
    int_c base = args[1]->type == Object::INT ? args[1]->data.i : (int_c) args[1]->data.f;
    while (exp)
    {
        if (exp & 1) result *= base;
        exp >>= 1;
        base *= base;
    }
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}

STDCLMethod(ChimeraMath::sqrt)
{
    LOG("Math.sqrt called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::sqrt(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::log)
{
    LOG("Math.log called");
    CHECK_ARGS(currentFrame, 2);
    self->returnSTDCL(currentFrame, std::log(args[1]->type == Object::FLOAT ?
                                             args[1]->data.f : (float_c) args[1]->data.i)
                                    / std::log(args[2]->type == Object::INT ?
                                               args[2]->data.i : (int_c) args[2]->data.f));
    return nullptr;
}

STDCLMethod(ChimeraMath::sin)
{
    LOG("Math.sin called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::sin(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::cos)
{
    LOG("Math.cos called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::cos(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::tan)
{
    LOG("Math.tan called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::tan(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::asin)
{
    LOG("Math.asin called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::asin(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::acos)
{
    LOG("Math.acos called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::acos(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::atan)
{
    LOG("Math.atan called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::atan(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::sinh)
{
    LOG("Math.sinh called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::sinh(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::cosh)
{
    LOG("Math.cosh called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::cosh(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::tanh)
{
    LOG("Math.tanh called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::tanh(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::asinh)
{
    LOG("Math.asinh called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::asinh(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::acosh)
{
    LOG("Math.acosh called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::acosh(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::atanh)
{
    LOG("Math.atanh called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::atanh(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::cosec)
{
    LOG("Math.cosec called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, 1/std::sin(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::sec)
{
    LOG("Math.sec called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, 1/std::cos(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::cot)
{
    LOG("Math.cot called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, 1/std::tan(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::acosec)
{
    LOG("Math.acosec called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::asin(1/(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i)));
    return nullptr;
}

STDCLMethod(ChimeraMath::asec)
{
    LOG("Math.asec called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::acos(1/(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i)));
    return nullptr;
}

STDCLMethod(ChimeraMath::acot)
{
    LOG("Math.acot called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, std::atan(1/(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i)));
    return nullptr;
}

STDCLMethod(ChimeraMath::round)
{
    LOG("Math.round called");
    CHECK_ARGS(currentFrame, 1);
    const float_c scalar = std::pow(10.0, args[2]->type == Object::INT ? args[2]->data.i : (int_c) args[2]->data.f);
    const float_c result = std::round((args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i) * scalar) / scalar;
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}


STDCLMethod(ChimeraMath::ceil)
{
    LOG("Math.ceil called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, (int_c) std::ceil(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::floor)
{
    LOG("Math.floor called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, (int_c) std::floor(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::truncate)
{
    LOG("Math.truncate called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, (int_c) std::trunc(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::abs)
{
    LOG("Math.abs called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, fabs(args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i));
    return nullptr;
}

STDCLMethod(ChimeraMath::modTruncated)
{
    LOG("Math.mod_truncated called");
    CHECK_ARGS(currentFrame, 2);
    self->returnSTDCL(currentFrame, (args[1]->type == Object::INT ?
                                     args[1]->data.i : (int_c) args[1]->data.f)
                                  % (args[2]->type == Object::INT ?
                                     args[2]->data.i : (int_c) args[2]->data.f));
    return nullptr;
}

STDCLMethod(ChimeraMath::modFloored)
{
    LOG("Math.mod_floored called");
    CHECK_ARGS(currentFrame, 2);
    const int_c& x = args[1]->type == Object::INT ? args[1]->data.i : (int_c) args[1]->data.f;
    const int_c& n = args[2]->type == Object::INT ? args[2]->data.i : (int_c) args[2]->data.f;
    self->returnSTDCL(currentFrame, (int_c) (x-n*std::floor((double)x/(double)n)));
    return nullptr;
}

STDCLMethod(ChimeraMath::factorial)
{
    LOG("Math.factorial called");
    CHECK_ARGS(currentFrame, 1);
    int_c i = args[1]->type == Object::INT ? args[1]->data.i : (int_c) args[1]->data.f;
    if (i<0) { std::cerr << "Factorial of " << i << " is undefined." << endl; exit(1); }
    int_c result = 1;
    for (; i != 1; --i) result *= i;
    self->returnSTDCL(currentFrame, result);
    return nullptr;
}

STDCLMethod(ChimeraMath::radiansToDegrees)
{
    LOG("Math.radians_to_degrees called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, (args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i) * 180 / pi());
    return nullptr;
}

STDCLMethod(ChimeraMath::degreesToRadians)
{
    LOG("Math.degrees_to_radians called");
    CHECK_ARGS(currentFrame, 1);
    self->returnSTDCL(currentFrame, (args[1]->type == Object::FLOAT ? args[1]->data.f : (float_c) args[1]->data.i) * pi() / 180);
    return nullptr;
}

STDCLMethod(ChimeraMath::pi)
{
    LOG("Math.pi called");
    unused_args();
    self->returnSTDCL(currentFrame, pi());
    return nullptr;
}

STDCLMethod(ChimeraMath::e)
{
    LOG("Math.e called");
    unused_args();
    self->returnSTDCL(currentFrame, std::exp(1.0));
    return nullptr;
}

#undef args
#undef RETURN_VOID
