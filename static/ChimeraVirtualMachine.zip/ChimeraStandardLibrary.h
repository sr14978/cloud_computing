#ifndef CHIMERA_STANDARD_LIBRARY_HEADER
#define CHIMERA_STANDARD_LIBRARY_HEADER
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <regex>
#include <stack>
#include "ChimeraVirtualMachine.h"

#define STDCLMethod(name) const object_ptr name(IChimeraStandardLibraryObject* self, Frame* const currentFrame)
#define unused_args() (void) (currentFrame)
#define unused_self() (void) self

enum class STDCLEnum {CHIMERA_UTILS, SCOPE_OBJECT, STRING_UTILS, TYPE_UTILS, FILE, BITWISE_OPERATOR_UTILS, LIST, MAP, TABLE, KEYED_TABLE, STACK, REGEX_UTILS, MATH, TASK_MANAGER};

class ChimeraStandardLibrary
{
public:
    static bool includes(string& tag);
    static bool includes(object_c chimeraObject);
    static object_c getInstance(string& tag, ChimeraVirtualMachine* vm, Frame* const frame);

private:
    static unordered_map<string, STDCLEnum> standardLibraryClassMap;
};

class IChimeraStandardLibraryObject : public ChimeraObject
{
    // All the standard library classes must be friends
    friend class ChimeraUtils;
    friend class ChimeraScopeObject;
    friend class ChimeraStringUtils;
    friend class ChimeraTypeUtils;
    friend class ChimeraFile;
    friend class ChimeraBitwiseOperatorUtils;
    friend class ChimeraList;
    friend class ChimeraMap;
    friend class ChimeraTable;
    friend class ChimeraKeyedTable;
    friend class ChimeraStack;
    friend class ChimeraRegexUtils;
    friend class ChimeraMath;
    friend class ChimeraTaskManager;
protected:
    ChimeraVirtualMachine* vm;

    IChimeraStandardLibraryObject(const string name, ChimeraVirtualMachine* vm) : ChimeraObject(name) { this->vm = vm; }
    virtual ~IChimeraStandardLibraryObject() {}
public:
    void putMethod(const string& name, method m);
    void putMethod(const string& name, MethodOrInt startLine) override final;
    object_ref returnRef(const Frame* const frame) const;
    bool returnSTDCL(const Frame* const frame, int_c x) const;
    bool returnSTDCL(const Frame* const frame, bool_c b) const;
    bool returnSTDCL(const Frame* const frame, float_c f) const;
    bool returnSTDCL(const Frame* const frame, const char* s) const;
    bool returnSTDCL(const Frame* const frame, string& s) const;
    bool returnSTDCL(const Frame* const frame, string_c s) const;
    bool returnSTDCL(const Frame* const frame, object_c o) const;
    bool returnSTDCL(const Frame* const frame, object_ptr obj) const;
    bool returnSTDCL(const Frame* const frame) const;
    void returnVoid(const Frame* const frame) const;
};

class ChimeraBitwiseOperatorUtils : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    ChimeraBitwiseOperatorUtils(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("BitwiseOperatorUtils", vm)
    {
        (void) frame;
        putMethod("bitwise_or", &ChimeraBitwiseOperatorUtils::bitwiseOr);
        putMethod("bitwise_and", &ChimeraBitwiseOperatorUtils::bitwiseAnd);
        putMethod("bitwise_xor", &ChimeraBitwiseOperatorUtils::bitwiseXor);
        putMethod("bitwise_not", &ChimeraBitwiseOperatorUtils::bitwiseNot);
        putMethod("bitshift_left", &ChimeraBitwiseOperatorUtils::bitshiftLeft);
        putMethod("bitshift_right", &ChimeraBitwiseOperatorUtils::bitshiftRight);
        putMethod("bitshift_right_zero", &ChimeraBitwiseOperatorUtils::bitshiftRightZero);
        putMethod("to_binary_string", &ChimeraBitwiseOperatorUtils::toBinaryString);
        putMethod("to_hex_string", &ChimeraBitwiseOperatorUtils::toHexString);
        putMethod("from_binary_string", &ChimeraBitwiseOperatorUtils::fromBinaryString);
        putMethod("from_hex_string", &ChimeraBitwiseOperatorUtils::fromHexString);
    }

    // int BitwiseOperatorUtils.bitwise_or(int x, int y)
    static STDCLMethod(bitwiseOr);
    // int BitwiseOperatorUtils.bitwise_and(int x, int y)
    static STDCLMethod(bitwiseAnd);
    // int BitwiseOperatorUtils.bitwise_xor(int x, int y)
    static STDCLMethod(bitwiseXor);
    // int BitwiseOperatorUtils.bitwise_not(int x)
    static STDCLMethod(bitwiseNot);
    // int BitwiseOperatorUtils.bitshift_left(int x, int y)
    static STDCLMethod(bitshiftLeft);
    // int BitwiseOperatorUtils.bitshift_right(int x, int y)
    static STDCLMethod(bitshiftRight);
    // int BitwiseOperatorUtils.bitshift_right_zero(int x, int y)
    static STDCLMethod(bitshiftRightZero);
    // string BitwiseOperatorUtils.to_binary_string(int x, bool pad_byte)
    static STDCLMethod(toBinaryString);
    // string BitwiseOperatorUtils.to_hex_string(int x)
    static STDCLMethod(toHexString);
    // int BitwiseOperatorUtils.from_binary_string(string x, bool unsigned)
    static STDCLMethod(fromBinaryString);
    // int BitwiseOperatorUtils.from_hex_string(string x, bool unsigned)
    static STDCLMethod(fromHexString);
};

class ChimeraFile : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    string filename;
    bool hasWritten;
    FILE* file;

    ChimeraFile(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("File", vm)
    {
        putMethod("close", &ChimeraFile::close);
        putMethod("seek", &ChimeraFile::seek);
        putMethod("tell", &ChimeraFile::tell);
        putMethod("get", &ChimeraFile::get);
        putMethod("put", &ChimeraFile::put);
        putMethod("peek", &ChimeraFile::peek);
        putMethod("delete", &ChimeraFile::deleteFile);
        putMethod("read", &ChimeraFile::read);
        putMethod("write", &ChimeraFile::write);
        putMethod("seek_end", &ChimeraFile::seekEnd);
        putMethod("seek_begin", &ChimeraFile::seekBegin);
        putMethod("read_int", &ChimeraFile::readInt);
        putMethod("write_int", &ChimeraFile::writeInt);
        putMethod("read_float", &ChimeraFile::readFloat);
        putMethod("write_float", &ChimeraFile::writeFloat);
        putMethod("get_line", &ChimeraFile::getLine);
        putMethod("get_contents", &ChimeraFile::getContents);
        putMethod("get_path", &ChimeraFile::getPath);
        putMethod("get_name", &ChimeraFile::getName);
        putMethod("get_extension", &ChimeraFile::getExtension);

        // File.__const__(string name)
        LOG("File.__const__ called");
        CHECK_ARGS(frame, 1);
        CHECK_TYPE(*frame->arguments[1], STRING);
        cout << *frame->arguments[1]->data.s << endl;
    }

    // void File.close(string path)
    static STDCLMethod(close);
    // void File.seek(int offset)
    static STDCLMethod(seek);
    // int File.tell()
    static STDCLMethod(tell);
    // int File.get()
    static STDCLMethod(get);
    // void File.put(int b)
    static STDCLMethod(put);
    // int File.peek()
    static STDCLMethod(peek);
    // void File.delete()
    static STDCLMethod(deleteFile);
    // string File.read()
    static STDCLMethod(read);
    // void File.write(string s)
    static STDCLMethod(write);
    // void File.seek_end()
    static STDCLMethod(seekEnd);
    // void File.seek_begin(int offset)
    static STDCLMethod(seekBegin);
    // int File.read_int()
    static STDCLMethod(readInt);
    // void File.write_int(int x)
    static STDCLMethod(writeInt);
    // float File.read_float()
    static STDCLMethod(readFloat);
    // void File.write_float(f)
    static STDCLMethod(writeFloat);
    // string File.get_line()
    static STDCLMethod(getLine);
    // string File.get_contents()
    static STDCLMethod(getContents);
    // string File.get_path()
    static STDCLMethod(getPath);
    // string File.get_name()
    static STDCLMethod(getName);
    // stirng File.get_extension()
    static STDCLMethod(getExtension);
};

class ChimeraKeyedTable : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
    friend class ChimeraUtils;
    friend class ChimeraStringUtils;
private:
    ChimeraKeyedTable(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("KeyedTable", vm)
    {
        (void) frame;
    }
};

class ChimeraList : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
    friend class ChimeraUtils;
    friend class ChimeraStringUtils;
    friend class ChimeraRegexUtils;
    friend class ChimeraTable;
private:
    vector<object_ptr> list;

    ChimeraList(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("List", vm)
    {
        (void) frame;
        putMethod("add", &ChimeraList::add);
        putMethod("get", &ChimeraList::get);
        putMethod("remove", &ChimeraList::remove);
        putMethod("set", &ChimeraList::set);
        putMethod("insert", &ChimeraList::insert);
        putMethod("contains", &ChimeraList::contains);
        putMethod("size", &ChimeraList::size);
        putMethod("is_empty", &ChimeraList::isEmpty);
        putMethod("clear", &ChimeraList::clear);
    }

    ~ChimeraList()
    {
        //for (auto& elem : list) if (elem->type == Object::OBJECT) unlink(elem->data.o);
        list.clear();
    }

    // void List.add(any obj)
    static STDCLMethod(add);
    // any List.get(integer index)
    static STDCLMethod(get);
    // void List.remove(integer index)
    static STDCLMethod(remove);
    // void List.set(integer index, any obj)
    static STDCLMethod(set);
    // void List.insert(integer index, any obj)
    static STDCLMethod(insert);
    // boolean List.contains(any obj)
    static STDCLMethod(contains);
    // integer List.size()
    static STDCLMethod(size);
    // boolean List.is_empty()
    static STDCLMethod(isEmpty);
    // void List.clear()
    static STDCLMethod(clear);

    object_c deepCopy(bool recursive) override
    {
        ChimeraList* copiedObject = new ChimeraList(vm, nullptr);
        int i = 0;
        copiedObject->list.resize(list.size());
        for (object_ptr element : list)
        {
            object_ptr newElement = make_shared<Object>();
            if (recursive and element->type == Object::OBJECT)
            {
                object_c copiedElement = element->data.o->deepCopy(true);
                newElement->data.o = copiedElement;
                newElement->type = Object::OBJECT;
                copiedElement->acquire();
            }
            else *newElement << *element;
            copiedObject->list[i] = newElement;
            ++i;
        }
        return copiedObject;
    }
};

class ChimeraMap : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
    friend class ChimeraUtils;
    friend class ChimeraStringUtils;
private:
    unordered_map<object_ptr, object_ptr> map;

    ChimeraMap(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("Map", vm)
    {
        (void) frame;
        putMethod("put", &ChimeraMap::put);
        putMethod("get", &ChimeraMap::get);
        putMethod("remove", &ChimeraMap::remove);
        putMethod("contains_key", &ChimeraMap::containsKey);
        putMethod("contains_value", &ChimeraMap::containsValue);
        putMethod("size", &ChimeraMap::size);
        putMethod("is_empty", &ChimeraMap::isEmpty);
        putMethod("clear", &ChimeraMap::clear);
    }

    ~ChimeraMap()
    {
        /*for (auto& elem : map)
        {
            if (elem.first->type == Object::OBJECT) unlink(elem.first->data.o);
            if (elem.second->type == Object::OBJECT) unlink(elem.second->data.o);
        }*/
        map.clear();
    }

    // void Map.put(any key, any value)
    vector<object_ptr> list;
    static STDCLMethod(put);
    // any Map.get(any key)
    static STDCLMethod(get);
    // void Map.remove(any key)
    static STDCLMethod(remove);
    // boolean Map.contains_key(any key)
    static STDCLMethod(containsKey);
    // boolean Map.contains_value(any value)
    static STDCLMethod(containsValue);
    // integer Map.size()
    static STDCLMethod(size);
    // boolean Map.is_empty()
    static STDCLMethod(isEmpty);
    // void Map.clear()
    static STDCLMethod(clear);

    object_c deepCopy(bool recursive) override
    {
        ChimeraMap* copiedObject = new ChimeraMap(vm, nullptr);
        for (std::pair<object_ptr, object_ptr> element : map)
        {
            object_ptr newKey = make_shared<Object>();
            object_ptr newValue = make_shared<Object>();
            if (recursive and element.first->type == Object::OBJECT)
            {
                object_c copiedKey = element.first->data.o->deepCopy(true);
                newKey->data.o = copiedKey;
                newKey->type = Object::OBJECT;
                copiedKey->acquire();
            }
            else *newKey << *element.first;
            if (recursive and element.second->type == Object::OBJECT)
            {
                object_c copiedValue = element.second->data.o->deepCopy(true);
                newValue->data.o = copiedValue;
                newValue->type = Object::OBJECT;
                copiedValue->acquire();
            }
            else *newValue << *element.second;
            copiedObject->map[newKey] = newValue;
        }
        return copiedObject;
    }
};

class ChimeraMath : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    ChimeraMath(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("Math", vm)
    {
        (void) frame;
        putMethod("float_compare", &ChimeraMath::floatCompare);
        putMethod("pow", &ChimeraMath::pow);
        putMethod("int_pow", &ChimeraMath::intPow);
        putMethod("sqrt", &ChimeraMath::sqrt);
        putMethod("log", &ChimeraMath::log);
        putMethod("sin", &ChimeraMath::sin);
        putMethod("cos", &ChimeraMath::cos);
        putMethod("tan", &ChimeraMath::tan);
        putMethod("asin", &ChimeraMath::asin);
        putMethod("acos", &ChimeraMath::acos);
        putMethod("atan", &ChimeraMath::atan);
        putMethod("sinh", &ChimeraMath::sinh);
        putMethod("cosh", &ChimeraMath::cosh);
        putMethod("tanh", &ChimeraMath::tanh);
        putMethod("asinh", &ChimeraMath::asinh);
        putMethod("acosh", &ChimeraMath::acosh);
        putMethod("atanh", &ChimeraMath::atanh);
        putMethod("cosec", &ChimeraMath::cosec);
        putMethod("sec", &ChimeraMath::sec);
        putMethod("cot", &ChimeraMath::cot);
        putMethod("acosec", &ChimeraMath::acosec);
        putMethod("asec", &ChimeraMath::asec);
        putMethod("acot", &ChimeraMath::acot);
        putMethod("round", &ChimeraMath::round);
        putMethod("ceil", &ChimeraMath::ceil);
        putMethod("floor", &ChimeraMath::floor);
        putMethod("truncate", &ChimeraMath::truncate);
        putMethod("abs", &ChimeraMath::abs);
        putMethod("mod_truncated", &ChimeraMath::modTruncated);
        putMethod("mod_floored", &ChimeraMath::modFloored);
        putMethod("factorial", &ChimeraMath::factorial);
        putMethod("radians_to_degrees", &ChimeraMath::radiansToDegrees);
        putMethod("degrees_to_radians", &ChimeraMath::degreesToRadians);
        putMethod("pi", &ChimeraMath::pi);
        putMethod("e", &ChimeraMath::e);
    }

#ifdef __GNUC__
    static constexpr float_c pi() { return std::atan(1)*4; }
#else
    static float_c pi() { return 3.141592653589793; }
#endif

    // int Math.float_compare(float f1, float f2, float mabs, float mrel)
    static STDCLMethod(floatCompare);
    // float Math.pow(int a, int b)
    static STDCLMethod(pow);
    // int Math.int_pow(int a, int b)
    static STDCLMethod(intPow);
    // float Math.sqrt(float a)
    static STDCLMethod(sqrt);
    // float Math.log(float x, int base)
    static STDCLMethod(log);
    // float Math.sin(float x)
    static STDCLMethod(sin);
    // float Math.cos(float x)
    static STDCLMethod(cos);
    // float Math.tan(float x)
    static STDCLMethod(tan);
    // float Math.asin(float x)
    static STDCLMethod(asin);
    // float Math.acos(float x)
    static STDCLMethod(acos);
    // float Math.atan(float x)
    static STDCLMethod(atan);
    // float Math.sinh(float x)
    static STDCLMethod(sinh);
    // float Math.cosh(float x)
    static STDCLMethod(cosh);
    // float Math.tanh(float x)
    static STDCLMethod(tanh);
    // float Math.asinh(float x)
    static STDCLMethod(asinh);
    // float Math.acosh(float x)
    static STDCLMethod(acosh);
    // float Math.atanh(float x)
    static STDCLMethod(atanh);
    // float Math.cosec(float x)
    static STDCLMethod(cosec);
    // float Math.sec(float x)
    static STDCLMethod(sec);
    // float Math.cot(float x)
    static STDCLMethod(cot);
    // float Math.acosec(float x)
    static STDCLMethod(acosec);
    // float Math.asec(float x)
    static STDCLMethod(asec);
    // float Math.acot(float x)
    static STDCLMethod(acot);
    // float Math.round(float x, int decimal_places)
    static STDCLMethod(round);
    // int Math.ceil(float x)
    static STDCLMethod(ceil);
    // int Math.floor(float x)
    static STDCLMethod(floor);
    // int Math.truncate(float x)
    static STDCLMethod(truncate);
    // float Math.abs(float x)
    static STDCLMethod(abs);
    // int Math.mod_truncated(int x, int n)
    static STDCLMethod(modTruncated);
    // int Math.mod_floored(int x, int n)
    static STDCLMethod(modFloored);
    // int Math.factorial(int x)
    static STDCLMethod(factorial);
    // float Math.radians_to_degrees(float theta)
    static STDCLMethod(radiansToDegrees);
    // float Math.degrees_to_radians(float theta)
    static STDCLMethod(degreesToRadians);
    // float Math.pi()
    static STDCLMethod(pi);
    // float Math.e()
    static STDCLMethod(e);
};

class ChimeraRegexUtils : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    std::unordered_map<string, vector<string>> capturedCache;
    std::unordered_map<string, std::regex> patternCache;

    ChimeraRegexUtils(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("RegexUtils", vm)
    {
        (void) frame;
        putMethod("full_match", &ChimeraRegexUtils::fullMatch);
        putMethod("contains_match", &ChimeraRegexUtils::containsMatch);
        putMethod("find_matches", &ChimeraRegexUtils::findMatches);
        putMethod("get_captured", &ChimeraRegexUtils::getCaptured);
        putMethod("replace", &ChimeraRegexUtils::replace);
        putMethod("split", &ChimeraRegexUtils::split);
    }

    // bool RegexUtils.full_match(string str, string pattern)
    static STDCLMethod(fullMatch);
    // bool RegexUtils.contains_match(string str, string pattern)
    static STDCLMethod(containsMatch);
    // List RegexUtils.find_matches(string str, string pattern)
    static STDCLMethod(findMatches);
    // string RegexUtils.get_captured(int index, string match)
    static STDCLMethod(getCaptured);
    // string RegexUtils.replace(string str, string pattern, string replace)
    static STDCLMethod(replace);
    // List RegexUtils.split(string str, string pattern)
    static STDCLMethod(split);
};

class ChimeraScopeObject : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    uint_fast32_t currentDepth;
    unordered_map<string, std::map<uint_fast32_t, object_ptr>> localTable;
    std::deque<uint_fast32_t> scopeSearchLimit;

    ChimeraScopeObject(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("ScopeObject", vm)
    {
        (void) frame;
        putMethod("up_scope", &ChimeraScopeObject::upScope);
        putMethod("down_scope", &ChimeraScopeObject::downScope);
        putMethod("get_local", &ChimeraScopeObject::getLocal);
        putMethod("put_local", &ChimeraScopeObject::putLocal);
        putMethod("print_scope_list", &ChimeraScopeObject::printScopeList);

        this->currentDepth = 0;
        this->scopeSearchLimit.push_back(0);
    }

    // ScopeObject ScopeObject.up_scope(boolean inherits_parent)
    static STDCLMethod(upScope);
    // ScopeObject ScopeObject.down_scope(integer roll_back_depth)
    static STDCLMethod(downScope);
    // any ScopeObject.get_local(string name)
    static STDCLMethod(getLocal);
    // void ScopeObject.put_local(string name, any obj)
    static STDCLMethod(putLocal);
    // void ScopeObject.print_scope_list()
    static STDCLMethod(printScopeList);

    object_c deepCopy(bool recursive) override
    {
        ChimeraScopeObject* copiedObject = new ChimeraScopeObject(vm, nullptr);
        copiedObject->currentDepth = currentDepth;
        copiedObject->scopeSearchLimit.resize(scopeSearchLimit.size());
        size_t i = 0;
        for (uint_fast16_t level : scopeSearchLimit) copiedObject->scopeSearchLimit[i++] = level;
        for (auto& mapping : localTable)
        {
            auto& copiedMapping = copiedObject->localTable[mapping.first];
            for (auto& var : mapping.second)
            {
                object_ptr newLocal = make_shared<Object>();
                if (recursive and var.second->type == Object::OBJECT)
                {
                    object_c copiedLocal = var.second->data.o->deepCopy(true);
                    newLocal->data.o = copiedLocal;
                    newLocal->type = Object::OBJECT;
                    copiedLocal->acquire();
                }
                else *newLocal << *var.second;
                copiedMapping[var.first] = newLocal;
            }
        }
        return copiedObject;
    }
};

class ChimeraStack : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    std::deque<object_ptr> stack;

    ChimeraStack(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("Stack", vm)
    {
        (void) frame;
        putMethod("push", &ChimeraStack::push);
        putMethod("peek", &ChimeraStack::peek);
        putMethod("pop", &ChimeraStack::pop);
        putMethod("size", &ChimeraStack::size);
        putMethod("is_empty", &ChimeraStack::isEmpty);
        putMethod("clear", &ChimeraStack::clear);
    }

    ~ChimeraStack()
    {
        // TODO unlinking code
    }

    // void Stack.push(any value)
    static STDCLMethod(push);
    // any Stack.peek()
    static STDCLMethod(peek);
    // any Stack.pop()
    static STDCLMethod(pop);
    // int Stack.size()
    static STDCLMethod(size);
    // bool Stack.is_empty()
    static STDCLMethod(isEmpty);
    // void Stack.clear()
    static STDCLMethod(clear);

    object_c deepCopy(bool recursive) override
    {
        ChimeraStack* copiedObject = new ChimeraStack(vm, nullptr);
        copiedObject->stack.resize(stack.size());
        size_t i = 0;
        for (object_ptr element : stack)
        {
            object_ptr newElement = make_shared<Object>();
            if (recursive and element->type == Object::OBJECT)
            {
                object_c copiedElement = element->data.o->deepCopy(true);
                newElement->data.o = copiedElement;
                newElement->type = Object::OBJECT;
                copiedElement->acquire();
            }
            else *newElement << *element;
            copiedObject->stack[i++] = newElement;
        }
        return copiedObject;
    }
};

class ChimeraStringUtils : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
    friend class ChimeraFile;
    friend class ChimeraScopeObject;
private:
    ChimeraStringUtils(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("StringUtils", vm)
    {
        (void) frame;
        putMethod("stringable", &ChimeraStringUtils::stringable);
        putMethod("stringify", &ChimeraStringUtils::stringify);
        putMethod("to_int", &ChimeraStringUtils::toInt);
        putMethod("to_float", &ChimeraStringUtils::toFloat);
        putMethod("to_boolean", &ChimeraStringUtils::toBoolean);
        putMethod("format", &ChimeraStringUtils::format);
        putMethod("reverse_string", &ChimeraStringUtils::reverseString);
        putMethod("string_compare", &ChimeraStringUtils::stringCompare);
        putMethod("lowercase", &ChimeraStringUtils::lowercase);
        putMethod("uppercase", &ChimeraStringUtils::uppercase);
        putMethod("capitalize", &ChimeraStringUtils::capitalize);
        putMethod("split", &ChimeraStringUtils::split);
        putMethod("replace", &ChimeraStringUtils::replace);
        putMethod("strip", &ChimeraStringUtils::strip);
        putMethod("count", &ChimeraStringUtils::count);
        putMethod("length", &ChimeraStringUtils::length);
        putMethod("substring", &ChimeraStringUtils::substring);
        putMethod("get", &ChimeraStringUtils::get);
    }

    // bool StringUtils.stringable(any obj)
    static STDCLMethod(stringable);
    // string StringUtils.stringify(any <stringable> obj)
    static STDCLMethod(stringify);
    // int StringUtils.to_int(string str)
    static STDCLMethod(toInt);
    // float StringUtils.to_float(string str)
    static STDCLMethod(toFloat);
    // bool StringUtils.to_boolean(string str)
    static STDCLMethod(toBoolean);
    // string StringUtils.format(string format_string, any args...)
    static STDCLMethod(format);
    // string StringUtils.reverse_string(string str)
    static STDCLMethod(reverseString);
    // int StringUtils.string_compare(string str1, string str2)
    static STDCLMethod(stringCompare);
    // string StringUtils.lowercase(string str)
    static STDCLMethod(lowercase);
    // string StringUtils.uppercase(string str)
    static STDCLMethod(uppercase);
    // string StringUtils.capitalize(string str)
    static STDCLMethod(capitalize);
    // List StringUtils.split(string str, string delimeter)
    static STDCLMethod(split);
    // string StringUtils.replace(string str, string replace, string with)
    static STDCLMethod(replace);
    // string StringUtils.strip(string str)
    static STDCLMethod(strip);
    // int StringUtils.count(string str, string seq)
    static STDCLMethod(count);
    // int StringUtils.length(string str)
    static STDCLMethod(length);
    // string StringUtils.substring(string str, int start, int end)
    static STDCLMethod(substring);
    // string StringUtils.get(string str, int index)
    static STDCLMethod(get);
};

class ChimeraTable : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
    friend class ChimeraUtils;
    friend class ChimeraStringUtils;
private:
    vector<vector<object_ptr>> table;
    int_c numEntries;

    ChimeraTable(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("Table", vm)
    {
        (void) frame;
        putMethod("put", &ChimeraTable::put);
        putMethod("get", &ChimeraTable::get);
        putMethod("get_row", &ChimeraTable::getRow);
        putMethod("get_col", &ChimeraTable::getCol);
        putMethod("remove", &ChimeraTable::remove);
        putMethod("remove_row", &ChimeraTable::removeRow);
        putMethod("remove_col", &ChimeraTable::removeCol);
        putMethod("trim", &ChimeraTable::trim);
        putMethod("contains", &ChimeraTable::contains);
        putMethod("num_rows", &ChimeraTable::numRows);
        putMethod("num_cols", &ChimeraTable::numCols);
        putMethod("size", &ChimeraTable::size);
        putMethod("is_empty", &ChimeraTable::isEmpty);
        putMethod("is_matrix", &ChimeraTable::isMatrix);
        putMethod("transpose", &ChimeraTable::transpose);
        putMethod("clear", &ChimeraTable::clear);
        numEntries = 0;
    }

    ~ChimeraTable()
    {
        for (auto& row : table)
        {
            //for (auto& elem : row) if (elem->type == Object::OBJECT) unlink(elem->data.o);
            row.clear();
        }
        table.clear();
    }

    // void Table.put(int row, int col, any value)
    static STDCLMethod(put);
    // any Table.get(int row, int col)
    static STDCLMethod(get);
    // List Table.get_row(int row, bool leave_null)
    static STDCLMethod(getRow);
    // List Table.get_col(int col, bool leave_null)
    static STDCLMethod(getCol);
    // void Table.remove(int row, int col)
    static STDCLMethod(remove);
    // void Table.remove_row(int row)
    static STDCLMethod(removeRow);
    // void Table.remove_col(int col)
    static STDCLMethod(removeCol);
    // void Table.trim()
    static STDCLMethod(trim);
    // bool Table.contains(any value)
    static STDCLMethod(contains);
    // int Table.num_rows()
    static STDCLMethod(numRows);
    // int Table.num_cols()
    static STDCLMethod(numCols);
    // int Table.size()
    static STDCLMethod(size);
    // bool Table.is_empty()
    static STDCLMethod(isEmpty);
    // bool Table.is_matrix()
    static STDCLMethod(isMatrix);
    // void Table.transpose()
    static STDCLMethod(transpose);
    // void Table.clear()
    static STDCLMethod(clear);

    inline bool isMatrix() const
    {
        int rowSize = -1;
        for (const vector<object_ptr>& row : table)
        {
            if (rowSize == -1) rowSize = row.size();
            if ((unsigned) rowSize != row.size()) return false;
        }
        return true;
    }

    inline bool isSquare() const
    {
        return table.size() > 1 and table[0].size() == table.size();
    }

    object_c deepCopy(bool recursive) override
    {
        ChimeraTable* copiedObject = new ChimeraTable(vm, nullptr);
        copiedObject->table.resize(table.size());
        int i = 0;
        for (vector<object_ptr>& row : table)
        {
            copiedObject->table[i].resize(row.size());
            int j = 0;
            for (object_ptr element : row)
            {
                object_ptr newElement = make_shared<Object>();
                if (recursive and element->type == Object::OBJECT)
                {
                    object_c copiedElement = element->data.o->deepCopy(true);
                    newElement->data.o = copiedElement;
                    newElement->type = Object::OBJECT;
                    copiedElement->acquire();
                }
                else *newElement << *element;
                copiedObject->table[i][j] = newElement;
                ++j;
            }
            ++i;
        }
        return copiedObject;
    }
};

class ChimeraTaskManager : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    std::map<int_c, std::thread> threads;
    int_c currentId;

    ChimeraTaskManager(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("TaskManager", vm)
    {
        (void) frame;
        this->currentId = 0;
        putMethod("run_local_task", &ChimeraTaskManager::runLocalTask);
        /*putMethod("run_global_task", &ChimeraTaskManager::runGlobalTask);
        putMethod("collect_result", &ChimeraTaskManager::collectResult);
        putMethod("await_tasks", &ChimeraTaskManager::awaitTasks);
        putMethod("set_pool_runner", &ChimeraTaskManager::setPoolRunner);
        putMethod("submit_pool_task", &ChimeraTaskManager::submitPoolTask);
        putMethod("run_pool", &ChimeraTaskManager::runPool);
        putMethod("stop_pool", &ChimeraTaskManager::stopPool);
        putMethod("acquire_lock", &ChimeraTaskManager::acquireLock);
        putMethod("release_lock", &ChimeraTaskManager::releaseLock);
        putMethod("sleep", &ChimeraTaskManager::sleep);*/
    }

    // int TaskManager.run_local_task(int function_ref, any args...)
    static STDCLMethod(runLocalTask);
/*
    // int TaskManager.run_global_task(int function_ref, any args...)
    static STDCLMethod(runGlobalTask);
    // any TaskManager.collect_result(int id)
    static STDCLMethod(collectResult);
    // void TaskManager.await_tasks()
    static STDCLMethod(awaitTasks);
    // void TaskManager.set_pool_runner(int function_ref, int num_threads)
    static STDCLMethod(setPoolRunner);
    // int TaskManager.submit_pool_task(any args...)
    static STDCLMethod(submitPoolTask);
    // void TaskManager.run_pool()
    static STDCLMethod(runPool);
    // void TaskManager.stop_pool()
    static STDCLMethod(stopPool);
    // void TaskManager.sleep(int millis)
    static STDCLMethod(sleep);
    // void TaskManager.acquire_lock(int lock)
    static STDCLMethod(acquireLock);
    // void TaskManager.release_lock(int lock)
    static STDCLMethod(releaseLock);
*/

    ~ChimeraTaskManager()
    {
        //for (auto entry : threads)
        for (auto it = threads.begin(); it != threads.end(); ++it)
        {
            if (it->second.joinable())
            {
                it->second.join();
            }
        }
    }
};

class ChimeraTypeUtils : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
private:
    ChimeraTypeUtils(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("TypeUtils", vm)
    {
        (void) frame;
        putMethod("is_null", &ChimeraTypeUtils::isNull);
        putMethod("null", &ChimeraTypeUtils::null);
        putMethod("get_id", &ChimeraTypeUtils::getId);
        putMethod("has_method", &ChimeraTypeUtils::hasMethod);
        putMethod("has_attribute", &ChimeraTypeUtils::hasAttribute);
        putMethod("get_name", &ChimeraTypeUtils::getName);
        putMethod("get_type", &ChimeraTypeUtils::getType);
        putMethod("is_instance", &ChimeraTypeUtils::isInstance);
        putMethod("to_int", &ChimeraTypeUtils::toInt);
        putMethod("to_bool", &ChimeraTypeUtils::toBool);
    }

    // bool TypeUtils.is_null(any obj)
    static STDCLMethod(isNull);
    // null TypeUtils.null()
    static STDCLMethod(null);
    // int TypeUtils.get_id(object obj)
    static STDCLMethod(getId);
    // bool TypeUtils.has_method(object obj, string method_name)
    static STDCLMethod(hasMethod);
    // bool TypeUtils.has_attribute(object obj, string attribute_name)
    static STDCLMethod(hasAttribute);
    // string TypeUtils.get_name(object obj)
    static STDCLMethod(getName);
    // string TypeUtils.get_type(any obj)
    static STDCLMethod(getType);
    // bool TypeUtils.is_instance(any obj, string type)
    static STDCLMethod(isInstance);
    // bool TypeUtils.to_int(bool b)
    static STDCLMethod(toInt);
    // int TypeUtils.to_bool(int i)
    static STDCLMethod(toBool);
};

class ChimeraUtils : private IChimeraStandardLibraryObject
{
    friend class ChimeraStandardLibrary;
    friend class ChimeraVirtualMachine;
private:
    ChimeraUtils(ChimeraVirtualMachine* vm, Frame* const frame) : IChimeraStandardLibraryObject("ChimeraUtils", vm)
    {
        (void) frame;
        putMethod("deep_copy", &ChimeraUtils::deepCopy);
        putMethod("rand_int", &ChimeraUtils::randInt);
        putMethod("block_copy", &ChimeraUtils::blockCopy);
        putMethod("mabs", &ChimeraUtils::mabs);
        putMethod("mrel", &ChimeraUtils::mrel);
        putMethod("time", &ChimeraUtils::time);
        putMethod("read", &ChimeraUtils::read);
        putMethod("read_line", &ChimeraUtils::readLine);
        putMethod("read_int", &ChimeraUtils::readInt);
        putMethod("flush", &ChimeraUtils::flush);
        putMethod("file_exists", &ChimeraUtils::fileExists);
    }

    // object ChimeraUtils.deep_copy(object obj, bool recursive)
    static STDCLMethod(deepCopy);
    // int ChimeraUtils.rand_int(int min, int max)
    static STDCLMethod(randInt);
    // void ChimeraUtils.block_copy(int from, int to, int length)
    static STDCLMethod(blockCopy);
    // float ChimeraUtils.mabs()
    static STDCLMethod(mabs);
    // float ChimeraUtils.mrel()
    static STDCLMethod(mrel);
    // int ChimeraUtils.time()
    static STDCLMethod(time);
    // string ChimeraUtils.read(int n)
    static STDCLMethod(read);
    // string ChimeraUtils.read_line()
    static STDCLMethod(readLine);
    // int ChimeraUtils.read_int()
    static STDCLMethod(readInt);
    // void ChimeraUtils.flush()
    static STDCLMethod(flush);
    // bool ChimeraUtils.file_exists();
    static STDCLMethod(fileExists);
};

#endif // CHIMERA_STANDARD_LIBRARY_HEADER
