#include "ChimeraStandardLibrary.h"
#define args currentFrame->arguments

/* For Sammy-boy;
   I have hooked in the required use of returnLine for the VM, you are good to go on that front...
   Your test needs to replace END with RETURN for your local task!
   Be careful when writing future tasks, :0 is the taskmanager (weirdly, but who cares), :1 starts the args passed into the function
   this is likely to trip you up at least once (already happened twice to me already...)
   I like what you did with the destructor, neat. However I'm not sure if that's the best way of going about it yet... My thought
   is that when the TaskManager is destroyed it shouldn't necessarily wait for the threads to finish, since this could cause VM
   freezeup at some point. It's a minor thing, but it might be better to call detach on the threads and then let them be terminated
   by their destructors when they go out of scope? Up to you :)

   Make sure you think about how to implement collect_result in advance! You might need to use std::packaged_task and std::future to collect
   the result! I've posted a comment about it on your initial commit.

   Some C++ stuff;
   Use for (type element : container) where possible, not iterators... in case of map, use for (auto& entry : container), where entry.first and entry.second
   are your friends. auto is nice for when you have stupidly long types (like iterators!).

   Avoid unnecessary copies! C++ is a pass by value language, NOT a pass by reference like Java. When you pass a vector into a function without using a
   pointer or reference, you copy the entire vector across... not great! Use references when you can, though note they cannot be reassigned their value
   (essentially a T* const).

   Beware of references! If you pass a reference into a function and then store it somewhere in an object for instance, when you leave the scope of the
   enclosing function call, the object is destroyed and the reference is invalid. Sometimes it is better to pass by value, or better yet, allocate the thing
   on the heap with new and use pointers. You have fallen into this trap with the ostream out in the VM. If the vm is constructed in one function then interpret
   called separately, it will crash. It's fine though, since that is the only way I can think to do it... It will be labelled as a vm limitation.

   Don't forget whitespace after if and before bracket; if (cond) not if(cond) :)

   I know you'd have seen it in my code in places, but try not to initialise a container with something on the rhs... It invokes a move constructor
   and reduces performance... vector<type> v; suffices to create a new vector... unless you want it on the heap...

   You *might* want to use "using std::thread" in this file, since std::thread is going to be used a lot... up to you!

   When you (perfectly rightly too) declare aliases around object attributes (like for instance taskManagerSelf and currentVM below), make sure to always
   use either pointers (if required) or references. Even better try and use as many consts as possible around it, this helps the compiler optimise the
   variables out and improve the speed, as well as prevents mistakes on our parts. As a general rule you read C++ types from right to left in a circle
   (see clockwise/spiral rule!) so with pointers you have const1 type* const2 variable, which is read as const2 pointer to const1 type. const1 imples the
   variable pointed to cannot be edited (including changing attributes of an object) and const2 implies the value of the pointer cannot be adjusted to
   point elsewhere. Otherwise const type is equivalent to type const, so use const type for consistency with other languages.

   Finally, use make_shared<>() with shared_ptr, it does a single heap allocation instead of 2 (one for pointer, one for object), so is twice as fast!

   That is all... Hopefully you've learnt something more about C++ from that paragraph...
*/

// Declare helper functions here
//void startNewLocalTask(int i);

//ChimeraTaskManager
STDCLMethod(ChimeraTaskManager::runLocalTask)
{
    LOG("TaskManager.run_local_task called");
    // Program memory is NO LONGER copied (you're welcome)
    // New call stack is created, ~default atm, should be same as current~ is same as current (you're welcome)
    CHECK_ARGS(currentFrame, 1);
    CHECK_TYPE(*args[1], INT);

    // There's nothing like throwing a const around every now and then.
    // First is a pointer that cannot be changed, the second is a pointer to a vm that can't be changed, that can't be changed
    ChimeraTaskManager* const taskManagerSelf = (ChimeraTaskManager*) self;
    const ChimeraVirtualMachine* const currentVM = taskManagerSelf->vm;
    const int_c& functionRef = args[1]->data.i;

    // No need for this!
    /*
    // Firstly, this is bad, should be vector<vector<byte>>& if anything
    vector<vector<byte>>& currentProgramMemory = currentVM->programMemory;
    // Secondly, this is also bad, the above line actually does this, and way more efficiently, also no need for rhs (I know I've used it in the past, but I'm an idiot)
    vector<vector<byte>> programMemory = {};
    for (vector<byte> line : currentProgramMemory)
    {
        vector<byte> newLine; // no need for right hand side stuff you had before!
        for (byte b : line)
        {
            newLine.push_back(b);
        }
        programMemory.push_back(newLine);
    }
    */

    // Create new virtual machine (simplified)
    vm_ptr vm = make_shared<ChimeraVirtualMachine>(currentVM, functionRef, currentFrame, false);

    // Run interpret method in new thread, thread stored in map, by threadId which is returned
    int_c threadId = taskManagerSelf->currentId++;
    taskManagerSelf->threads[threadId] = std::thread(&ChimeraVirtualMachine::interpret, vm, vm->silence);
    // We now return directly into the vm itself! use RETURN_VOID; for void returns and then RETURN blocks for any other return.
    // In addition some methods need to return a result back to the environment vs direct into the vm. These methods are specialcase
    // In the general case, write return nullptr; at the end of every method.
    self->returnSTDCL(currentFrame, threadId);
    return nullptr;
}

// Define helper functions here
/*void startNewLocalTask(int i)
{
    //vm->interpret();
    cout << "vm thread ended: " << i << endl;
}*/

#undef args
#undef numargs
#undef returnAddress
#undef NO_PASSBACK
#undef RETURN
#undef RETURN_VOID
