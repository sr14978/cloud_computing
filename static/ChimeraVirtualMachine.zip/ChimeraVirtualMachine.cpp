#include "ChimeraVirtualMachine.h"
#include "ChimeraJIT.h"

enum class PreprocessorDirective {RECURSION_DEPTH, RECURSION_DEPTH_UNBOUNDED, INITIAL_MEMORY_BLOCKS, DETECT_DEADLOCK};

// Object Methods
id_c Object::objectId = 0;

Object::Object() : type(NOTYPE), preserve(false)
{
    uid = objectId++;
    id = uid;
}

Object::Object(Object* that)
{
    this->uid = objectId++;
    this->data = that->data;
    this->id = that->id;
    this->type = that->type;
    if (this->type == OBJECT) this->data.o->acquire();
}

Object::~Object()
{
    LOG("Object #" << uid << ":" << id << " destroyed");
    if (!preserve) readyOverwrite();
}

void Object::readyOverwrite()
{
    switch(type)
    {
    case STRING: delete data.s; break;
    case OBJECT: data.o->release(); break;
    case TUPLE:
        std::cerr << "TupleViolationException: cannot clear a tuple unless it has been unpacked" << endl;
        exit(1);
        break;
    default: break;
    }
}

bool operator==(const object_ref o1, const object_ptr& o2)
{
    if (o1.uid == o2->uid) return true;
    if (o1.type != o2->type) return false;
    switch(o1.type)
    {
    case Object::INT: return o1.data.i == o2->data.i;
    case Object::FLOAT: return chimeraFloatEquality(o1.data.f, o2->data.f);
    case Object::STRING: return (*o1.data.s) == (*o2->data.s);
    case Object::BOOL: return o1.data.b == o2->data.b;
    case Object::OBJECT: return o1.data.o == o2->data.o;
    case Object::TUPLE: return o1.data.t == o2->data.t;
    default: return false;
    }
}

bool operator==(const object_ptr& o1, const object_ptr& o2)
{
    if (o1->uid == o2->uid) return true;
    if (o1->type != o2->type) return false;
    switch(o1->type)
    {
    case Object::INT: return o1->data.i == o2->data.i;
    case Object::FLOAT: return chimeraFloatEquality(o1->data.f, o2->data.f);
    case Object::STRING: return (*o1->data.s) == (*o2->data.s);
    case Object::BOOL: return o1->data.b == o2->data.b;
    case Object::OBJECT: return o1->data.o == o2->data.o;
    case Object::TUPLE: return o1->data.t == o2->data.t;
    default: return false;
    }
}

void operator<<(object_ref o1, object_ref o2)
{
    if (o1.uid == o2.uid)
    {
        LOG("SUPPRESSED COPY");
        return;
    }
    o1.id = o2.id;
    o1.readyOverwrite();
    o1.type = o2.type;
    switch(o2.type)
    {
    case Object::STRING: o1.data.s = new string(*o2.data.s); break;
    case Object::OBJECT:
        o1.data.o = o2.data.o;
        o1.data.o->acquire();
        break;
    case Object::TUPLE:
        o1.data.t = o2.data.t;
        // This is important, we have moved a tuple, but we can't allow the original pointer to be deleted, we need to clear the type!
        o2.type = Object::NOTYPE;
        break;
    default:
        o1.data = o2.data;
        break;
    }
}

string Object::dataToString() const
{
    std::stringstream str;
    switch(type)
    {
    case INT: str << data.i; break;
    case FLOAT: str << data.f; break;
    case BOOL: str << data.b; break;
    case STRING: str << *data.s; break;
    case OBJECT: str << "Object #" << data.o->getId(); break;
    case TUPLE: str << data.t->toString(); break;
    default: str << "null"; break;
    }
    return str.str();
}

string Object::typeToString() const
{
    switch(type)
    {
    case INT: return "INT";
    case FLOAT: return "FLOAT";
    case BOOL: return "BOOL";
    case STRING: return "STRING";
    case OBJECT: return "OBJECT";
    case TUPLE: return "TUPLE";
    default: return "NOTYPE";
    }
}

void Object::print() const
{
    cout << uid << ":" << id << ":" << (int) type << " = " << dataToString() << endl;
}

object_ptr Object::make(int_c i)
{
    object_ptr newObject = make_shared<Object>();
    newObject->data.i = i;
    newObject->type = Object::INT;
    return newObject;
}

object_ptr Object::make(float_c f)
{
    object_ptr newObject = make_shared<Object>();
    newObject->data.f = f;
    newObject->type = Object::FLOAT;
    return newObject;
}

object_ptr Object::make(bool_c b)
{
    object_ptr newObject = make_shared<Object>();
    newObject->data.b = b;
    newObject->type = Object::BOOL;
    return newObject;
}

object_ptr Object::make(const char* s)
{
    return Object::make(new string(s));
}

object_ptr Object::make(string_c s)
{
    object_ptr newObject = make_shared<Object>();
    newObject->data.s = s;
    newObject->type = Object::STRING;
    return newObject;
}

object_ptr Object::make(object_c o)
{
    object_ptr newObject = make_shared<Object>();
    newObject->data.o = o;
    newObject->type = Object::OBJECT;
    o->acquire();
    return newObject;
}

// ChimeraObject Methods
id_c ChimeraObject::objectId = 0;

ChimeraObject::ChimeraObject() : references(0)
#ifdef CYCLIC_GC
, objectReferences(0), index(0), onStack(false), linkState(0)
#endif
{ id = objectId++; }

ChimeraObject::ChimeraObject(const string name) : ChimeraObject() { tag = name; }
ChimeraObject::~ChimeraObject()
{
    LOG("Chimera Object #" << id << " has been garbage collected");
    #ifdef CYCLIC_GC
    for (auto& attr : attributes)
    {
        if (attr.second.type == Object::OBJECT)
        {
            if (not onStack) unlink(attr.second.data.o);
            else attr.second.type = Object::NOTYPE;
        }
    }
    #endif
    attributes.clear();
    methods.clear();
}

id_c& ChimeraObject::getId() { return id; }
string& ChimeraObject::getTag() { return tag; }

void ChimeraObject::acquire()
{
    ++references;
    LOG("Chimera Object #" << id << " has count " << references);
}

void ChimeraObject::release()
{
    --references;
    LOG("Chimera Object #" << id << " has count " << references);
    if (not references) delete this;
    #ifdef CYCLIC_GC
    // As an optimisation, we can do a quick check for non-object refs in the root, this will eliminate most runs
    else if (objectReferences == references and linkState != linkCount and succs.size() != 0)
    {
        runGarbage();
        // SAFE: We are actually in a stable structure, assuming no change to the linkage of objects we are completely stable
        if (objectReferences == references) linkState = linkCount;
    }
    #endif // CYCLIC_GC
}

void ChimeraObject::putAttribute(const string& name, object_ref value)
{
    #ifdef CYCLIC_GC
    if (value.type == Object::OBJECT) link(value.data.o);
    if (hasAttribute(name) && attributes[name].type == Object::OBJECT) unlink(attributes[name].data.o);
    #endif // CYCLIC_GC
    attributes[name] << value;
}

object_ref ChimeraObject::getAttribute(const string& name)
{
    #ifdef RUNTIME_CHECKS
    return attributes.at(name);
    #else
    return attributes[name];
    #endif // RUNTIME_CHECKS
}
bool ChimeraObject::hasAttribute(const string& name) { return attributes.find(name) != attributes.end(); }
void ChimeraObject::putMethod(const string& name, MethodOrInt startLine) { methods[name] = startLine; }
bool ChimeraObject::hasMethod(const string& name) { return methods.find(name) != methods.end(); }
MethodOrInt ChimeraObject::getMethod(const string& name)
{
    #ifdef RUNTIME_CHECKS
    if (not hasMethod(name))
    {
        std::cerr << tag << " does not have method \"" << name << "\"" << endl;
        exit(1);
    }
    #endif // RUNTIME_CHECKS
    return methods[name];
}

ChimeraObject* ChimeraObject::deepCopy(bool recursive)
{
    ChimeraObject* copiedObject = new ChimeraObject(tag);
    for (auto attribute : attributes)
    {
        if (attribute.second.type == Object::OBJECT and recursive)
        {
            ChimeraObject* copiedAttribute = attribute.second.data.o->deepCopy(true);
            copiedObject->attributes[attribute.first].data.o = copiedAttribute;
            copiedObject->attributes[attribute.first].type = Object::OBJECT;
            copiedAttribute->acquire();
        }
        else copiedObject->attributes[attribute.first] << attribute.second;
    }
    copiedObject->methods = methods;
    return copiedObject;
}

#ifdef CYCLIC_GC
uint64_t ChimeraObject::linkCount = 0;

void ChimeraObject::link(object_c obj)
{
    LOG("Linking objects #" << this->id << " and #" << obj->id);
    ++succs[obj];
    obj->preds.insert(this);
    ++obj->objectReferences;
    ++linkCount;
}

void ChimeraObject::unlink(object_c obj)
{
    LOG("Unlinking objects #" << this->id << " and #" << obj->id);
    ++linkCount;
    if (succs.count(obj) > 1)
    {
        --succs[obj];
        --obj->objectReferences;
    }
    else
    {
        succs.erase(obj);
        obj->preds.erase(this);
    }
}

void ChimeraObject::runGarbage()
{
    LOG("Running Garbage Collector with root " << id);
    vector<vector<object_c>> cycles;
    vector<object_c> noncyclic;
    tarjan(cycles, noncyclic);
    // The reverse Topological Sort of SCCs returned by Tarjan's is the inverse optimal traversal order
    for (size_t i = cycles.size(); i-- > 0;)
    {
        auto& cycle = cycles[i];
        std::sort(cycle.begin(), cycle.end());
        // another quick optimisation - if the root isn't in first cycle, then nothing can change
        if (i == cycles.size() - 1 and not std::binary_search(cycle.begin(), cycle.end(), this)) return;
        bool unreachable = true;
        std::unordered_set<object_c> seen;
        for (size_t j = 0; j < cycle.size() and unreachable; ++j)
        {
            object_c obj = cycle[j];
            seen.insert(obj);
            // If we have more references than references from objects, we are trivially reachable, or,
            // if we have more predecessors than members of the cycle then there's no point in checking: we are reachable
            // This is guaranteed as either the predecessor is from the external world or is from a parent cycle in the Topological Ordering
            if (obj->objectReferences < obj->references or obj->preds.size() > cycle.size())
            {
                // if this was true for the root cycle then don't bother checking other cycles, they are reachable by proxy!
                if (i == cycles.size() - 1) return;
                break;
            }
            // otherwise we are going to have to verify all the references come from within the cycle
            for (object_c pred : obj->preds)
            {
                if (not std::binary_search(cycle.begin(), cycle.end(), pred))
                {
                    // We've identified a predecessor outside the cycle, from reasoning above we are reachable
                    // if this was true for the root cycle then don't bother checking other cycles, they are reachable by proxy!
                    if (i == cycles.size() - 1) return;
                    unreachable = false;
                    break;
                }
            }
        }
        if (unreachable)
        {
            ++linkCount;
            for (size_t j = 0; j < cycle.size(); ++j)
            {
                object_c obj = cycle[j];
                auto& succs = obj->succs;
                for (auto& succ : succs)
                {
                    object_c succ_p = succ.first;
                    if (seen.find(succ_p) == seen.end())
                    {
                        seen.insert(succ_p);
                        if (--(succ_p->references)) --(succ_p->objectReferences);
                        else cycle.push_back(succ_p);
                    }
                }
                obj->onStack = true;
                delete obj;
            }
        }
    }
    // Theorem; In a linear system, everything is stable
    for (size_t i = 0; i < noncyclic.size(); ++i) noncyclic[i]->linkState = linkCount;
}

void ChimeraObject::tarjan(vector<vector<object_c>>& cycles, vector<object_c>& noncyclic)
{
    ResizableArrayStack<object_c> stack(8);
    ResizableArrayStack<object_c> callStack(8);
    callStack.push(this);
    unsigned int index = 1;
    object_c v, w;

strong_connect:
    v = callStack.peek();
    v->index = index;
    v->lowlink = index;
    index++;
    stack.push(v);
    v->onStack = true;
    for (v->iter = v->succs.begin(); v->iter != v->succs.end(); v->iter++)
    {
        w = v->iter->first;
        if (w->index == 0)
        {
            callStack.push(w);
            goto strong_connect;
        continuation:
            v->lowlink = std::min(v->lowlink, w->lowlink);
            w->lowlink = 0;
        }
        else if (w->onStack)
        {
            // optimisation, finds self-loops
            if (w == v) cycles.push_back({v});
            v->lowlink = std::min(v->lowlink, w->index);
        }
    }

    if (v->lowlink == v->index)
    {
        // optimisation, prevents unnecessary allocations
        if (stack.peek() != v)
        {
            vector<object_c> cycle;
            do
            {
                w = stack.pop();
                w->onStack = false;
                w->index = 0;
                w->lowlink = 0;
                cycle.push_back(w);
            } while (w != v);
            cycles.push_back(cycle);
        }
        else
        {
            stack.pop();
            v->onStack = false;
            v->index = 0;
            if (v->preds.count(v) == 0) noncyclic.push_back(v);
        }
    }

    callStack.pop();
    if (!callStack.isEmpty())
    {
        // UNSAFE: THIS HASN'T BEEN PROVED YET
        // In theory, the technique that states that surviving a GC round implies stability can be applied early
        // If GC cleans up anything, it affects the linkCount, so anything we touch in this graph would be in conflict
        // of the linkCount. If there was no cleanup, then everything we touch in here is stable if the objectReferences == references
        // So we should be able to apply it early. It's not as strong as a post GC fix, but it'll still provide an improvement in
        // an already established stable structure.
        if (v->objectReferences == v->references) v->linkState = linkCount;
        w = v;
        v = callStack.peek();
        goto continuation;
    }
    v->lowlink = 0;
}
#endif // CYCLIC_GC

// Frame Methods
// We never start at 0, since that is where self is... But we need to ensure the initial allocation of the self arg (arg 0)
Frame::Frame() : callingLine(-1), returnAddr(-1), nextArgIndex(1) { arguments.push_back(make_shared<Object>()); }
// We are now formally deprecating the clearing of stack frames for array-backed stacks for performance
// As a result, this should rarely be called! (unless the default stack frame is on)
Frame::~Frame() { /*LOG("Clearing FRAME");*/ clear(); }

void Frame::clear()
{
    reset();
    arguments.clear();
}

void Frame::reset()
{
    callingLine = -1;
    returnAddr = -1;
    nextArgIndex = 1;
}

object_ptr& Frame::operator[](const unsigned int& index)
{
    CHECK_ARGS(this, index);
    return arguments[index];
}

const object_ptr& Frame::operator[](const unsigned int& index) const
{
    CHECK_ARGS(this, index);
    return arguments[index];
}

/*void Frame::putArgument(const object_ptr& arg)
{
    if (arguments.size() == nextArgIndex)
    {
        object_ptr insertValue = make_shared<Object>();
        arguments.push_back(insertValue);
    }
    *arguments[nextArgIndex++] << *arg;
}*/

void Frame::putArgument(object_ref arg)
{
    if (arguments.size() == nextArgIndex)
    {
        object_ptr insertValue = make_shared<Object>();
        arguments.push_back(insertValue);
    }
    *arguments[nextArgIndex++] << arg;
}

void Frame::putArgumentConst(const object_ptr& arg)
{
    if (arguments.size() == nextArgIndex)
    {
        arguments.push_back(arg);
    }
    arguments[nextArgIndex++] = arg;
}

void Frame::stretch(const int_fast16_t additional_size)
{
    nextArgIndex += additional_size;
    if (arguments.size() < nextArgIndex)
    {
        int start = arguments.size();
        arguments.resize(nextArgIndex);
        for (size_t i = start; i < nextArgIndex; ++i)
        {
            arguments[i] = make_shared<Object>();
        }
    }
}

// Tuple Methods
Tuple::Tuple(object_ref value1, object_ref value2)
{
    put(value1);
    put(value2);
}

Tuple::~Tuple()
{
    LOG("Clearing TUPLE");
    tuple.clear();
}

string Tuple::toString()
{
    std::stringstream str;
    bool start = true;
    str << "(";
    for (object_ptr obj : tuple)
    {
        if (not start) str << ", ";
        else start = false;
        str << obj->dataToString();
    }
    str << ")";
    return str.str();
}

void Tuple::put(object_ref value)
{
    object_ptr insertValue = make_shared<Object>();
    *insertValue << value;
    tuple.push_back(insertValue);
}

// Chimera Virtual Machine Methods
float_c ChimeraVirtualMachine::mabs = 0.00001;
float_c ChimeraVirtualMachine::mrel = 0.00001;

ChimeraVirtualMachine::ChimeraVirtualMachine(std::ostream& out, const byte* const* const program, counter_c programSize, const byte* const lineSizes, const addr_c memorySize, IStack<Frame*>* callStack) :
silence(false),
out(out),
minMemorySize(memorySize),
memorySize(memorySize),
programMemory(program),
programSize(programSize),
lineSizes(lineSizes),
programCounter(0),
callStack(callStack),
returnLine(-1),
state(MAIN)
{
    this->nextFrame = this->callStack->allocNextPush();
    this->blocks = new Object[memorySize];
    //for (addr_c i = 0; i < memorySize; i++) this->blocks[i] = new Object;//make_shared<Object>();

    //#ifdef JIT
    //jit = make_shared<ChimeraJIT>(programSize);
    //#endif // JIT
}

ChimeraVirtualMachine::ChimeraVirtualMachine(const ChimeraVirtualMachine* main, int_c functionLine, Frame* managerCallFrame, bool global) :
out(main->out),
programMemory(main->programMemory),
programSize(main->programSize),
lineSizes(main->lineSizes)
{
    this->callStack = main->callStack->clone();
    this->memorySize = main->memorySize;
    this->blocks = global ? main->blocks : new Object[memorySize];
    if (not global)
    {
        // Bye bye performance... Recommended to use INITIAL_BLOCKS to shrink this and then increase size for main with ALLOC?
        // In that case we need to set the memorySize to minMemorySize of main... Requires a spec change for 1.1...
        //for (addr_c i = 0; i < memorySize; i++) this->blocks[i] = new Object;//make_shared<Object>();
    }
    this->returnLine = managerCallFrame->callingLine;
    this->programCounter = functionLine;
    this->nextFrame = this->callStack->allocNextPush();
    this->nextFrame->callingLine = managerCallFrame->callingLine;
    this->nextFrame->nextArgIndex = managerCallFrame->nextArgIndex-1;
    // Move arguments over (without deepcopy... We'll deal with the ramifications later. Note; taskmanager is self... bit weird, but oh well)
    this->nextFrame->arguments = managerCallFrame->arguments;
    // In addition we need to remove :1 from the frame, since it is going to conflict nastily... we can leave :0 in place without nulling it
    this->nextFrame->arguments.erase(this->nextFrame->arguments.begin() + 1);
    this->callStack->push();
    this->nextFrame = this->callStack->allocNextPush();
    this->silence = main->silence;
    this->state = global ? GLOBAL_TASK : LOCAL_TASK;
}

ChimeraVirtualMachine::~ChimeraVirtualMachine()
{
    // In DEBUG mode this becomes rather cumbersome, with 1000s of cleanup messages
    #ifndef DEBUG
    if (state != GLOBAL_TASK) delete [] this->blocks;
    delete nextFrame;
    callStack->clear();
    #endif // DEBUG
    if (state == MAIN or state == CALLBACK)
    {
        for (size_t i = 0; i < programSize; i++)
        {
            delete [] programMemory[i];
        }
        delete [] programMemory;
        delete [] lineSizes;
    }
}

int_c ChimeraVirtualMachine::parseInt(const instr_size_c start, const instr_size_c end, const byte* const line)
{
    int_c resultInt = 0;
    for (instr_size_c i = start; i < end; i++)
    {
        resultInt <<= 8;
        resultInt |= line[i];
    }
    return resultInt;
}

string ChimeraVirtualMachine::parseString(const instr_size_c start, const instr_size_c end, const byte* const line)
{
    string resultString = "";
    for (instr_size_c i = start; i < end; i++)
    {
        resultString += (char) line[i];
    }
    return resultString;
}

bool ChimeraVirtualMachine::parseBool(const instr_size_c start, const byte* const line)
{
    return line[start] == 1;
}

double ChimeraVirtualMachine::parseFloat(const instr_size_c start, const instr_size_c end, const byte* const line)
{
    float_bytes_c resultLong = 0;
    for (instr_size_c i = start; i < end; i++)
    {
        resultLong <<= 8;
        resultLong |= line[i];
    }
    float_c resultFloat;
    memcpy(&resultFloat, &resultLong, sizeof(resultLong));
    return resultFloat;
}

string chimeraFloatRepresentation(float_c f)
{
    bool sign = f < 0;
    f = fabs(f);
    unsigned long long left = static_cast<unsigned long long>(std::floor(f));
    unsigned long long right = static_cast<unsigned long long>((f-left+1)*1000000000000000l);
    string dp1 = std::to_string(right);
    string dp2 = std::to_string(right + 1);
    dp1.erase(dp1.find_last_not_of('0') + 1);
    dp2.erase(dp2.find_last_not_of('0') + 1);
    string dp = dp1.size() > dp2.size() ? dp2.substr(1) : dp1.substr(1);
    string rep = std::to_string(left) + "." + (dp.empty() ? "0" : dp);
    return (sign and rep != "0.0" ? "-" : "") + rep;
}

bool chimeraFloatEquality(const float_c f1, const float_c f2, const float_c mabs, const float_c mrel)
{
    if (fabs(f1 - f2) < mabs) return true;
    return (fabs(f2) > fabs(f1) ? fabs((f1 - f2) / f2) : fabs((f1 - f2) / f1)) <= mrel;
}

counter_c readChimeraStandardBinary(str filename, byte**& programData, byte*& lineSizes, addr_c& memory_size, IStack<Frame*>*& callStack, bool verbose)
{
    std::ifstream in(filename, std::ios::binary|std::ios::ate);
    if (verbose) cout << "Requested file " << (in.is_open() ? "is" : "is not") << " open" << endl;
    int size = 0;
    char* data;
    if (in.is_open())
    {
        size = ((int) in.tellg())-1;
        data = new char [size];
        in.seekg(0);
        in.read(data, size);
        int checkSumReceived = in.peek();

        if (data[0] == 0x73 && data[1] == 0x74 && data[2] == 0x64 && data[3] == 0x63)
        {
            if (verbose) cout << "header is good" << endl;
        }
        else
        {
            std::cerr << "Unsupported file header, expecting:\n\t73746463 (stdc)\ngot:\n\t"
          << std::hex << (int)(byte) data[0] << (int)(byte) data[1] << (int)(byte) data[2] << (int)(byte) data[3] << std::dec
                      << " (" << data[0] << data[1] << data[2] << data[3] << ")";
            std::exit(1);
        }

        // Read 4 bytes, check if it is the endp marker, if not, roll back and read a directive
        int readPos = 4;
        int checkSum = 430 + 423;
        byte b;
        instr_size_c length;
        int_c resultInt;
        instr_size_c i;

        while(data[readPos] != 0x65 or data[readPos+1] != 0x6E or data[readPos+2] != 0x64 or data[readPos+3] != 0x70)
        {
            b = data[readPos++];
            checkSum += b;
            PreprocessorDirective dir = (PreprocessorDirective) b;
            switch(dir)
            {
            case PreprocessorDirective::INITIAL_MEMORY_BLOCKS:
                LOG("Changing initial memory blocks");
                b = data[readPos++];
                checkSum += b;
                length = b;
                resultInt = 0;
                for (i = 0; i < length; i++)
                {
                    resultInt <<= 8;
                    b = data[readPos++];
                    checkSum += b;
                    resultInt |= b;
                }
                memory_size = resultInt;
                break;
            case PreprocessorDirective::RECURSION_DEPTH:
                LOG("Setting recursion depth");
                b = data[readPos++];
                checkSum += b;
                length = b;
                resultInt = 0;
                for (i = 0; i < length; i++)
                {
                    resultInt <<= 8;
                    b = data[readPos++];
                    checkSum += b;
                    resultInt |= b;
                }
                delete callStack;
                callStack = new ArrayStack<Frame*>(resultInt);
                break;
            case PreprocessorDirective::RECURSION_DEPTH_UNBOUNDED:
                LOG("Setting recursion depth (unbounded)");
                b = data[readPos++];
                checkSum += b;
                length = b;
                resultInt = 0;
                for (i = 0; i < length; i++)
                {
                    resultInt <<= 8;
                    b = data[readPos++];
                    checkSum += b;
                    resultInt |= b;
                }
                delete callStack;
                callStack = new ResizableArrayStack<Frame*>(resultInt);
                break;
            default:
                break;
            }
        }
        readPos += 4;

        size_t sizeOfLine;
        counter_c sizeOfProgram = ((byte) data[readPos]) << 8 | ((byte) data[readPos+1]);
        checkSum += data[readPos] + data[readPos+1];
        readPos += 2;
        int readUntil;
        programData = new byte*[sizeOfProgram];
        lineSizes = new byte[sizeOfProgram];
        for (size_t i = 0; readPos < size; ++i)
        {
            // First we read a byte
            #ifdef DEBUG_FILE
            cout << "next line is " << std::dec << (int)(byte) data[readPos] << " bytes long" << endl;
            #endif // DEBUG_FILE
            sizeOfLine = (size_t)(byte)data[readPos];
            checkSum += sizeOfLine;
            readUntil = sizeOfLine + readPos;
            readPos++;
            byte*& line = programData[i];
            line = new byte[sizeOfLine];
            lineSizes[i] = sizeOfLine;
            for (size_t j = 0; readPos <= readUntil; ++j, ++readPos)
            {
                #ifdef DEBUG_FILE
                cout << std::hex << (int)(byte)data[readPos] << ' ';
                #endif // DEBUG_FILE
                b = data[readPos];
                line[j] = b;
                checkSum += b;
            }
            #ifdef DEBUG_FILE
            cout << endl;
            #endif // DEBUG_FILE
            #ifdef DEBUG_FILE
            Sleep(100);
            #endif // DEBUG_FILE
        }
        if (checkSum%256 != checkSumReceived)
        {
            cout << "check-sum is bad, possible corruption. expecting:\n\t"
                 << std::hex << checkSumReceived
                 << "\ngot:\n\t" << checkSum % 256 << std::dec << "\n"
                 << "It would be potentially dangerous to execute this program, terminating" << endl;
            exit(1);
        }
        else if (verbose) cout << "check-sum is good" << endl;
        if (verbose) cout << "done reading file" << endl;
        delete data;
        return sizeOfProgram;
    }
    else
    {
        throw std::runtime_error(string("\n\ncouldn't read file: ") + filename);
    }
    std::cout << std::dec;
}

// Macro accompaniers
#ifdef RUNTIME_CHECKS
void _CHECK_TYPE(object_cref obj, char t)
{
    if (obj.type != t)
    {
        std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int) obj.type << " != " << t << endl;
        exit(1);
    }
}

void _CHECK_ARGS(const Frame* frame, const uint_fast32_t numargs)
{
    if (frame->nextArgIndex <= numargs)
    {
        std::cerr << "FAILED RUNTIME ARGS CHECK: " << "Not enough arguments for function, " << numargs << " required got " << ((int) frame->nextArgIndex)-1 << endl;
        exit(1);
    }
}
#endif // RUNTIME_CHECKS
