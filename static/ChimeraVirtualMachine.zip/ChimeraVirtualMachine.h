#ifndef CHIMERA_VIRTUAL_MACHINE_HEADER
#define CHIMERA_VIRTUAL_MACHINE_HEADER
#include <algorithm>
#include <chrono>
#include <cstring>
#include <deque>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <map>
#include <sstream>
#include <string>
#include <thread>
#include <unordered_set>
#include <unordered_map>
#include "DataStructures.h"

//#define DEBUG
#define RUNTIME_CHECKS
//#define DEBUG_FILE
//#define JIT
#define CYCLIC_GC
//#define JIT_SAFE_STACK
#define STACK_SIZE 1045000
#ifdef DEBUG
#define LOG(message) cout << message << endl
#define PLOG(message) LOG(message)
#define Sleep(ms) std::this_thread::sleep_for(std::chrono::milliseconds(ms))
#define SLEEP_TIME 0
#else
#define LOG(message)
#define PLOG(message) std::cerr << message << endl
#endif //DEBUG
#define unused(var) (void)(var)

//extern std::ofstream logFile;

using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::deque;
using std::unordered_map;
using std::make_shared;

struct Object;
struct Frame;
struct Tuple;

class ChimeraVirtualMachine;
class ChimeraObject;
class ChimeraStandardLibrary;
class ChimeraList;
class IChimeraStandardLibraryObject;
class ChimeraJIT;

// The size of a Chimera int
typedef int32_t int_c;
// The size of a Chimera float
typedef double float_c;
// The size of a Chimera bool
typedef bool bool_c;
// Type of a Chimera object
typedef ChimeraObject* object_c;
// Type of a Chimera string
typedef string* string_c;
// Type of a Chimera tuple
typedef Tuple* tuple_c;
// This should match float_c (i.e. if float_c = float then uint32_t else uint64_t
typedef uint_fast64_t float_bytes_c;
// Maximum lines of code allowed
typedef uint_fast16_t counter_c;
// Maximum size of an instruction
typedef size_t instr_size_c;
// Maximum size of blocks
typedef uint_fast64_t addr_c;
// Maximum number of object_ptrs
typedef uint_fast32_t id_c;
// Maximum number of times an object can be referenced
typedef uint_fast32_t ref_c;

typedef uint_fast8_t byte;
typedef const char* str;
typedef std::shared_ptr<Object> object_ptr;
typedef Object* object_uptr;
typedef Object& object_ref;
typedef const Object& object_cref;
typedef std::shared_ptr<ChimeraJIT> jit_ptr;
typedef std::shared_ptr<ChimeraVirtualMachine> vm_ptr;
typedef const object_ptr (*method)(IChimeraStandardLibraryObject*, Frame* const);
typedef union MethodOrInt
{
    counter_c i; method m;
} MethodOrInt;

#ifdef RUNTIME_CHECKS
#define CHECK_TYPE(obj, t) _CHECK_TYPE(obj, Object::t)
#define CHECK_ARGS(frame, numargs) _CHECK_ARGS(frame, numargs)
void _CHECK_TYPE(object_cref obj, char t);
void _CHECK_ARGS(const Frame* frame, const uint_fast32_t numargs);
#else
#define CHECK_TYPE(obj, t)
#define CHECK_ARGS(numargs, index)
#endif // RUNTIME_CHECKS

counter_c readChimeraStandardBinary(str filename, byte**& programData, byte*& lineSizes, addr_c& memorySize, IStack<Frame*>*& callStack, bool verbose);
string chimeraFloatRepresentation(float_c f);

struct Object
{
    enum {NOTYPE, INT, FLOAT, BOOL, STRING, OBJECT, TUPLE};
    static id_c objectId;
    id_c id, uid;
    char type;
    union {int_c i; float_c f; string_c s; bool_c b; object_c o; tuple_c t;} data;
    bool preserve;

    explicit Object();
    explicit Object(Object* that);
    ~Object();

    friend void operator<<(object_ref o1, object_ref o2);
    friend bool operator==(const object_ref o1, const object_ptr& o2);
    friend bool operator==(const object_ptr& o1, const object_ptr& o2);

    string dataToString() const;
    string typeToString() const;

    void print() const;

    void readyOverwrite();
    static object_ptr make(int_c i);
    static object_ptr make(float_c f);
    static object_ptr make(bool_c b);
    static object_ptr make(const char* s);
    static object_ptr make(string_c s);
    static object_ptr make(object_c o);
};

struct string_fast_compare
{
    bool operator()(const string& lhs, const string& rhs) const
    {
        return lhs.length() != rhs.length() ? lhs.length() < rhs.length() : memcmp(lhs.c_str(), rhs.c_str(), lhs.length()) < 0;
    }
};

class ChimeraObject
{
protected:
    std::map<string, Object, string_fast_compare> attributes;
    std::map<string, MethodOrInt, string_fast_compare> methods;

private:
    id_c id;
    string tag;
    ref_c references;
#ifdef CYCLIC_GC
    ref_c objectReferences;
    id_c index;
    id_c lowlink;
    bool onStack;
    uint64_t linkState; //init to 0, if gc is needed linkCount can't be 0 except on overflow, so least likely collision
    std::unordered_map<object_c, ref_c>::const_iterator iter;
    std::unordered_map<object_c, ref_c> succs;
    std::unordered_set<object_c> preds;
#endif //CYCLIC_GC

public:
    static id_c objectId;
#ifdef CYCLIC_GC
    static uint64_t linkCount;
#endif //CYCLIC_GC

    ChimeraObject();
    ChimeraObject(const string name);
    virtual ~ChimeraObject();

    id_c& getId();
    string& getTag();

    void acquire();
    void release();

    #ifdef CYCLIC_GC
    void link(object_c obj);
    void unlink(object_c obj);

    void runGarbage();
    void tarjan(vector<vector<object_c>>& cycles, vector<object_c>& noncyclic);
    #endif // CYCLIC_GC

    void putAttribute(const string& name, object_ref value);
    object_ref getAttribute(const string& name);
    bool hasAttribute(const string& name);
    virtual void putMethod(const string& name, MethodOrInt startLine);
    bool hasMethod(const string& name);
    MethodOrInt getMethod(const string& name);
    virtual object_c deepCopy(bool recursive);
};

namespace std
{
    template <> struct hash<object_ptr>
    {
        size_t operator()(const object_ptr& o) const
        {
            size_t h = 0;
            switch(o->type)
            {
            case Object::INT: h += std::hash<long>()(o->data.i); break;
            case Object::FLOAT: h += std::hash<double>()(o->data.f); break;
            case Object::BOOL: h += std::hash<bool>()(o->data.b); break;
            case Object::STRING: h += std::hash<string>()(*(o->data.s)); break;
            case Object::OBJECT: h += std::hash<int>()(o->data.o->getId()); break;
            case Object::TUPLE: std::cerr << "TupleViolationException: Cannot hash tuples" << endl; exit(1);
            default: break;
            }
            return (h << 3) | (int) o->type;
        }
    };

    template <> struct equal_to<object_ptr>
    {
        bool operator()(const object_ptr& o1, const object_ptr& o2) const { return o1 == o2; }
    };
}

struct Frame
{
    counter_c callingLine;
    bool returnIntoBlock;
    addr_c returnAddr;
    vector<object_ptr> arguments;
    uint32_t nextArgIndex;

    Frame();
    ~Frame();

    void clear();
    void reset();

    object_ptr& operator[](const unsigned int& index);
    const object_ptr& operator[](const unsigned int& index) const;

    //void putArgument(const object_ptr& arg);
    void putArgument(object_ref arg);
    void putArgumentConst(const object_ptr& arg);

    void stretch(const int_fast16_t additional_size);
};

struct Tuple
{
    deque<object_ptr> tuple;

    Tuple(object_ref value1, object_ref value2);
    ~Tuple();
    string toString();
    void put(object_ref value);
};

class ChimeraVirtualMachine
{
    friend class ChimeraJIT;
    friend class ctx_t;
    friend class IChimeraStandardLibraryObject;
    friend class ChimeraUtils;
    friend class ChimeraScopeObject;
    friend class ChimeraTable;
    friend class ChimeraKeyedTable;
    friend class ChimeraStack;
    friend class ChimeraTaskManager;
    typedef enum {MAIN, CALLBACK, LOCAL_TASK, GLOBAL_TASK} VMState;
public:
    static const int DEFAULT_MEMORY_SIZE = 1000;
    static float_c mabs;
    static float_c mrel;

private:
    static const byte BLOCK = 0xFF;
    static const byte POINTER = 0xFE;
    static const byte ARGUMENT = 0xFD;
    static const instr_size_c LONG_ADDR_LENGTH = 4;

    bool silence;
    std::ostream& out;
    Object* blocks;
    addr_c minMemorySize;
    addr_c memorySize;
    bool_c compare;
    const byte* const* const programMemory;
    const counter_c programSize;
    const byte* const lineSizes;
    #ifdef JIT
    jit_ptr jit;
    #endif // JIT
    counter_c programCounter;
    IStack<Frame*>* callStack; //safe to keep pointer
    Frame* nextFrame; //safe to keep pointer

    counter_c returnLine;
    VMState state;

public:
    ChimeraVirtualMachine(std::ostream& out,
                          const byte* const* const program,
                          counter_c programSize,
                          const byte* const lineSizes,
                          const addr_c memorySize = DEFAULT_MEMORY_SIZE,
                          IStack<Frame*>* callStack = new LinkedStack<Frame*>());
    ChimeraVirtualMachine(const ChimeraVirtualMachine* main, int_c functionLine, Frame* managerCallFrame, bool global);
    ~ChimeraVirtualMachine();

    Object interpret(bool silence);
    template <typename... Args> Object callback(counter_c functionRef, bool silence, Args... args);
    int_c parseInt(const instr_size_c start, const instr_size_c end, const byte* const line);
    string parseString(const instr_size_c start, const instr_size_c end, const byte* const line);
    bool_c parseBool(const instr_size_c start, const byte* const line);
    float_c parseFloat(const instr_size_c start, const instr_size_c end, const byte* const line);
};

bool chimeraFloatEquality(const float_c f1, const float_c f2,
                          const float_c mabs = ChimeraVirtualMachine::mabs,
                          const float_c mrel = ChimeraVirtualMachine::mrel);

template <typename... Arg> Object ChimeraVirtualMachine::callback(counter_c functionRef, bool silence, Arg... args)
{
    LOG("Callback triggered for line @" << functionRef);
    object_ptr* callerSave = nullptr;
    const addr_c numargs = nextFrame->nextArgIndex-1;
    if (numargs > 0)
    {
        // We need to do caller save
        LOG("Performing caller-save on " << numargs << " arguments");
        callerSave = new object_ptr[numargs];
        for (addr_c i = 0; i < numargs; i++)
        {
            callerSave[i] = make_shared<Object>();
            *callerSave[i] << *(*nextFrame)[i+1];
            LOG("Argument #" << i+1 << ": " << callerSave[i]->dataToString());
        }
        nextFrame->reset();
    }

    // Save program counter and returnLine
    const counter_c oldProgramCounter = programCounter;
    const counter_c oldReturnLine = returnLine;

    // Setup frame and vm for push
    vector<object_ptr> newArgs = {args...};
    for (object_ptr arg : newArgs)
    {
        nextFrame->putArgumentConst(arg);
    }
    returnLine = nextFrame->callingLine = programCounter;
    callStack->push();
    nextFrame = callStack->allocNextPush();

    // Perform callback (after, nextFrame is the original frame we started with)
    programCounter = functionRef;
    Object result = interpret(silence);

    // Restore state
    nextFrame->reset();
    returnLine = oldReturnLine;
    programCounter = oldProgramCounter;

    if (numargs > 0)
    {
        LOG("Restoring caller-saved arguments");
        nextFrame->nextArgIndex += numargs;
        for (addr_c i = 0; i < numargs; i++)
        {
            LOG("Argument #" << i+1 << ": " << callerSave[i]->dataToString());
            (*nextFrame)[i+1] = callerSave[i];
        }
        delete [] callerSave;
    }
    return result;
}
#endif // CHIMERA_VIRTUAL_MACHINE_HEADER
