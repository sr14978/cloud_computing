#include "ChimeraVirtualMachine.h"
#include "ChimeraJIT.h"
#include "ChimeraStandardLibrary.h"
#define args (*callStack->peek())

#ifdef JIT
// This variable allows us to approximate the stack size of the program, allowing us to early exit the CET chain
size_t tos;
#endif // JIT

enum class Instruction {ADD, SUB, MULT, DIV,
                        ADDI, SUBI, MULTI, DIVI, INC, DEC, ADDF, SUBF, MULTF, DIVF,
                        EQ, LEQ, LT, NEQ, EQI, LEQI, LTI, NEQI, CMP,
                        NOT, AND, OR, EQB, XOR, IMPLIES, NAND, NOR,
                        ADDS, MULTS, ORD, CHAR,
                        STOREINT, STOREFLOAT, STORESTRING, STOREBOOL, COPY, SWAP, ALLOC, DEALLOC,
                        JUMP, JCMP, JNC, JNQZ, JNEG, JMPT,
                        CALL, RETURN, PUTARG, PACK, UNPACK,
                        DEREFL, DEREFS, STRETCH,
                        NEW, PUTATTR, PULLATTR, PUTMETHOD, INVOKE,
                        PRINT, END};

Object ChimeraVirtualMachine::interpret(bool silence)
{
    #ifdef JIT
    int tos_intr = 0;
    tos = (size_t) &tos_intr;
    #endif // JIT
    this->silence = silence;
    int_c startTime = 0;
    if (not silence)
    {
        cout << "Program started" << endl;
        nextFrame->returnAddr = -1;
        startTime = ChimeraUtils::time(nullptr, nextFrame)->data.i;
    }
    while(true)
    {
        LOG('@' << programCounter);
        const byte* const line = programMemory[programCounter];
        const byte lineSize = lineSizes[programCounter];
        #undef JIT
        #ifdef JIT
        if (jit->instructions[programCounter].enabled)
        {
            jit->instructions[programCounter].instr(&jit->instructions[programCounter], jit->instructions, this);
            continue;
        }
        ctx_t& ctx = jit->instructions[programCounter];
        //ctx.enabled = true; // This can be reenabled when all instructions are in jit?
        ctx.next = programCounter+1;
        #endif // JIT

        Instruction instr = (Instruction) line[0];
        #ifdef DEBUG
        for (size_t i = 0; i < lineSize; ++i)
        {
            cout << std::hex << (int) line[i] << ' ';
        }
        cout << std::dec << endl;
        #endif // DEBUG

        switch(instr)
        {
        case Instruction::ADDI:
        case Instruction::SUBI:
        case Instruction::MULTI:
        case Instruction::DIVI:
        {
            instr_size_c length1 = line[3];
            int_c a;
            switch(length1)
            {
            case BLOCK:
            {
                object_cref block = blocks[line[4]];
                switch(block.type)
                {
                case Object::INT: a = block.data.i; break;
                case Object::FLOAT: a = (int_c) block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                PUT_CTX(addr2, line[4]);
                //ctx.mode2 = 1;
                length1 = 1; break;
            }
            case POINTER:
            {
                object_cref block = blocks[blocks[line[4]].data.i];
                switch(block.type)
                {
                case Object::INT: a = block.data.i; break;
                case Object::FLOAT: a = (int_c) block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                PUT_CTX(addr2, line[4]);
                //ctx.mode2 = 2;
                length1 = 1; break;
            }
            case ARGUMENT:
            {
                object_cref block = *args[line[4]];
                switch(block.type)
                {
                case Object::INT: a = block.data.i; break;
                case Object::FLOAT: a = (int_c) block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                PUT_CTX(addr2, line[4]);
                length1 = 1; break;
            }
            default:
                a = 0;
                for (instr_size_c i = 4; i < length1 + 4; i++)
                {
                    a <<= 8;
                    a |= line[i];
                }
                PUT_CTX(x, a);
                break;
            }
            instr_size_c length2 = line[4 + length1];
            int_c b;
            switch(length2)
            {
            case BLOCK:
            {
                object_cref block = blocks[line[5 + length1]];
                switch(block.type)
                {
                case Object::INT: b = block.data.i; break;
                case Object::FLOAT: b = (int_c) block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                PUT_CTX(addr3, line[5+length1]);
                //ctx.mode3 = 1;
                break;
            }
            case POINTER:
            {
                object_cref block = blocks[blocks[line[5 + length1]].data.i];
                switch(block.type)
                {
                case Object::INT: b = block.data.i; break;
                case Object::FLOAT: b = (int_c) block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                PUT_CTX(addr3, line[5+length1]);
                //ctx.mode3 = 2;
                break;
            }
            case ARGUMENT:
            {
                object_cref block = *args[line[5 + length1]];
                switch(block.type)
                {
                case Object::INT: b = block.data.i; break;
                case Object::FLOAT: b = (int_c) block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                PUT_CTX(addr3, line[5+length1]);
                break;
            }
            default:
                b = 0;
                for (instr_size_c i = 5 + length1; i < length2 + length1 + 5; i++)
                {
                    b <<= 8;
                    b |= line[i];
                }
                PUT_CTX(y, b);
                break;
            }
            switch(line[1])
            {
            case BLOCK:
                blocks[line[2]].readyOverwrite();
                switch(instr)
                {
                case Instruction::ADDI: LOG("ADDI"); /*ctx.instr = ChimeraJIT::jaddi; ctx.enabled = true;*/ blocks[line[2]].data.i = a + b; break;
                case Instruction::SUBI: LOG("SUBI"); blocks[line[2]].data.i = a - b; break;
                case Instruction::MULTI: LOG("MULTI"); /*ctx.instr = ChimeraJIT::jmulti; ctx.enabled = true;*/ blocks[line[2]].data.i = a * b; break;
                case Instruction::DIVI: LOG("DIVI"); blocks[line[2]].data.i = a / b; break;
                default: break;
                }
                blocks[line[2]].type = Object::INT;
                PUT_CTX(addr1, line[2]);
                //ctx.mode1 = 1;
                switch(line[3])
                {
                case BLOCK:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 7); break;
                    case POINTER: SET_ARITHI(instr, 8); break;
                    case ARGUMENT: SET_ARITHI(instr, 9); break;
                    default: SET_ARITHI(instr, 6); break;
                    }
                    break;
                case POINTER:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 12); break;
                    case POINTER: SET_ARITHI(instr, 13); break;
                    case ARGUMENT: SET_ARITHI(instr, 14); break;
                    default: SET_ARITHI(instr, 11); break;
                    }
                    break;
                case ARGUMENT:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 17); break;
                    case POINTER: SET_ARITHI(instr, 18); break;
                    case ARGUMENT: SET_ARITHI(instr, 19); break;
                    default: SET_ARITHI(instr, 16); break;
                    }
                    break;
                default:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 2); break;
                    case POINTER: SET_ARITHI(instr, 3); break;
                    case ARGUMENT: SET_ARITHI(instr, 4); break;
                    default: SET_ARITHI(instr, 1); break;
                    }
                    break;
                }
                break;
            case POINTER:
                blocks[blocks[line[2]].data.i].readyOverwrite();
                switch(instr)
                {
                case Instruction::ADDI: LOG("ADDI"); blocks[blocks[line[2]].data.i].data.i = a + b; break;
                case Instruction::SUBI: LOG("SUBI"); blocks[blocks[line[2]].data.i].data.i = a - b; break;
                case Instruction::MULTI: LOG("MULTI"); blocks[blocks[line[2]].data.i].data.i = a * b; break;
                case Instruction::DIVI: LOG("DIVI"); blocks[blocks[line[2]].data.i].data.i = a / b; break;
                default: break;
                }
                blocks[blocks[line[2]].data.i].type = Object::INT;
                PUT_CTX(addr1, line[2]);
                switch(line[3])
                {
                case BLOCK:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 32); break;
                    case POINTER: SET_ARITHI(instr, 33); break;
                    case ARGUMENT: SET_ARITHI(instr, 34); break;
                    default: SET_ARITHI(instr, 31); break;
                    }
                    break;
                case POINTER:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 37); break;
                    case POINTER: SET_ARITHI(instr, 38); break;
                    case ARGUMENT: SET_ARITHI(instr, 39); break;
                    default: SET_ARITHI(instr, 36); break;
                    }
                    break;
                case ARGUMENT:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 42); break;
                    case POINTER: SET_ARITHI(instr, 43); break;
                    case ARGUMENT: SET_ARITHI(instr, 44); break;
                    default: SET_ARITHI(instr, 41); break;
                    }
                    break;
                default:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 27); break;
                    case POINTER: SET_ARITHI(instr, 28); break;
                    case ARGUMENT: SET_ARITHI(instr, 29); break;
                    default: SET_ARITHI(instr, 26); break;
                    }
                    break;
                }
                break;
            case ARGUMENT:
                args[line[2]]->readyOverwrite();
                switch(instr)
                {
                case Instruction::ADDI: LOG("ADDI"); args[line[2]]->data.i = a + b; break;
                case Instruction::SUBI: LOG("SUBI"); args[line[2]]->data.i = a - b; break;
                case Instruction::MULTI: LOG("MULTI"); args[line[2]]->data.i = a * b; break;
                case Instruction::DIVI: LOG("DIVI"); args[line[2]]->data.i = a / b; break;
                default: break;
                }
                args[line[2]]->type = Object::INT;
                PUT_CTX(addr1, line[2]);
                switch(line[3])
                {
                case BLOCK:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 57); break;
                    case POINTER: SET_ARITHI(instr, 58); break;
                    case ARGUMENT: SET_ARITHI(instr, 59); break;
                    default: SET_ARITHI(instr, 56); break;
                    }
                    break;
                case POINTER:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 62); break;
                    case POINTER: SET_ARITHI(instr, 63); break;
                    case ARGUMENT: SET_ARITHI(instr, 64); break;
                    default: SET_ARITHI(instr, 61); break;
                    }
                    break;
                case ARGUMENT:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 67); break;
                    case POINTER: SET_ARITHI(instr, 68); break;
                    case ARGUMENT: SET_ARITHI(instr, 69); break;
                    default: SET_ARITHI(instr, 66); break;
                    }
                    break;
                default:
                    switch(line[4 + length1])
                    {
                    case BLOCK: SET_ARITHI(instr, 52); break;
                    case POINTER: SET_ARITHI(instr, 53); break;
                    case ARGUMENT: SET_ARITHI(instr, 54); break;
                    default: SET_ARITHI(instr, 51); break;
                    }
                    break;
                }
                break;
            default: break;
            }
            break;
        }
        case Instruction::ADDF:
        case Instruction::SUBF:
        case Instruction::MULTF:
        case Instruction::DIVF:
        {
            instr_size_c length1 = line[3];
            float_c c;
            switch(length1)
            {
            case BLOCK:
            {
                object_cref block = blocks[line[4]];
                switch(block.type)
                {
                case Object::INT: c = (float_c) block.data.i; break;
                case Object::FLOAT: c = block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                length1 = 1; break;
            }
            case POINTER:
            {
                object_cref block = blocks[blocks[line[4]].data.i];
                switch(block.type)
                {
                case Object::INT: c = (float_c) block.data.i; break;
                case Object::FLOAT: c = block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                length1 = 1; break;
            }
            case ARGUMENT:
            {
                object_cref block = *args[line[4]];
                switch(block.type)
                {
                case Object::INT: c = (float_c) block.data.i; break;
                case Object::FLOAT: c = block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                length1 = 1; break;
            }
            default:
                float_bytes_c resultLong = 0;
                for (instr_size_c i = 4; i < length1 + 4; i++)
                {
                    resultLong <<= 8;
                    resultLong |= line[i];
                }
                memcpy(&c, &resultLong, sizeof(resultLong));
                break;
            }
            instr_size_c length2 = line[4 + length1];
            float_c d;
            switch(length2)
            {
            case BLOCK:
            {
                object_cref block = blocks[line[5 + length1]];
                switch(block.type)
                {
                case Object::INT: d = (float_c) block.data.i; break;
                case Object::FLOAT: d = block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                break;
            }
            case POINTER:
            {
                object_cref block = blocks[blocks[line[5 + length1]].data.i];
                switch(block.type)
                {
                case Object::INT: d = (float_c) block.data.i; break;
                case Object::FLOAT: d = block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                break;
            }
            case ARGUMENT:
            {
                object_cref block = *args[line[5 + length1]];
                switch(block.type)
                {
                case Object::INT: d = (float_c) block.data.i; break;
                case Object::FLOAT: d = block.data.f; break;
                default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                }
                break;
            }
            default:
                float_bytes_c resultLong = 0;
                for (instr_size_c i = 5 + length1; i < length2 + length1 + 5; i++)
                {
                    resultLong <<= 8;
                    resultLong |= line[i];
                }
                memcpy(&d, &resultLong, sizeof(resultLong));
                break;
            }
            switch(instr)
            {
            case Instruction::ADDF: LOG("ADDF");
                switch(line[1])
                {
                case BLOCK:
                    blocks[line[2]].readyOverwrite();
                    blocks[line[2]].data.f = c + d;
                    blocks[line[2]].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[line[2]].data.i].readyOverwrite();
                    blocks[blocks[line[2]].data.i].data.f = c + d;
                    blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    args[line[2]]->data.f = c + d;
                    args[line[2]]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            case Instruction::SUBF: LOG("SUBF");
                switch(line[1])
                {
                case BLOCK:
                    blocks[line[2]].readyOverwrite();
                    blocks[line[2]].data.f = c - d;
                    blocks[line[2]].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[line[2]].data.i].readyOverwrite();
                    blocks[blocks[line[2]].data.i].data.f = c - d;
                    blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    args[line[2]]->data.f = c - d;
                    args[line[2]]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            case Instruction::MULTF: LOG("MULTF");
                switch(line[1])
                {
                case BLOCK:
                    blocks[line[2]].readyOverwrite();
                    blocks[line[2]].data.f = c * d;
                    blocks[line[2]].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[line[2]].data.i].readyOverwrite();
                    blocks[blocks[line[2]].data.i].data.f = c * d;
                    blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    args[line[2]]->data.f = c * d;
                    args[line[2]]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            case Instruction::DIVF: LOG("DIVF");
                switch(line[1])
                {
                case BLOCK:
                    blocks[line[2]].readyOverwrite();
                    blocks[line[2]].data.f = c / d;
                    blocks[line[2]].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[line[2]].data.i].readyOverwrite();
                    blocks[blocks[line[2]].data.i].data.f = c / d;
                    blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    args[line[2]]->data.f = c / d;
                    args[line[2]]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            default: break;
            }
            break;
        }
        case Instruction::ADDS:
        {
            LOG("ADDS");
            instr_size_c length1 = line[3];
            string resultString1;
            switch (length1)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[4]], STRING);
                resultString1 = *blocks[line[4]].data.s; length1 = 1; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[4]].data.i], STRING);
                resultString1 = *blocks[blocks[line[4]].data.i].data.s; length1 = 1; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[4]], STRING);
                resultString1 = *args[line[4]]->data.s; length1 = 1; break;
            default:
                resultString1 = "";
                for (instr_size_c i = 4; i < length1 + 4; i++) resultString1 += line[i];
                break;
            }
            instr_size_c length2 = line[4 + length1];
            string resultString2;
            switch (length2)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[5 + length1]], STRING);
                resultString2 = *blocks[line[5 + length1]].data.s; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[5 + length1]].data.i], STRING);
                resultString2 = *blocks[blocks[line[5 + length1]].data.i].data.s; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[5 + length1]], STRING);
                resultString2 = *args[line[5 + length1]]->data.s; break;
            default:
                resultString2 = "";
                for (instr_size_c i = 5 + length1; i < length1 + length2 + 5; i++) resultString2 += line[i];
                break;
            }
            switch(line[1])
            {
            case BLOCK:
                blocks[line[2]].readyOverwrite();
                blocks[line[2]].data.s = new string(resultString1 + resultString2);
                blocks[line[2]].type = Object::STRING;
                break;
            case POINTER:
                blocks[blocks[line[2]].data.i].readyOverwrite();
                blocks[blocks[line[2]].data.i].data.s = new string(resultString1 + resultString2);
                blocks[blocks[line[2]].data.i].type = Object::STRING;
                break;
            case ARGUMENT:
                args[line[2]]->readyOverwrite();
                args[line[2]]->data.s = new string(resultString1 + resultString2);
                args[line[2]]->type = Object::STRING;
                break;
            default: break;
            }
            break;
        }
        case Instruction::MULTS:
        {
            LOG("MULTS");
            instr_size_c length1 = line[3];
            string resultString1;
            switch (length1)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[4]], STRING);
                resultString1 = *blocks[line[4]].data.s; length1 = 1; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[4]].data.i], STRING);
                resultString1 = *blocks[blocks[line[4]].data.i].data.s; length1 = 1; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[4]], STRING);
                resultString1 = *args[line[4]]->data.s; length1 = 1; break;
            default:
                resultString1 = "";
                for (instr_size_c i = 4; i < length1 + 4; i++) resultString1 += line[i];
                break;
            }
            instr_size_c length2 = line[4 + length1];
            int_c resultInt;
            switch (length2)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[5 + length1]], INT);
                resultInt = blocks[line[5 + length1]].data.i; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[5 + length1]].data.i], INT);
                resultInt = blocks[blocks[line[5 + length1]].data.i].data.i; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[5 + length1]], INT);
                resultInt = args[line[5 + length1]]->data.i; break;
            default:
                resultInt = 0;
                for (instr_size_c i = 5 + length1; i < length1 + length2 + 5; i++)
                {
                    resultInt <<= 8;
                    resultInt |= line[i];
                }
                break;
            }
            std::ostringstream builder;
            for (int_c i = 0; i < resultInt; i++) builder << resultString1;
            string resultString2 = builder.str();
            switch(line[1])
            {
            case BLOCK:
                blocks[line[2]].readyOverwrite();
                blocks[line[2]].data.s = new string(resultString2);
                blocks[line[2]].type = Object::STRING;
                break;
            case POINTER:
                blocks[blocks[line[2]].data.i].readyOverwrite();
                blocks[blocks[line[2]].data.i].data.s = new string(resultString2);
                blocks[blocks[line[2]].data.i].type = Object::STRING;
                break;
            case ARGUMENT:
                args[line[2]]->readyOverwrite();
                args[line[2]]->data.s = new string(resultString2);
                args[line[2]]->type = Object::STRING;
                break;
            default: break;
            }
            break;
        }
        case Instruction::ORD:
        {
            LOG("ORD");
            string resultString1;
            switch (line[3])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[4]], STRING);
                resultString1 = *blocks[line[4]].data.s; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[4]].data.i], STRING);
                resultString1 = *blocks[blocks[line[4]].data.i].data.s; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[4]], STRING);
                resultString1 = *args[line[4]]->data.s; break;
            default:
                resultString1 = "";
                resultString1 += line[4];
            }
            switch (line[1])
            {
            case BLOCK:
                blocks[line[2]].readyOverwrite();
                blocks[line[2]].data.i = (int_c) resultString1[0];
                blocks[line[2]].type = Object::INT;
                break;
            case POINTER:
                blocks[blocks[line[2]].data.i].readyOverwrite();
                blocks[blocks[line[2]].data.i].data.i = (int_c) resultString1[0];
                blocks[blocks[line[2]].data.i].type = Object::INT;
                break;
            case ARGUMENT:
                args[line[2]]->readyOverwrite();
                args[line[2]]->data.i = (int_c) resultString1[0];
                args[line[2]]->type = Object::INT;
                break;
            default: break;
            }
            break;
        }
        case Instruction::CHAR:
        {
            LOG("CHAR");
            instr_size_c length1 = line[3];
            int_c resultInt;
            switch (length1)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[4]], INT);
                resultInt = blocks[line[4]].data.i; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[4]].data.i], INT);
                resultInt = blocks[blocks[line[4]].data.i].data.i; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[4]], INT);
                resultInt = args[line[4]]->data.i; break;
            default:
                resultInt = 0;
                for (instr_size_c i = 4; i < length1 + 4; i++)
                {
                    resultInt <<= 8;
                    resultInt |= line[i];
                }
            }
            string resultString1 = "";
            resultString1 += resultInt;
            switch (line[1])
            {
            case BLOCK:
                blocks[line[2]].readyOverwrite();
                blocks[line[2]].data.s = new string(resultString1);
                blocks[line[2]].type = Object::STRING;
                break;
            case POINTER:
                blocks[blocks[line[2]].data.i].readyOverwrite();
                blocks[blocks[line[2]].data.i].data.s = new string(resultString1);
                blocks[blocks[line[2]].data.i].type = Object::STRING;
                break;
            case ARGUMENT:
                args[line[2]]->readyOverwrite();
                args[line[2]]->data.s = new string(resultString1);
                args[line[2]]->type = Object::STRING;
                break;
            default: break;
            }
            break;
        }
        case Instruction::CALL:
        {
            LOG("CALL");
            counter_c call = line[1] << 8 | line[2];
            nextFrame->callingLine = programCounter+1;
            int_fast16_t control = line[3];
            PUT_CTX(x, control);
            if (control > 0) nextFrame->stretch(control);
            if (lineSize > 4)
            {
                switch (line[4])
                {
                case BLOCK:
                    nextFrame->returnAddr = line[5];
                    nextFrame->returnIntoBlock = true;
                    PUT_CTX(addr1, line[5]); SET_INSTR(jcall2);
                    break;
                case POINTER:
                    CHECK_TYPE(blocks[line[5]], INT);
                    nextFrame->returnIntoBlock = true;
                    nextFrame->returnAddr = blocks[line[5]].data.i;
                    PUT_CTX(addr1, line[5]); SET_INSTR(jcall3);
                    break;
                case ARGUMENT:
                    nextFrame->returnAddr = line[5];
                    nextFrame->returnIntoBlock = false;
                    PUT_CTX(addr1, line[5]); SET_INSTR(jcall4);
                    break;
                default: SET_INSTR(jcall1); break;
                }
            }
            callStack->push();
            nextFrame = callStack->allocNextPush();
            programCounter = call;
            continue;
        }
        case Instruction::COPY:
        {
            LOG("COPY");
            addr_c addr1 = 0;
            for (instr_size_c i = 2; i <= LONG_ADDR_LENGTH + 1; i++)
            {
                addr1 <<= 8;
                addr1 |= line[i];
            }
            addr_c addr2 = 0;
            for (instr_size_c i = 3 + LONG_ADDR_LENGTH; i < LONG_ADDR_LENGTH + LONG_ADDR_LENGTH + 3; i++)
            {
                addr2 <<= 8;
                addr2 |= line[i];
            }
            switch(line[1])
            {
            case BLOCK:
                switch(line[2 + LONG_ADDR_LENGTH])
                {
                case BLOCK: blocks[addr2] << blocks[addr1]; break;
                case POINTER: blocks[blocks[addr2].data.i] << blocks[addr1]; break;
                case ARGUMENT: *args[addr2] << blocks[addr1]; break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[2 + LONG_ADDR_LENGTH])
                {
                case BLOCK: blocks[addr2] << blocks[blocks[addr1].data.i]; break;
                case POINTER: blocks[blocks[addr2].data.i] << blocks[blocks[addr1].data.i]; break;
                case ARGUMENT: *args[addr2] << blocks[blocks[addr1].data.i]; break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[2 + LONG_ADDR_LENGTH])
                {
                case BLOCK: blocks[addr2] << *args[addr1]; break;
                case POINTER: blocks[blocks[addr2].data.i] << *args[addr1]; break;
                case ARGUMENT: *args[addr2] << *args[addr1]; break;
                default: break;
                }
                break;
            default: break;
            }
            break;
        }
        case Instruction::SWAP:
        {
            LOG("SWAP");
            addr_c addr1 = 0;
            for (instr_size_c i = 1; i <= LONG_ADDR_LENGTH; i++)
            {
                addr1 <<= 8;
                addr1 |= line[i + 1];
            }
            PUT_CTX(addr1, addr1);
            addr_c addr2 = 0;
            for (instr_size_c i = 3 + LONG_ADDR_LENGTH; i < LONG_ADDR_LENGTH + LONG_ADDR_LENGTH + 3; i++)
            {
                addr2 <<= 8;
                addr2 |= line[i];
            }
            PUT_CTX(addr2, addr2);
            switch(line[1])
            {
            case BLOCK:
                switch(line[2 + LONG_ADDR_LENGTH])
                {
                case BLOCK: std::swap(blocks[addr1], blocks[addr2]); SET_INSTR(jswap1); break;
                case POINTER: std::swap(blocks[addr1], blocks[blocks[addr2].data.i]); SET_INSTR(jswap2); break;
                case ARGUMENT: std::swap(blocks[addr1], *args[addr2]); SET_INSTR(jswap3); break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[2 + LONG_ADDR_LENGTH])
                {
                case BLOCK: std::swap(blocks[blocks[addr1].data.i], blocks[addr2]); SET_INSTR(jswap5); break;
                case POINTER: std::swap(blocks[blocks[addr1].data.i], blocks[blocks[addr2].data.i]); SET_INSTR(jswap6); break;
                case ARGUMENT: std::swap(blocks[blocks[addr1].data.i], *args[addr2]); SET_INSTR(jswap7); break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[2 + LONG_ADDR_LENGTH])
                {
                case BLOCK: std::swap(*args[addr1], blocks[addr2]); SET_INSTR(jswap9); break;
                case POINTER: std::swap(*args[addr1], blocks[blocks[addr2].data.i]); SET_INSTR(jswap10); break;
                case ARGUMENT: std::swap(args[addr1], args[addr2]); SET_INSTR(jswap11); break;
                default: break;
                }
                break;
            default: break;
            }
            break;
        }
        case Instruction::DEC:
        {
            LOG("DEC");
            switch(line[1])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], INT);
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jdec1);
                --blocks[line[2]].data.i; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], INT);
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jdec2);
                --blocks[blocks[line[2]].data.i].data.i; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], INT);
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jdec3);
                --args[line[2]]->data.i; break;
            default: break;
            }
            break;
        }
        case Instruction::CMP:
        {
            LOG("CMP");
            switch(line[1])
            {
            case BLOCK:
                blocks[line[2]].readyOverwrite();
                blocks[line[2]].data.b = compare;
                blocks[line[2]].type = Object::BOOL;
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jcmp1);
                break;
            case POINTER:
                blocks[blocks[line[2]].data.i].readyOverwrite();
                blocks[blocks[line[2]].data.i].data.b = compare;
                blocks[blocks[line[2]].data.i].type = Object::BOOL;
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jcmp2);
                break;
            case ARGUMENT:
                args[line[2]]->readyOverwrite();
                args[line[2]]->data.b = compare;
                args[line[2]]->type = Object::BOOL;
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jcmp3);
                break;
            default: break;
            }
            break;
        }
        case Instruction::INC:
        {
            LOG("INC");
            switch(line[1])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], INT);
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jinc1);
                //ctx.instr = ChimeraJIT::jinc; ctx.enabled = true; ctx.mode1 = 1;
                ++blocks[line[2]].data.i; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], INT);
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jinc2);
                ++blocks[blocks[line[2]].data.i].data.i; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], INT);
                PUT_CTX(addr1, line[2]);
                SET_INSTR(jinc3);
                ++args[line[2]]->data.i; break;
            default: break;
            }
            break;
        }
        case Instruction::JUMP:
        {
            LOG("JUMP");
            programCounter = line[1] << 8 | line[2];
            PUT_CTX(l1, programCounter);
            SET_INSTR(jjump);
            //ctx.instr = ChimeraJIT::jjump; ctx.enabled = true;
            continue;
        }
        case Instruction::JCMP:
        {
            LOG("JCMP");
            if (lineSize > 3)
            {
                switch(line[3])
                {
                case BLOCK: CHECK_TYPE(blocks[line[4]], BOOL); compare = blocks[line[4]].data.b; PUT_CTX(addr1, line[4]); SET_INSTR(jjcmp2); break;
                case POINTER: CHECK_TYPE(blocks[blocks[line[4]].data.i], BOOL); compare = blocks[blocks[line[4]].data.i].data.b; PUT_CTX(addr1, line[4]); SET_INSTR(jjcmp3); break;
                case ARGUMENT: CHECK_TYPE(*args[line[4]], BOOL); compare = args[line[4]]->data.b; PUT_CTX(addr1, line[4]); SET_INSTR(jjcmp4); break;
                default: break;
                }
            }
            //else { SET_INSTR(jjcmp1); ctx.instr = ChimeraJIT::jjcmp; ctx.enabled = true; }
            PUT_CTX(l1, line[1] << 8 | line[2]);
            programCounter = compare ? line[1] << 8 | line[2] : programCounter + 1; continue;
        }
        case Instruction::JNC:
        {
            LOG("JNC");
            if (lineSize > 3)
            {
                switch(line[3])
                {
                case BLOCK: CHECK_TYPE(blocks[line[4]], BOOL); compare = blocks[line[4]].data.b; PUT_CTX(addr1, line[4]); SET_INSTR(jjnc2); break;
                case POINTER: CHECK_TYPE(blocks[blocks[line[4]].data.i], BOOL); compare = blocks[blocks[line[4]].data.i].data.b; PUT_CTX(addr1, line[4]); SET_INSTR(jjnc3); break;
                case ARGUMENT: CHECK_TYPE(*args[line[4]], BOOL); compare = args[line[4]]->data.b; PUT_CTX(addr1, line[4]); SET_INSTR(jjnc4); break;
                default: break;
                }
            }
            else { SET_INSTR(jjnc1); }
            PUT_CTX(l1, line[1] << 8 | line[2]);
            programCounter = compare ? programCounter + 1 : line[1] << 8 | line[2]; continue;
        }
        case Instruction::JNEG:
        {
            LOG("JNEG");
            int_c a;
            switch(line[3])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[4]], INT);
                PUT_CTX(addr1, line[4]); SET_INSTR(jjneg1);
                a = blocks[line[4]].data.i; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[4]].data.i], INT);
                PUT_CTX(addr1, line[4]); SET_INSTR(jjneg2);
                a = blocks[blocks[line[4]].data.i].data.i; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[4]], INT);
                PUT_CTX(addr1, line[4]); SET_INSTR(jjneg3);
                a = args[line[4]]->data.i; break;
            default: a = 0; break;
            }
            PUT_CTX(l1, line[1] << 8 | line[2]);
            if (a < 0)
            {
                programCounter = line[1] << 8 | line[2]; continue;
            }
            break;
        }
        case Instruction::JNQZ:
        {
            LOG("JUMP_NEQI");
            int_c a;
            switch(line[3])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[4]], INT);
                PUT_CTX(addr1, line[4]); SET_INSTR(jjnqz1);
                a = blocks[line[4]].data.i; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[4]].data.i], INT);
                PUT_CTX(addr1, line[4]); SET_INSTR(jjnqz2);
                a = blocks[blocks[line[4]].data.i].data.i; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[4]], INT);
                PUT_CTX(addr1, line[4]); SET_INSTR(jjnqz3);
                a = args[line[4]]->data.i; break;
            default: a = 0; break;
            }
            PUT_CTX(l1, line[1] << 8 | line[2]);
            if (a != 0)
            {
                programCounter = line[1] << 8 | line[2]; continue;
            }
            break;
        }
        case Instruction::JMPT:
        {
            LOG("JMPT");
            int type;
            switch(line[11])
            {
            case BLOCK: type = blocks[line[12]].type; break;
            case POINTER: type = blocks[blocks[line[12]].data.i].type; break;
            case ARGUMENT: type = args[line[12]]->type; break;
            default: type = Object::NOTYPE; break;
            }
            switch(type)
            {
            case Object::INT: programCounter = line[1] << 8 | line[2]; continue;
            case Object::FLOAT: programCounter = line[3] << 8 | line[4]; continue;
            case Object::BOOL: programCounter = line[5] << 8 | line[6]; continue;
            case Object::STRING: programCounter = line[7] << 8 | line[8]; continue;
            case Object::OBJECT: programCounter = line[9] << 8 | line[10]; continue;
            default: break;
            }
            break;
        }
        case Instruction::LTI:
        case Instruction::LEQI:
        case Instruction::EQI:
        case Instruction::NEQI:
        {
            instr_size_c length1 = line[1];
            int_c a;
            switch(length1)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], INT);
                a = blocks[line[2]].data.i; length1 = 1;
                PUT_CTX(addr2, line[2]);
                //ctx.mode2 = 1; break;
                break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], INT);
                a = blocks[blocks[line[2]].data.i].data.i; length1 = 1;
                PUT_CTX(addr2, line[2]); break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], INT);
                a = args[line[2]]->data.i; length1 = 1;
                PUT_CTX(addr2, line[2]); break;
            default:
                a = 0;
                for (instr_size_c i = 2; i < length1 + 2; i++)
                {
                    a <<= 8;
                    a |= line[i];
                }
                PUT_CTX(x, a);
                break;
            }
            instr_size_c length2 = line[2 + length1];
            int_c b;
            switch(length2)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[3 + length1]], INT);
                b = blocks[line[3 + length1]].data.i;
                PUT_CTX(addr3, line[3 + length1]);
                //ctx.mode3 = 1;
                break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], INT);
                b = blocks[blocks[line[3 + length1]].data.i].data.i;
                PUT_CTX(addr3, line[3 + length1]); break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[3 + length1]], INT);
                b = args[line[3 + length1]]->data.i;
                PUT_CTX(addr3, line[3 + length1]); break;
            default:
                b = 0;
                for (instr_size_c i = 3 + length1; i < length2 + length1 + 3; i++)
                {
                    b <<= 8;
                    b |= line[i];
                }
                PUT_CTX(y, b);
                break;
            }
            switch(instr)
            {
            case Instruction::LTI: LOG("LTI"); /*ctx.instr = ChimeraJIT::jlti; ctx.enabled = true;*/ compare = a < b; break;
            case Instruction::LEQI: LOG("LEQI"); compare = a <= b; break;
            case Instruction::EQI: LOG("EQI"); compare = a == b; break;
            case Instruction::NEQI: LOG("NEQI"); compare = a != b; break;
            default: break;
            }
            switch(line[1])
            {
            case BLOCK:
                switch(line[2 + length1])
                {
                case BLOCK: SET_COMPI(instr, 7); break;
                case POINTER: SET_COMPI(instr, 8); break;
                case ARGUMENT: SET_COMPI(instr, 9); break;
                default: SET_COMPI(instr, 6); break;
                }
                break;
            case POINTER:
                switch(line[2 + length1])
                {
                case BLOCK: SET_COMPI(instr, 12); break;
                case POINTER: SET_COMPI(instr, 13); break;
                case ARGUMENT: SET_COMPI(instr, 14); break;
                default: SET_COMPI(instr, 11); break;
                }
                break;
            case ARGUMENT:
                switch(line[2 + length1])
                {
                case BLOCK: SET_COMPI(instr, 17); break;
                case POINTER: SET_COMPI(instr, 18); break;
                case ARGUMENT: SET_COMPI(instr, 19); break;
                default: SET_COMPI(instr, 16); break;
                }
                break;
            default:
                switch(line[2 + length1])
                {
                case BLOCK: SET_COMPI(instr, 2); break;
                case POINTER: SET_COMPI(instr, 3); break;
                case ARGUMENT: SET_COMPI(instr, 4); break;
                default: SET_COMPI(instr, 1); break;
                }
                break;
            }
            break;
        }
        case Instruction::NOT:
        {
            LOG("NOT");
            if (lineSize == 1) compare = not compare;
            else
            {
                switch(line[1])
                {
                case BLOCK:
                    CHECK_TYPE(blocks[line[2]], BOOL);
                    compare = not blocks[line[2]].data.b; break;
                case POINTER:
                    CHECK_TYPE(blocks[blocks[line[2]].data.i], BOOL);
                    compare = not blocks[blocks[line[2]].data.i].data.b; break;
                case ARGUMENT:
                    CHECK_TYPE(*args[line[2]], BOOL);
                    compare = not args[line[2]]->data.b; break;
                default: compare = line[2] != 1; break;
                }
            }
            break;
        }
        case Instruction::AND:
        case Instruction::OR:
        case Instruction::EQB:
        case Instruction::XOR:
        case Instruction::IMPLIES:
        case Instruction::NAND:
        case Instruction::NOR:
        {
            instr_size_c length1 = 0;
            bool_c p;
            switch(line[1])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], BOOL);
                p = blocks[line[2]].data.b; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], BOOL);
                p = blocks[blocks[line[2]].data.i].data.b; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], BOOL);
                p = args[line[2]]->data.b; break;
            default: p = line[2] == 1; break;
            }
            bool_c q;
            if (lineSize == 3 + length1) q = compare;
            else
            {
                switch(line[3+length1])
                {
                case BLOCK:
                    CHECK_TYPE(blocks[line[4 + length1]], BOOL);
                    q = blocks[line[4+length1]].data.b; break;
                case POINTER:
                    CHECK_TYPE(blocks[blocks[line[4 + length1]].data.i], BOOL);
                    q = blocks[blocks[line[4+length1]].data.i].data.b; break;
                case ARGUMENT:
                    CHECK_TYPE(*args[line[4 + length1]], BOOL);
                    q = args[line[4+length1]]->data.b; break;
                default: q = line[4+length1] == 1; break;
                }
            }
            switch(instr)
            {
            case Instruction::AND: LOG("AND"); compare = p and q; break;
            case Instruction::OR: LOG("OR"); compare = p or q; break;
            case Instruction::EQB: LOG("EQB"); compare = p == q; break;
            case Instruction::XOR: LOG("XOR"); compare = p != q; break;
            case Instruction::IMPLIES: LOG("IMPLIES"); compare = not p or q; break;
            case Instruction::NAND: LOG("NAND"); compare = not p and not q; break;
            case Instruction::NOR: LOG("NOR"); compare = not p or not q; break;
            default: break;
            }
            break;
        }
        case Instruction::PRINT:
        {
            LOG("PRINT");
            // Control structure: _:_:_:_:_:_:cmp:\n
            byte control = line[1];
            if (lineSize > 2)
            {
                object_uptr containerObject1;
                switch(line[2])
                {
                case BLOCK: containerObject1 = &blocks[line[3]]; break;
                case POINTER: containerObject1 = &blocks[blocks[line[3]].data.i]; break;
                case ARGUMENT: containerObject1 = args[line[3]].get(); break;
                default: containerObject1 = nullptr; break;
                }
                switch(containerObject1->type)
                {
                case Object::INT:
                    out << containerObject1->data.i << ((control & 1) == 1 ? "\n" : "");
                    break;
                case Object::FLOAT:
                    out << chimeraFloatRepresentation(containerObject1->data.f) << ((control & 1) == 1 ? "\n" : "");
                    break;
                case Object::BOOL:
                    out << (containerObject1->data.b ? "true" : "false") << ((control & 1) == 1 ? "\n" : "");
                    break;
                case Object::STRING:
                    out << *containerObject1->data.s << ((control & 1) == 1 ? "\n" : "");
                    break;
                case Object::OBJECT:
                {
                    object_c resultObject1 = containerObject1->data.o;
                    if (resultObject1 == nullptr) { std::cerr << "Object was null!" << endl; exit(1); }
                    if (resultObject1->hasMethod("print"))
                    {
                        nextFrame->callingLine = programCounter;
                        object_ptr self = make_shared<Object>();
                        self->data.o = resultObject1;
                        self->type = Object::OBJECT;
                        *(*nextFrame)[0] << *self;
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = resultObject1->getMethod("print").i;
                        continue;
                    }
                    else out << resultObject1->getTag() << " object #" << resultObject1->getId() << ((control & 1) == 1 ? "\n" : "");
                    break;
                }
                case Object::TUPLE:
                    out << containerObject1->data.t->toString() << ((control & 1) == 1 ? "\n" : "");
                    delete containerObject1->data.t;
                    containerObject1->type = Object::NOTYPE;
                    break;
                default:
                    //std::cerr << "printing NOTYPE object" << endl; exit(1);
                    out << "null" << ((control & 1) == 1 ? "\n" : "");
                    break;
                }
            }
            else
            {
                out << ((control & 2) == 2 ? compare ? "true" : "false" : "") << ((control & 1) == 1 ? "\n" : "");
            }
            break;
        }
        case Instruction::RETURN:
        {
            LOG("RETURN");
            nextFrame = callStack->pop();
            addr_c returnAddress = nextFrame->returnAddr;
            if (returnLine == nextFrame->callingLine)
            {
                if (lineSize == 1) { return Object(); }
                switch(line[1])
                {
                case BLOCK: return blocks[line[2]];
                case POINTER: return blocks[blocks[line[2]].data.i];
                case ARGUMENT: return *nextFrame->arguments[line[2]];
                default: return Object();
                }
            }
            if (returnAddress != (addr_c) -1)
            {
                if (lineSize == 1)
                {
                    out << "Attempting to collect return value from void function" << endl;
                    return Object();
                }
                switch(line[1])
                {
                case BLOCK: (nextFrame->returnIntoBlock ? blocks[returnAddress] : *args[returnAddress]) << blocks[line[2]]; break;
                case POINTER: (nextFrame->returnIntoBlock ? blocks[returnAddress] : *args[returnAddress]) << blocks[blocks[line[2]].data.i]; break;
                case ARGUMENT: (nextFrame->returnIntoBlock ? blocks[returnAddress] : *args[returnAddress]) << *nextFrame->arguments[line[2]]; break;
                default: break;
                }
            }
            if (lineSize == 1) { SET_INSTR(jreturn1); }
            else switch(line[1])
            {
            case BLOCK: PUT_CTX(addr1, line[2]); SET_INSTR(jreturn2); break;
            case POINTER: PUT_CTX(addr1, line[2]); SET_INSTR(jreturn3); break;
            case ARGUMENT: PUT_CTX(addr1, line[2]); SET_INSTR(jreturn4); break;
            default: break;
            }
            programCounter = nextFrame->callingLine;
            nextFrame->reset();
            continue;
        }
        case Instruction::STOREINT:
        {
            LOG("STOREINT");
            addr_c addr1 = 0;
            instr_size_c length1;
            length1 = LONG_ADDR_LENGTH;
            for (instr_size_c i = 1; i <= LONG_ADDR_LENGTH; i++)
            {
                addr1 <<= 8;
                addr1 |= line[i+1];
            }
            instr_size_c length2 = line[length1 + 2];
            switch(length2)
            {
            case BLOCK:
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    {
                        object_cref block = blocks[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: blocks[addr1].data.i = block.data.i; break;
                        case Object::FLOAT: blocks[addr1].data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                        //ctx.instr = ChimeraJIT::jstoreint; ctx.enabled = true;
                    }
                    blocks[addr1].type = Object::INT;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    {
                        object_cref block = blocks[line[3 + length1]];
                        PUT_CTX(addr2, line[3 + length1]);
                        //ctx.mode2 = 1;
                        switch(block.type)
                        {
                        case Object::INT: blocks[blocks[addr1].data.i].data.i = block.data.i; break;
                        case Object::FLOAT: blocks[blocks[addr1].data.i].data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                        //ctx.instr = ChimeraJIT::jstoreint; ctx.enabled = true;
                    }
                    blocks[blocks[addr1].data.i].type = Object::INT;
                    PUT_CTX(addr1, addr1);
                    //ctx.mode1 = 2;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    {
                        object_cref block = blocks[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: args[addr1]->data.i = block.data.i; break;
                        case Object::FLOAT: args[addr1]->data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    args[addr1]->type = Object::INT;
                    break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    {
                        object_cref block = blocks[blocks[line[3 + length1]].data.i];
                        switch(block.type)
                        {
                        case Object::INT: blocks[addr1].data.i = block.data.i; break;
                        case Object::FLOAT: blocks[addr1].data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[addr1].type = Object::INT;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    {
                        object_cref block = blocks[blocks[line[3 + length1]].data.i];
                        switch(block.type)
                        {
                        case Object::INT: blocks[blocks[addr1].data.i].data.i = block.data.i; break;
                        case Object::FLOAT: blocks[blocks[addr1].data.i].data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[blocks[addr1].data.i].type = Object::INT;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    {
                        object_cref block = blocks[blocks[line[3 + length1]].data.i];
                        switch(block.type)
                        {
                        case Object::INT: args[addr1]->data.i = block.data.i; break;
                        case Object::FLOAT: args[addr1]->data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    args[addr1]->type = Object::INT;
                    break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    {
                        object_cref block = *args[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: blocks[addr1].data.i = block.data.i; break;
                        case Object::FLOAT: blocks[addr1].data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[addr1].type = Object::INT;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    {
                        object_cref block = *args[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: blocks[blocks[addr1].data.i].data.i = block.data.i; break;
                        case Object::FLOAT: blocks[blocks[addr1].data.i].data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[blocks[addr1].data.i].type = Object::INT;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    {
                        object_cref block = *args[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: args[addr1]->data.i = block.data.i; break;
                        case Object::FLOAT: args[addr1]->data.i = (int_c) block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    args[addr1]->type = Object::INT;
                    break;
                default: break;
                }
                break;
            default:
                int_c resultInt = 0;
                for (instr_size_c i = 3 + length1; i < 3 + length1 + length2; i++)
                {
                    resultInt <<= 8;
                    resultInt |= line[i];
                }
                PUT_CTX(x, resultInt);
                //ctx.mode2 = 0;
                switch(line[1])
                {
                case BLOCK:
                    PUT_CTX(addr1, addr1);
                    SET_INSTR(jstoreint1);
                    blocks[addr1].readyOverwrite();
                    blocks[addr1].data.i = resultInt;
                    blocks[addr1].type = Object::INT;
                    //ctx.instr = ChimeraJIT::jstoreint; ctx.enabled = true;
                    //ctx.mode1 = 1;
                    break;
                case POINTER:
                    PUT_CTX(addr1, addr1);
                    SET_INSTR(jstoreint2);
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    blocks[blocks[addr1].data.i].data.i = resultInt;
                    blocks[blocks[addr1].data.i].type = Object::INT;
                    break;
                case ARGUMENT:
                    PUT_CTX(addr1, addr1);
                    SET_INSTR(jstoreint3);
                    args[addr1]->readyOverwrite();
                    args[addr1]->data.i = resultInt;
                    args[addr1]->type = Object::INT;
                    break;
                default: break;
                }
                break;
            }
            break;
        }
        case Instruction::STOREFLOAT:
        {
            LOG("STOREFLOAT");
            addr_c addr1 = 0;
            instr_size_c length1;
            length1 = LONG_ADDR_LENGTH;
            for (instr_size_c i = 1; i <= LONG_ADDR_LENGTH; i++)
            {
                addr1 <<= 8;
                addr1 |= line[i+1];
            }
            instr_size_c length2 = line[length1 + 2];
            switch(length2)
            {
            case BLOCK:
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    {
                        object_cref block = blocks[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: blocks[addr1].data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: blocks[addr1].data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[addr1].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    {
                        object_cref block = blocks[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: blocks[blocks[addr1].data.i].data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: blocks[blocks[addr1].data.i].data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[blocks[addr1].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    {
                        object_cref block = blocks[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: args[addr1]->data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: args[addr1]->data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    args[addr1]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    {
                        object_cref block = blocks[blocks[line[3 + length1]].data.i];
                        switch(block.type)
                        {
                        case Object::INT: blocks[addr1].data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: blocks[addr1].data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[addr1].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    {
                        object_cref block = blocks[blocks[line[3 + length1]].data.i];
                        switch(block.type)
                        {
                        case Object::INT: blocks[blocks[addr1].data.i].data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: blocks[blocks[addr1].data.i].data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[blocks[addr1].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    {
                        object_cref block = blocks[blocks[line[3 + length1]].data.i];
                        switch(block.type)
                        {
                        case Object::INT: args[addr1]->data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: args[addr1]->data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    args[addr1]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    {
                        object_cref block = *args[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: blocks[addr1].data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: blocks[addr1].data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[addr1].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    {
                        object_cref block = *args[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: blocks[blocks[addr1].data.i].data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: blocks[blocks[addr1].data.i].data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    blocks[blocks[addr1].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    {
                        object_cref block = *args[line[3 + length1]];
                        switch(block.type)
                        {
                        case Object::INT: args[addr1]->data.f = (float_c) block.data.i; break;
                        case Object::FLOAT: args[addr1]->data.f = block.data.f; break;
                        default: std::cerr << "FAILED RUNTIME TYPE CHECK: " << (int)block.type << " != " << Object::INT << "|" << Object::FLOAT << endl; exit(1);
                        }
                    }
                    args[addr1]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            default:
                float_bytes_c resultLong = 0;
                for (instr_size_c i = 3 + length1; i < 3 + length1 + length2; i++)
                {
                    resultLong <<= 8;
                    resultLong |= line[i];
                }
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    memcpy(&blocks[addr1].data.f, &resultLong, sizeof(resultLong));
                    blocks[addr1].type = Object::FLOAT;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    memcpy(&blocks[blocks[addr1].data.i].data.f, &resultLong, sizeof(resultLong));
                    blocks[blocks[addr1].data.i].type = Object::FLOAT;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    memcpy(&args[addr1]->data.f, &resultLong, sizeof(resultLong));
                    args[addr1]->type = Object::FLOAT;
                    break;
                default: break;
                }
                break;
            }
            break;
        }
        case Instruction::STORESTRING:
        {
            LOG("STORESTRING");
            addr_c addr1 = 0;
            instr_size_c length1;
            length1 = LONG_ADDR_LENGTH;
            for (instr_size_c i = 1; i <= LONG_ADDR_LENGTH; i++)
            {
                addr1 <<= 8;
                addr1 |= line[i+1];
            }
            instr_size_c length2 = line[length1 + 2];
            switch(length2)
            {
            case BLOCK:
                switch(line[1])
                {
                case BLOCK:
                    if (blocks[addr1].uid != blocks[line[3 + length1]].uid)
                    {
                        CHECK_TYPE(blocks[line[3 + length1]], STRING);
                        blocks[addr1].readyOverwrite();
                        blocks[addr1].data.s = new string(*blocks[line[3 + length1]].data.s);
                        blocks[addr1].type = Object::STRING;
                    }
                    break;
                case POINTER:
                    if (blocks[blocks[addr1].data.i].uid != blocks[line[3 + length1]].uid)
                    {
                        CHECK_TYPE(blocks[line[3 + length1]], STRING);
                        blocks[blocks[addr1].data.i].readyOverwrite();
                        blocks[blocks[addr1].data.i].data.s = new string(*blocks[line[3 + length1]].data.s);
                        blocks[blocks[addr1].data.i].type = Object::STRING;
                    }
                    break;
                case ARGUMENT:
                    if (args[addr1]->uid != blocks[line[3 + length1]].uid)
                    {
                        CHECK_TYPE(blocks[line[3 + length1]], STRING);
                        args[addr1]->readyOverwrite();
                        args[addr1]->data.s = new string(*blocks[line[3 + length1]].data.s);
                        args[addr1]->type = Object::STRING;
                    }
                    break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[1])
                {
                case BLOCK:
                    if (blocks[addr1].uid != blocks[blocks[line[3 + length1]].data.i].uid)
                    {
                        CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                        blocks[addr1].readyOverwrite();
                        blocks[addr1].data.s = new string(*blocks[blocks[line[3 + length1]].data.i].data.s);
                        blocks[addr1].type = Object::STRING;
                    }
                    break;
                case POINTER:
                    if (blocks[blocks[addr1].data.i].uid != blocks[blocks[line[3 + length1]].data.i].uid)
                    {
                        CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                        blocks[blocks[addr1].data.i].readyOverwrite();
                        blocks[blocks[addr1].data.i].data.s = new string(*blocks[blocks[line[3 + length1]].data.i].data.s);
                        blocks[blocks[addr1].data.i].type = Object::STRING;
                    }
                    break;
                case ARGUMENT:
                    if (args[addr1]->uid != blocks[blocks[line[3 + length1]].data.i].uid)
                    {
                        CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                        args[addr1]->readyOverwrite();
                        args[addr1]->data.s = new string(*blocks[blocks[line[3 + length1]].data.i].data.s);
                        args[addr1]->type = Object::STRING;
                    }
                    break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[1])
                {
                case BLOCK:
                    if (blocks[addr1].uid != args[line[3 + length1]]->uid)
                    {
                        CHECK_TYPE(*args[line[3 + length1]], STRING);
                        blocks[addr1].readyOverwrite();
                        blocks[addr1].data.s = new string(*args[line[3 + length1]]->data.s);
                        blocks[addr1].type = Object::STRING;
                    }
                    break;
                case POINTER:
                    if (blocks[blocks[addr1].data.i].uid != args[line[3 + length1]]->uid)
                    {
                        CHECK_TYPE(*args[line[3 + length1]], STRING);
                        blocks[blocks[addr1].data.i].readyOverwrite();
                        blocks[blocks[addr1].data.i].data.s = new string(*args[line[3 + length1]]->data.s);
                        blocks[blocks[addr1].data.i].type = Object::STRING;
                    }
                    break;
                case ARGUMENT:
                    if (args[addr1]->uid != args[line[3 + length1]]->uid)
                    {
                        CHECK_TYPE(*args[line[3 + length1]], STRING);
                        args[addr1]->readyOverwrite();
                        args[addr1]->data.s = new string(*args[line[3 + length1]]->data.s);
                        args[addr1]->type = Object::STRING;
                    }
                    break;
                default: break;
                }
                break;
            default:
                string resultString1 = "";
                for (instr_size_c i = 3 + length1; i < length2 + 3 + length1; i++) resultString1 += line[i];
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    blocks[addr1].data.s = new string(resultString1);
                    blocks[addr1].type = Object::STRING;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    blocks[blocks[addr1].data.i].data.s = new string(resultString1);
                    blocks[blocks[addr1].data.i].type = Object::STRING;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    args[addr1]->data.s = new string(resultString1);
                    args[addr1]->type = Object::STRING;
                    break;
                default: break;
                }
                break;
            }
            break;
        }
        case Instruction::STOREBOOL:
        {
            LOG("STOREBOOL");
            addr_c addr1 = 0;
            instr_size_c length1;
            length1 = LONG_ADDR_LENGTH;
            for (instr_size_c i = 1; i <= LONG_ADDR_LENGTH; i++)
            {
                addr1 <<= 8;
                addr1 |= line[i+1];
            }
            instr_size_c length2 = line[length1 + 2];
            switch(length2)
            {
            case BLOCK:
                switch(line[1])
                {
                case BLOCK:
                    CHECK_TYPE(blocks[line[3 + length1]], BOOL);
                    blocks[addr1].readyOverwrite();
                    blocks[addr1].data.b = blocks[line[3 + length1]].data.b;
                    blocks[addr1].type = Object::BOOL;
                    break;
                case POINTER:
                    CHECK_TYPE(blocks[line[3 + length1]], BOOL);
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    blocks[blocks[addr1].data.i].data.b = blocks[line[3 + length1]].data.b;
                    blocks[blocks[addr1].data.i].type = Object::BOOL;
                    break;
                case ARGUMENT:
                    CHECK_TYPE(blocks[line[3 + length1]], BOOL);
                    args[addr1]->readyOverwrite();
                    args[addr1]->data.b = blocks[line[3 + length1]].data.b;
                    args[addr1]->type = Object::BOOL;
                    break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[1])
                {
                case BLOCK:
                    CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], BOOL);
                    blocks[addr1].readyOverwrite();
                    blocks[addr1].data.b = blocks[blocks[line[3 + length1]].data.i].data.b;
                    blocks[addr1].type = Object::BOOL;
                    break;
                case POINTER:
                    CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], BOOL);
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    blocks[blocks[addr1].data.i].data.b = blocks[blocks[line[3 + length1]].data.i].data.b;
                    blocks[blocks[addr1].data.i].type = Object::BOOL;
                    break;
                case ARGUMENT:
                    CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], BOOL);
                    args[addr1]->readyOverwrite();
                    args[addr1]->data.b = blocks[blocks[line[3 + length1]].data.i].data.b;
                    args[addr1]->type = Object::BOOL;
                    break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[1])
                {
                case BLOCK:
                    CHECK_TYPE(*args[line[3 + length1]], BOOL);
                    blocks[addr1].readyOverwrite();
                    blocks[addr1].data.b = args[line[3 + length1]]->data.b;
                    blocks[addr1].type = Object::BOOL;
                    break;
                case POINTER:
                    CHECK_TYPE(*args[line[3 + length1]], BOOL);
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    blocks[blocks[addr1].data.i].data.b = args[line[3 + length1]]->data.b;
                    blocks[blocks[addr1].data.i].type = Object::BOOL;
                    break;
                case ARGUMENT:
                    CHECK_TYPE(*args[line[3 + length1]], BOOL);
                    args[addr1]->readyOverwrite();
                    args[addr1]->data.b = args[line[3 + length1]]->data.b;
                    args[addr1]->type = Object::BOOL;
                    break;
                default: break;
                }
                break;
            default:
                switch(line[1])
                {
                case BLOCK:
                    blocks[addr1].readyOverwrite();
                    blocks[addr1].data.b = line[3 + length1] == 1;
                    blocks[addr1].type = Object::BOOL;
                    break;
                case POINTER:
                    blocks[blocks[addr1].data.i].readyOverwrite();
                    blocks[blocks[addr1].data.i].data.b = line[3 + length1] == 1;
                    blocks[blocks[addr1].data.i].type = Object::BOOL;
                    break;
                case ARGUMENT:
                    args[addr1]->readyOverwrite();
                    args[addr1]->data.b = line[3 + length1] == 1;
                    args[addr1]->type = Object::BOOL;
                    break;
                default: break;
                }
                break;
            }
            break;
        }
        case Instruction::ALLOC:
        case Instruction::DEALLOC:
        {
            LOG("ALLOC/DEALLOC");
            instr_size_c length1 = line[1];
            int_c resultInt = 0;
            switch(length1)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], INT);
                resultInt = blocks[line[2]].data.i; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], INT);
                resultInt = blocks[blocks[line[2]].data.i].data.i; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], INT);
                resultInt = args[line[2]]->data.i; break;
            default:
                for (instr_size_c i = 2; i < length1 + 2; i++)
                {
                    resultInt <<= 8;
                    resultInt |= line[i];
                }
            }
            if (instr == Instruction::ALLOC)
            {
                addr_c newSize = memorySize + resultInt;
                LOG("new size of array: " << newSize * sizeof(Object));
                Object* temp_blocks = new Object[newSize];
                for (addr_c i = 0; i < memorySize; ++i) blocks[i].preserve = true;
                std::copy(blocks, blocks + memorySize, temp_blocks);
                delete [] blocks;
                blocks = temp_blocks;
                for (addr_c i = 0; i < memorySize; ++i) blocks[i].preserve = false;
                memorySize = newSize;
            }
            else
            {
                addr_c newSize = memorySize - resultInt;
                if (newSize < minMemorySize) out << "cannot deallocate past memory size of " << minMemorySize << " to " << newSize << endl; return Object();
                for (addr_c i = 0; i < newSize; ++i) blocks[i].preserve = true;
                Object* tempBlocks = new Object[newSize];
                std::copy(blocks, blocks + newSize, tempBlocks);
                delete [] blocks;
                blocks = tempBlocks;
                for (addr_c i = 0; i < newSize; ++i) blocks[i].preserve = false;
                memorySize = newSize;
            }
            break;
        }
        case Instruction::END:
        {
            LOG("END");
            if (not silence)
            {
                nextFrame->returnAddr = -1;
                cout << "Program terminated in " << ChimeraUtils::time(nullptr, nextFrame)->data.i - startTime << "ms" << endl;
            }
            // We need to move on the pc, just in case this is a interrupt vs termination
            programCounter++;
            return Object();
        }
        case Instruction::INVOKE:
        {
            LOG("INVOKE");
            instr_size_c length1 = 1;
            object_uptr containerObject1;
            switch(line[1])
            {
            case BLOCK: containerObject1 = &blocks[line[2]]; PUT_CTX(addr1, line[2]); break;
            case POINTER: containerObject1 = &blocks[blocks[line[2]].data.i]; PUT_CTX(addr1, line[2]); break;
            case ARGUMENT: containerObject1 = args[line[2]].get(); PUT_CTX(addr1, line[2]); break;
            default: std::cerr << "An error has occured" << endl; return Object();
            }
            instr_size_c length2 = line[2 + length1];
            string resultString1;
            switch(length2)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[3 + length1]], STRING);
                resultString1 = *blocks[line[3 + length1]].data.s; length2 = 1;
                PUT_CTX(addr2, line[3 + length1]);
                break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                resultString1 = *blocks[blocks[line[3 + length1]].data.i].data.s; length2 = 1;
                PUT_CTX(addr2, line[3 + length1]);
                break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[3 + length1]], STRING);
                resultString1 = *args[line[3 + length1]]->data.s; length2 = 1;
                PUT_CTX(addr2, line[3 + length1]);
                break;
            default:
                resultString1 = "";
                for (instr_size_c i = 3 + length1; i < length1 + 3 + length2; i++) resultString1 += (char) line[i];
                PUT_CTX(s2, resultString1);
                break;
            }
            CHECK_TYPE(*containerObject1, OBJECT);
            nextFrame->callingLine = programCounter + 1;
            *(*nextFrame)[0] << *containerObject1;
            if (lineSize > length2 + 3 + length1)
            {
                switch(line[length2 + 3 + length1])
                {
                case BLOCK:
                    nextFrame->returnAddr = line[length2 + 4 + length1];
                    nextFrame->returnIntoBlock = true;
                    PUT_CTX(addr3, line[length2 + 4 + length1]);
                    break;
                case POINTER:
                    nextFrame->returnAddr = blocks[line[length2 + 4 + length1]].data.i;
                    nextFrame->returnIntoBlock = true;
                    PUT_CTX(addr3, length2 + 4 + length1);
                    break;
                case ARGUMENT:
                    nextFrame->returnAddr = line[length2 + 4 + length1];
                    nextFrame->returnIntoBlock = false;
                    PUT_CTX(addr3, line[length2 + 4 + length1]);
                    break;
                default: break;
                }
            }
            callStack->push();
            nextFrame = callStack->allocNextPush();
            object_c resultObject1 = containerObject1->data.o;
            if (ChimeraStandardLibrary::includes(resultObject1))
            {
                nextFrame = callStack->pop();
                resultObject1->getMethod(resultString1).m((IChimeraStandardLibraryObject*) resultObject1, nextFrame);
                nextFrame->reset();
                break;
            }
            else programCounter = containerObject1->data.o->getMethod(resultString1).i;
            continue;
        }
        case Instruction::NEW:
        {
            LOG("NEW");
            addr_c addr1 = 0;
            instr_size_c length1;
            length1 = LONG_ADDR_LENGTH;
            for (instr_size_c i = 1; i <= LONG_ADDR_LENGTH; i++)
            {
                addr1 <<= 8;
                addr1 |= line[i+1];
            }
            object_c resultObject1;
            instr_size_c length2 = line[2 + length1];
            string resultString1;
            switch(length2)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[3 + length1]], STRING);
                resultString1 = *blocks[line[3 + length1]].data.s; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                resultString1 = *blocks[blocks[line[3 + length1]].data.i].data.s; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[3 + length1]], STRING);
                resultString1 = *args[line[3 + length1]]->data.s; break;
            default:
                resultString1 = "";
                for (instr_size_c i = 3 + length1; i < length1 + 3 + length2; i++) resultString1 += (char) line[i];
                break;
            }
            if (ChimeraStandardLibrary::includes(resultString1))
            {
                nextFrame->callingLine = programCounter + 1;
                nextFrame->returnAddr = line[length2 + 4 + length1];
                resultObject1 = ChimeraStandardLibrary::getInstance(resultString1, this, nextFrame);
                nextFrame->reset();
            }
            else
            {
                resultObject1 = new ChimeraObject(resultString1);
                // if (optional const available)
                if (false)
                {
                    nextFrame->callingLine = programCounter + 1;
                    nextFrame->returnAddr = line[length2 + 4 + length1];
                    *(*nextFrame)[0] << *Object::make(resultObject1);
                    callStack->push();
                    nextFrame = callStack->allocNextPush();
                    programCounter = 0; //optional pc
                }
            }
            switch(line[1])
            {
            case BLOCK:
                blocks[addr1].readyOverwrite();
                blocks[addr1].data.o = resultObject1;
                blocks[addr1].type = Object::OBJECT;
                resultObject1->acquire();
                break;
            case POINTER:
                blocks[blocks[addr1].data.i].readyOverwrite();
                blocks[blocks[addr1].data.i].data.o = resultObject1;
                blocks[blocks[addr1].data.i].type = Object::OBJECT;
                resultObject1->acquire();
                break;
            case ARGUMENT:
                args[addr1]->readyOverwrite();
                args[addr1]->data.o = resultObject1;
                args[addr1]->type = Object::OBJECT;
                resultObject1->acquire();
                break;
            default: break;
            }
            break;
        }
        case Instruction::PULLATTR:
        {
            LOG("PULLATTR");
            instr_size_c length1 = 1;
            object_c resultObject1;
            switch(line[1])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], OBJECT);
                resultObject1 = blocks[line[2]].data.o; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], OBJECT);
                resultObject1 = blocks[blocks[line[2]].data.i].data.o; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], OBJECT);
                resultObject1 = args[line[2]]->data.o; break;
            default: std::cerr << "An error has occured" << endl; return Object();
            }
            LOG("Pulling from; Object#" << resultObject1->getId() << ":" << resultObject1->getTag());
            instr_size_c length2 = line[2 + length1];
            string resultString1;
            switch(length1)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[3 + length1]], STRING);
                resultString1 = *blocks[line[3 + length1]].data.s; length2 = 1; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                resultString1 = *blocks[blocks[line[3 + length1]].data.i].data.s; length2 = 1; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[3 + length1]], STRING);
                resultString1 = *args[line[3 + length1]]->data.s; length2 = 1; break;
            default:
                resultString1 = "";
                for (instr_size_c i = 3 + length1; i < length1 + 3 + length2; i++) resultString1 += (char) line[i];
                break;
            }
            LOG("Variable: " << resultString1);
            #ifdef DEBUG
            cout << "Pulled: ";
            resultObject1->getAttribute(resultString1).print();
            #endif // DEBUG
            switch(line[length2 + length1 + 3])
            {
            case BLOCK: blocks[line[length2 + length1 + 4]] << resultObject1->getAttribute(resultString1); break;
            case POINTER: blocks[blocks[line[length2 + length1 + 4]].data.i] << resultObject1->getAttribute(resultString1); break;
            case ARGUMENT: *args[line[length2 + length1 + 4]] << resultObject1->getAttribute(resultString1); break;
            default: break;
            }
            break;
        }
        case Instruction::PUTARG:
        {
            LOG("PUTARG");
            switch(line[1])
            {
            case BLOCK:
                nextFrame->putArgument(blocks[line[2]]);
                PUT_CTX(addr1, line[2]); SET_INSTR(jputarg1);
                break;
            case POINTER:
                nextFrame->putArgument(blocks[blocks[line[2]].data.i]);
                PUT_CTX(addr1, line[2]); SET_INSTR(jputarg2);
                break;
            case ARGUMENT:
                nextFrame->putArgument(*args[line[2]]);
                PUT_CTX(addr1, line[2]); SET_INSTR(jputarg3);
                break;
            default: break;
            }
            break;
        }
        case Instruction::PUTATTR:
        {
            LOG("PUTATTR");
            instr_size_c length1 = 1;
            object_c resultObject1;
            switch(line[1])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], OBJECT);
                resultObject1 = blocks[line[2]].data.o; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], OBJECT);
                resultObject1 = blocks[blocks[line[2]].data.i].data.o; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], OBJECT);
                resultObject1 = args[line[2]]->data.o; break;
            default: std::cerr << "An error has occured" << endl; return Object();
            }
            LOG("Putting into; Object#" << resultObject1->getId() << ":" << resultObject1->getTag());
            instr_size_c length2 = line[2 + length1];
            string resultString1;
            switch(length2)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[3 + length1]], STRING);
                resultString1 = *blocks[line[3 + length1]].data.s; length2 = 1; break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                resultString1 = *blocks[blocks[line[3 + length1]].data.i].data.s; length2 = 1; break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[3 + length1]], STRING);
                resultString1 = *args[line[3 + length1]]->data.s; length2 = 1; break;
            default:
                resultString1 = "";
                for (instr_size_c i = 3 + length1; i < length1 + 3 + length2; i++) resultString1 += (char) line[i];
                break;
            }
            LOG("Variable: " << resultString1);
            switch(line[length2 + length1 + 3])
            {
            case BLOCK:
                resultObject1->putAttribute(resultString1, blocks[line[length1 + length2 + 4]]);
                break;
            case POINTER:
                resultObject1->putAttribute(resultString1, blocks[blocks[line[length1 + length2 + 4]].data.i]);
                break;
            case ARGUMENT:
                resultObject1->putAttribute(resultString1, *args[line[length1 + length2 + 4]]);
                break;
            default: break;
            }
            #ifdef DEBUG
            cout << "Value End: ";
            resultObject1->getAttribute(resultString1).print();
            #endif // DEBUG
            break;
        }
        case Instruction::PUTMETHOD:
        {
            LOG("PUTMETHOD");
            instr_size_c length1 = 1;
            object_c resultObject1;
            switch(line[1])
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[2]], OBJECT);
                resultObject1 = blocks[line[2]].data.o;
                PUT_CTX(addr1, line[2]); break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[2]].data.i], OBJECT);
                resultObject1 = blocks[blocks[line[2]].data.i].data.o;
                PUT_CTX(addr1, line[2]); break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[2]], OBJECT);
                resultObject1 = args[line[2]]->data.o;
                PUT_CTX(addr1, line[2]); break;
            default: std::cerr << "An error has occured" << endl; return Object();
            }
            instr_size_c length2 = line[2 + length1];
            string resultString1;
            switch(length1)
            {
            case BLOCK:
                CHECK_TYPE(blocks[line[3 + length1]], STRING);
                resultString1 = *blocks[line[3 + length1]].data.s; length2 = 1;
                PUT_CTX(addr1, line[2]);
                switch(line[1])
                {
                    case BLOCK: SET_INSTR(jputmethod5); break;
                    case POINTER: SET_INSTR(jputmethod9); break;
                    case ARGUMENT: SET_INSTR(jputmethod13); break;
                    default: break;
                }
                break;
            case POINTER:
                CHECK_TYPE(blocks[blocks[line[3 + length1]].data.i], STRING);
                resultString1 = *blocks[blocks[line[3 + length1]].data.i].data.s; length2 = 1;
                PUT_CTX(addr1, line[2]);
                switch(line[1])
                {
                    case BLOCK: SET_INSTR(jputmethod6); break;
                    case POINTER: SET_INSTR(jputmethod10); break;
                    case ARGUMENT: SET_INSTR(jputmethod14); break;
                    default: break;
                }
                break;
            case ARGUMENT:
                CHECK_TYPE(*args[line[3 + length1]], STRING);
                resultString1 = *args[line[3 + length1]]->data.s; length2 = 1;
                PUT_CTX(addr1, line[2]);
                switch(line[1])
                {
                    case BLOCK: SET_INSTR(jputmethod7); break;
                    case POINTER: SET_INSTR(jputmethod11); break;
                    case ARGUMENT: SET_INSTR(jputmethod15); break;
                    default: break;
                }
                break;
            default:
                resultString1 = "";
                for (instr_size_c i = 3 + length1; i < length2 + 3 + length1; i++) resultString1 += (char) line[i];
                PUT_CTX(s1, resultString1);
                switch(line[1])
                {
                    case BLOCK: SET_INSTR(jputmethod1); break;
                    case POINTER: SET_INSTR(jputmethod2); break;
                    case ARGUMENT: SET_INSTR(jputmethod3); break;
                    default: break;
                }
                break;
            }
            MethodOrInt moi;
            moi.i = line[length2 + 3 + length1] << 8 | line[length2 + 4 + length1];
            PUT_CTX(l1, moi.i);
            resultObject1->putMethod(resultString1, moi);
            break;
        }
        case Instruction::DEREFL:
        {
            LOG("DEREFL");
            addr_c addr1 = line[2];
            addr_c addr2 = line[4];
            switch(line[1])
            {
            case BLOCK:
                switch(line[3])
                {
                case BLOCK: blocks[addr1] << blocks[blocks[addr2].data.i]; break;
                case POINTER: blocks[blocks[addr1].data.i] << blocks[blocks[addr2].data.i]; break;
                case ARGUMENT: *args[addr1] << blocks[blocks[addr2].data.i]; break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[3])
                {
                case BLOCK: blocks[addr1] << blocks[blocks[blocks[addr2].data.i].data.i]; break;
                case POINTER: blocks[blocks[addr1].data.i] << blocks[blocks[blocks[addr2].data.i].data.i]; break;
                case ARGUMENT: *args[addr1] << blocks[blocks[blocks[addr2].data.i].data.i]; break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[3])
                {
                case BLOCK: blocks[addr1] << blocks[args[addr2]->data.i]; break;
                case POINTER: blocks[blocks[addr1].data.i] << blocks[args[addr2]->data.i]; break;
                case ARGUMENT: *args[addr1] << blocks[args[addr2]->data.i]; break;
                default: break;
                }
                break;
            default: break;
            }
            break;
        }
        case Instruction::DEREFS:
        {
            LOG("DEREFS");
            addr_c addr1 = line[2];
            addr_c addr2 = line[4];
            switch(line[1])
            {
            case BLOCK:
                switch(line[3])
                {
                case BLOCK: blocks[blocks[addr1].data.i] << blocks[addr2]; break;
                case POINTER: blocks[blocks[blocks[addr1].data.i].data.i] << blocks[addr2]; break;
                case ARGUMENT: blocks[args[addr1]->data.i] << blocks[addr2]; break;
                default: break;
                }
                break;
            case POINTER:
                switch(line[3])
                {
                case BLOCK: blocks[blocks[addr1].data.i] << blocks[blocks[addr2].data.i]; break;
                case POINTER: blocks[blocks[blocks[addr1].data.i].data.i] << blocks[blocks[addr2].data.i]; break;
                case ARGUMENT: blocks[args[addr1]->data.i] << blocks[blocks[addr2].data.i]; break;
                default: break;
                }
                break;
            case ARGUMENT:
                switch(line[3])
                {
                case BLOCK: blocks[blocks[addr1].data.i] << *args[addr2]; break;
                case POINTER: blocks[blocks[blocks[addr1].data.i].data.i] << *args[addr2]; break;
                case ARGUMENT: blocks[args[addr1]->data.i] << *args[addr2]; break;
                default: break;
                }
                break;
            default: break;
            }
            break;
        }
        case Instruction::STRETCH:
        {
            LOG("STRETCH");
            PUT_CTX(x, line[1]);
            callStack->peek()->stretch(line[1]);
            SET_INSTR(jstretch);
            break;
        }
        case Instruction::PACK:
        {
            LOG("PACK");
            object_uptr tupleBlock;
            instr_size_c length1 = 0;
            switch(line[1])
            {
            case BLOCK: tupleBlock = &blocks[line[2]]; break;
            case ARGUMENT: tupleBlock = args[line[2]].get(); length1 = line[2]; break;
            default: std::cerr << "TupleViolationException: Tuples can only be packed into globals or arguments" << endl; exit(1); break;
            }
            instr_size_c length2 = 0;
            object_uptr containerObject1;
            switch(line[3+length1])
            {
            case BLOCK: containerObject1 = &blocks[line[4+length1]]; break;
            case POINTER: containerObject1 = &blocks[blocks[line[4+length1]].data.i]; break;
            case ARGUMENT: containerObject1 = args[line[4+length1]].get(); break;
            default: containerObject1 = nullptr; break;
            }
            if (lineSize == 5 + length1 + length2)
            {
                CHECK_TYPE(*tupleBlock, TUPLE);
                tupleBlock->data.t->put(*containerObject1);
            }
            else
            {
                object_uptr containerObject2;
                switch(line[5+length1+length2])
                {
                case BLOCK: containerObject2 = &blocks[line[6+length1+length2]]; break;
                case POINTER: containerObject2 = &blocks[blocks[line[6+length1+length2]].data.i]; break;
                case ARGUMENT: containerObject2 = args[line[6+length1+length2]].get(); break;
                default: containerObject2 = nullptr; break;
                }
                tupleBlock->readyOverwrite();
                tupleBlock->data.t = new Tuple(*containerObject1, *containerObject2);
                tupleBlock->type = Object::TUPLE;
            }
            break;
        }
        case Instruction::UNPACK:
        {
            LOG("UNPACK");
            if (line[1] != BLOCK) { std::cerr << "TupleViolationException: Tuples can only be unpacked from globals" << endl; exit(1); }
            addr_c addr1 = line[2];
            CHECK_TYPE(blocks[addr1], TUPLE);
            tuple_c tuple = blocks[addr1].data.t;
            if (lineSize != 5) blocks[addr1].type = Object::NOTYPE;
            if (tuple->tuple.empty())
            {
                std::cerr << "TupleViolationException: Too few values to unpack" << endl;
                exit(1);
            }
            switch(line[3])
            {
            case BLOCK:
                blocks[line[4]] = *tuple->tuple.front();
                break;
            case POINTER:
                blocks[blocks[line[4]].data.i] = *tuple->tuple.front();
                break;
            case ARGUMENT:
                args[line[4]] = tuple->tuple.front();
                break;
            default: break;
            }
            tuple->tuple.pop_front();
            if (lineSize != 5)
            {
                if (tuple->tuple.empty())
                {
                    std::cerr << "TupleViolationException: Too few values to unpack" << endl;
                    exit(1);
                }
                switch(line[5])
                {
                case BLOCK:
                    blocks[line[6]] = *tuple->tuple.front();
                    break;
                case POINTER:
                    blocks[blocks[line[6]].data.i] = *tuple->tuple.front();
                    break;
                case ARGUMENT:
                    args[line[6]] = tuple->tuple.front();
                    break;
                default: break;
                }
                delete tuple;
            }
            break;
        }
        // CHIMERA UNTYPED INSTRUCTIONS
        case Instruction::ADD:
        case Instruction::SUB:
        case Instruction::MULT:
        case Instruction::DIV:
        {
            instr_size_c length1 = line[3];
            object_uptr containerObject1;
            switch(length1)
            {
            case BLOCK: containerObject1 = &blocks[line[4]]; length1 = 1; break;
            case POINTER: containerObject1 = &blocks[blocks[line[4]].data.i]; length1 = 1; break;
            case ARGUMENT: containerObject1 = args[line[4]].get(); length1 = 1; break;
            default: break;//containerObject1 = nullptr; break;
            }
            instr_size_c length2 = line[4+length1];
            object_uptr containerObject2;
            switch(length2)
            {
            case BLOCK: containerObject2 = &blocks[line[5 + length1]]; break;
            case POINTER: containerObject2 = &blocks[blocks[line[5 + length1]].data.i]; break;
            case ARGUMENT: containerObject2 = args[line[5 + length1]].get(); break;
            default: break;//containerObject2 = nullptr; break;
            }
            switch(instr)
            {
            case Instruction::ADD:
                LOG("ADD");
                switch(line[1])
                {
                case BLOCK:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.i = containerObject1->data.i + containerObject2->data.i;
                        blocks[line[2]].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.i + containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f + containerObject2->data.i;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f + containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::STRING and containerObject2->type == Object::STRING)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.s = new string(*containerObject1->data.s + *containerObject2->data.s);
                        blocks[line[2]].type = Object::STRING;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator+").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in ADD" << endl;
                        exit(1);
                    }
                    break;
                case POINTER:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.i = containerObject1->data.i + containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f + containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.i + containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f + containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::STRING and containerObject2->type == Object::STRING)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.s = new string(*containerObject1->data.s + *containerObject2->data.s);
                        blocks[blocks[line[2]].data.i].type = Object::STRING;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        CHECK_TYPE(blocks[line[2]], INT);
                        nextFrame->returnAddr = blocks[line[2]].data.i;
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator+").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in ADD" << endl;
                        exit(1);
                    }
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->data.i = containerObject1->data.i + containerObject2->data.i;
                        args[line[2]]->type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.f + containerObject2->data.i;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.i + containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->data.f = containerObject1->data.f + containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::STRING and containerObject2->type == Object::STRING)
                    {
                        args[line[2]]->data.s = new string(*containerObject1->data.s + *containerObject2->data.s);
                        args[line[2]]->type = Object::STRING;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = false;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator+").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in ADD" << endl;
                        exit(1);
                    }
                    break;
                default: break;
                }
                break;
            case Instruction::SUB:
                LOG("SUB");
                switch(line[1])
                {
                case BLOCK:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.i = containerObject1->data.i - containerObject2->data.i;
                        blocks[line[2]].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.i - containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f - containerObject2->data.i;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f - containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator-").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in SUB" << endl;
                        exit(1);
                    }
                    break;
                case POINTER:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.i = containerObject1->data.i - containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f - containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.i - containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f - containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        CHECK_TYPE(blocks[line[2]], INT);
                        nextFrame->returnAddr = blocks[line[2]].data.i;
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator-").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in SUB" << endl;
                        exit(1);
                    }
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->data.i = containerObject1->data.i - containerObject2->data.i;
                        args[line[2]]->type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.f - containerObject2->data.i;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.i - containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->data.f = containerObject1->data.f - containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = false;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator-").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in SUB" << endl;
                        exit(1);
                    }
                    break;
                default: break;
                }
                break;
            case Instruction::MULT:
                LOG("MULT");
                switch(line[1])
                {
                case BLOCK:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.i = containerObject1->data.i * containerObject2->data.i;
                        blocks[line[2]].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.i * containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f * containerObject2->data.i;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f * containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::STRING and containerObject2->type == Object::INT)
                    {
                        std::ostringstream builder;
                        for (int i = 0; i < containerObject2->data.i; i++) builder << *containerObject1->data.s;
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.s = new string(builder.str());
                        blocks[line[2]].type = Object::STRING;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator*").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in MULT" << endl;
                        exit(1);
                    }
                    break;
                case POINTER:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.i = containerObject1->data.i * containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f * containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.i * containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f * containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::STRING and containerObject2->type == Object::INT)
                    {
                        std::ostringstream builder;
                        for (int i = 0; i < containerObject2->data.i; i++) builder << *containerObject1->data.s;
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.s = new string(builder.str());
                        blocks[blocks[line[2]].data.i].type = Object::STRING;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        CHECK_TYPE(blocks[line[2]], INT);
                        nextFrame->returnAddr = blocks[line[2]].data.i;
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator*").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in MULT" << endl;
                        exit(1);
                    }
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->data.i = containerObject1->data.i * containerObject2->data.i;
                        args[line[2]]->type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.f * containerObject2->data.i;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.i * containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->data.f = containerObject1->data.f * containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::STRING and containerObject2->type == Object::INT)
                    {
                        std::ostringstream builder;
                        for (int i = 0; i < containerObject2->data.i; i++) builder << *containerObject1->data.s;
                        args[line[2]]->data.s = new string(builder.str());
                        args[line[2]]->type = Object::STRING;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = false;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator*").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in MULT" << endl;
                        exit(1);
                    }
                    break;
                default: break;
                }
                break;
            case Instruction::DIV:
                LOG("DIV");
                switch(line[1])
                {
                case BLOCK:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.i = containerObject1->data.i / containerObject2->data.i;
                        blocks[line[2]].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.i / containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f / containerObject2->data.i;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[line[2]].readyOverwrite();
                        blocks[line[2]].data.f = containerObject1->data.f / containerObject2->data.f;
                        blocks[line[2]].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator/").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in DIV" << endl;
                        exit(1);
                    }
                    break;
                case POINTER:
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.i = containerObject1->data.i / containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f / containerObject2->data.i;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.i / containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        blocks[blocks[line[2]].data.i].readyOverwrite();
                        blocks[blocks[line[2]].data.i].data.f = containerObject1->data.f / containerObject2->data.f;
                        blocks[blocks[line[2]].data.i].type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        CHECK_TYPE(blocks[line[2]], INT);
                        nextFrame->returnAddr = blocks[line[2]].data.i;
                        nextFrame->returnIntoBlock = true;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator/").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in DIV" << endl;
                        exit(1);
                    }
                    break;
                case ARGUMENT:
                    args[line[2]]->readyOverwrite();
                    if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->data.i = containerObject1->data.i / containerObject2->data.i;
                        args[line[2]]->type = Object::INT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::INT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.f / containerObject2->data.i;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::INT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->readyOverwrite();
                        args[line[2]]->data.f = containerObject1->data.i / containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::FLOAT and containerObject2->type == Object::FLOAT)
                    {
                        args[line[2]]->data.f = containerObject1->data.f / containerObject2->data.f;
                        args[line[2]]->type = Object::FLOAT;
                    }
                    else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                    {
                        nextFrame->returnAddr = line[2];
                        nextFrame->returnIntoBlock = false;
                        nextFrame->callingLine = programCounter+1;
                        *(*nextFrame)[0] << *containerObject1;
                        nextFrame->putArgument(*containerObject2);
                        callStack->push();
                        nextFrame = callStack->allocNextPush();
                        programCounter = containerObject1->data.o->getMethod("operator/").i;
                        continue;
                    }
                    else
                    {
                        std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in DIV" << endl;
                        exit(1);
                    }
                    break;
                default: break;
                }
                break;
            default: break;
            }
            break;
        }
        case Instruction::LT:
        case Instruction::LEQ:
        case Instruction::EQ:
        case Instruction::NEQ:
        {
            instr_size_c length1 = line[1];
            object_uptr containerObject1;
            switch(length1)
            {
            case BLOCK: containerObject1 = &blocks[line[2]]; length1 = 1; break;
            case POINTER: containerObject1 = &blocks[blocks[line[2]].data.i]; length1 = 1; break;
            case ARGUMENT: containerObject1 = args[line[2]].get(); length1 = 1; break;
            default: break;//containerObject1 = nullptr; break;
            }
            instr_size_c length2 = line[2 + length1];
            object_uptr containerObject2;
            switch(length2)
            {
            case BLOCK: containerObject2 = &blocks[line[3 + length1]]; break;
            case POINTER: containerObject2 = &blocks[blocks[line[3 + length1]].data.i]; break;
            case ARGUMENT: containerObject2 = args[line[3 + length1]].get(); break;
            default: break;//containerObject2 = nullptr; break;
            }
            switch(instr)
            {
            case Instruction::LT:
                LOG("LT");
                if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                {
                    compare = containerObject1->data.i < containerObject2->data.i;
                }
                else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                {
                    nextFrame->callingLine = programCounter+1;
                    *(*nextFrame)[0] << *containerObject1;
                    nextFrame->putArgument(*containerObject2);
                    callStack->push();
                    nextFrame = callStack->allocNextPush();
                    programCounter = containerObject1->data.o->getMethod("operator<").i;
                    continue;
                }
                else
                {
                    std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in LT" << endl;
                    exit(1);
                }
                break;
            case Instruction::LEQ:
                LOG("LEQ");
                if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                {
                    compare = containerObject1->data.i <= containerObject2->data.i;
                }
                else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                {
                    nextFrame->callingLine = programCounter+1;
                    *(*nextFrame)[0] << *containerObject1;
                    nextFrame->putArgument(*containerObject2);
                    callStack->push();
                    nextFrame = callStack->allocNextPush();
                    programCounter = containerObject1->data.o->getMethod("operator<=").i;
                    continue;
                }
                else
                {
                    std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in LEQ" << endl;
                    exit(1);
                }
                break;
            case Instruction::EQ:
                LOG("EQ");
                if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                {
                    compare = containerObject1->data.i == containerObject2->data.i;
                }
                else if (containerObject1->type == Object::BOOL and containerObject2->type == Object::BOOL)
                {
                    compare = containerObject1->data.b == containerObject2->data.b;
                }
                else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                {
                    nextFrame->callingLine = programCounter+1;
                    *(*nextFrame)[0] << *containerObject1;
                    nextFrame->putArgument(*containerObject2);
                    callStack->push();
                    nextFrame = callStack->allocNextPush();
                    programCounter = containerObject1->data.o->getMethod("operator==").i;
                    continue;
                }
                else
                {
                    std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in EQ" << endl;
                    exit(1);
                }
                break;
            case Instruction::NEQ:
                LOG("NEQ");
                if (containerObject1->type == Object::INT and containerObject2->type == Object::INT)
                {
                    compare = containerObject1->data.i != containerObject2->data.i;
                }
                else if (containerObject1->type == Object::BOOL and containerObject2->type == Object::BOOL)
                {
                    compare = containerObject1->data.b != containerObject2->data.b;
                }
                else if (containerObject1->type == Object::OBJECT and containerObject2->type == Object::OBJECT)
                {
                    nextFrame->callingLine = programCounter+1;
                    *(*nextFrame)[0] << *containerObject1;
                    nextFrame->putArgument(*containerObject2);
                    callStack->push();
                    nextFrame = callStack->allocNextPush();
                    programCounter = containerObject1->data.o->getMethod("operator!=").i;
                    continue;
                }
                else
                {
                    std::cerr << "UnsupportedTypeException: Cannot support " << containerObject1->typeToString() << " and " << containerObject2->typeToString() << " in NEQ" << endl;
                    exit(1);
                }
                break;
            default: break;
            }
            break;
        }
        default: break;
        }
        programCounter++;
        #ifdef DEBUG
        Sleep(SLEEP_TIME);
        #endif // DEBUG
    }
}

#undef args
