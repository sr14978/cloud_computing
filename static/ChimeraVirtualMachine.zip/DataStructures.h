#ifndef DATA_STRUCTURES_HEADER
#define DATA_STRUCTURES_HEADER
#include<vector>
#include<memory>
#ifdef _MSC_VER
#define not !
#define and &&
#define or ||
#endif

template <typename T> class IStack
{
    public:
        virtual void push(const T& value) = 0;
        // push() will push the stack pointer forward (only use after allocNextPush)
        virtual void push() = 0;
        virtual T pop() = 0;
        virtual const T& peek() const = 0;
        virtual void duplicate() = 0;
        virtual bool isEmpty() const = 0;
        virtual void clear() = 0;
        virtual int size() const = 0;
        // allocNextPush creates the next entry in the stack
        virtual T& allocNextPush() = 0;
        virtual IStack<T>* clone() = 0;
        virtual ~IStack() {};
};

template <typename T> class StackAllocator
{
    protected:
        bool deleter;
        inline T allocate() const { return T(); }
        inline void deallocate(const T& t) const { (void) t; }
};

template <typename T> class StackAllocator<T*>
{
    protected:
        bool deleter;
        inline T* allocate() { deleter = true; return new T(); }
        inline void deallocate(T* t) const { delete t; }
};

template <typename T> class ArrayStack: public IStack<T>, private StackAllocator<T>
{
    private:
        T* stack;
        int capacity;
        int pointer;
        int maxEver;

    public:
        explicit ArrayStack(int capacity) :
        maxEver(-1)
        {
            this->capacity = capacity;
            stack = new T[capacity];
            clear();
            StackAllocator<T>::deleter = false;
        }
        ~ArrayStack()
        {
            if (StackAllocator<T>::deleter)
            {
                for (int i = 0; i < capacity; i++)
                {
                    StackAllocator<T>::deallocate(stack[i]);
                }
            }
            delete [] stack;
        }

        void push(const T& value) { if (maxEver < pointer) ++maxEver; stack[pointer++] = value; }
        T pop() { return stack[--pointer]; }
        const T& peek() const { return stack[pointer-1]; }
        void duplicate() { stack[pointer] = stack[pointer-1]; pointer++; }
        bool isEmpty() const { return pointer == 0; }
        void clear() { pointer = 0; }
        int size() const { return pointer; }
        int getCapacity() { return capacity; }
        T& allocNextPush()
        {
            if (maxEver < pointer)
            {
                ++maxEver;
                return stack[pointer] = StackAllocator<T>::allocate();
            }
            else return stack[pointer];
        }
        void push() { ++pointer; }
        IStack<T>* clone() { return new ArrayStack<T>(capacity); }
};

template <typename T> class ResizableArrayStack: public IStack<T>, private StackAllocator<T>
{
    private:
        std::vector<T> stack;
        int capacity;
        unsigned int pointer;

    public:
        explicit ResizableArrayStack(int capacity) :
        pointer(0)
        {
            this->capacity = capacity;
            stack.reserve(capacity);
            StackAllocator<T>::deleter = false;
        }
        ~ResizableArrayStack()
        {
            if (StackAllocator<T>::deleter)
            {
                for (T t : stack)
                {
                    StackAllocator<T>::deallocate(t);
                }
            }
        }

        void push(const T& value)
        {
            if (pointer == stack.size()) stack.push_back(value);
            else stack[pointer] = value;
            ++pointer;
        }
        T pop() { return stack[--pointer]; }
        const T& peek() const { return stack[pointer-1]; }
        void duplicate()
        {
            if (pointer == stack.size()) stack.push_back(stack[pointer-1]);
            else stack[pointer] = stack[pointer-1];
            pointer++;
        }
        bool isEmpty() const { return pointer == 0; }
        void clear() { pointer = 0; stack.clear(); }
        int size() const { return pointer; }
        int getCapacity() { return capacity; }
        T& allocNextPush()
        {
            if (pointer == stack.size())
            {
                stack.push_back(StackAllocator<T>::allocate());
            }
            return stack[pointer];
        }
        void push() { ++pointer; }
        IStack<T>* clone() { return new ResizableArrayStack<T>(capacity); }
};

template <typename T> class LinkedStack: public IStack<T>, private StackAllocator<T>
{
    private:
        template <typename U> struct Node;
        std::unique_ptr<Node<T>> head;
        int stackSize;
        T nextPush;
        bool usedPush;

    public:
        explicit LinkedStack() : head(nullptr), stackSize(0), usedPush(true) { StackAllocator<T>::deleter = false; }
        ~LinkedStack() { clear(); if (StackAllocator<T>::deleter) StackAllocator<T>::deallocate(nextPush); }

        void push(const T& value)
        {
            head = std::unique_ptr<Node<T>>(new Node<T>(head, value));
            ++stackSize;
        }
        T pop()
        {
            T value = head->data;
            head = std::move(head->next);
            --stackSize;
            if (StackAllocator<T>::deleter) StackAllocator<T>::deallocate(nextPush);
            nextPush = value;
            return value;
        }
        const T& peek() const { return head->data; }
        void duplicate()
        {
            head = std::unique_ptr<Node<T>>(new Node<T>(head, head->data));
            ++stackSize;
        }
        bool isEmpty() const { return stackSize == 0; }
        void clear()
        {
            if (StackAllocator<T>::deleter) while (not isEmpty()) pop();
            else
            {
                head.reset();
                head = nullptr;
            }
        }
        int size() const { return stackSize; }
        T& allocNextPush()
        {
            if (usedPush)
            {
                nextPush = StackAllocator<T>::allocate();
                usedPush = false;
            }
            return nextPush;
        }
        void push()
        {
            head = std::unique_ptr<Node<T>>(new Node<T>(head, nextPush));
            ++stackSize;
            usedPush = true;
        }
        IStack<T>* clone() { return new LinkedStack<T>(); }

    private:
        template <typename U> struct Node
        {
            std::unique_ptr<Node<U>> next;
            T data;
            Node(std::unique_ptr<Node<U>>& next, T data) { this->next = std::move(next); this->data = data; }
        };
};
#endif // DATA_STRUCTURES_HEADER
