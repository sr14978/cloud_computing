#include <cstdio>
#include "ChimeraVirtualMachine.h"

//std::ofstream logFile("debug-log.txt");

string path = "../../Tests/InstructionTests/";
const string files [] = {"variableassignmenttests.cass", "arithmetictests.cass", "comparisontests.cass", "functiontests.cass",
                         "logictests.cass", "jumptests.cass", "stringtests.cass", "memorytests.cass", "objecttests.cass",
                         "overloadingtests.cass", "Listtests.cass", "Maptests.cass", "ChimeraUtilstests.cass",
                         "StringUtilstests.cass", "TypeUtilstests.cass", "Mathtests.cass", "BitwiseOperatorUtilstests.cass",
                         "Stacktests.cass", "Filetests.cass", "Tabletests.cass", "ScopeObjecttests.cass", "RegexUtilstests.cass"};

// Command line arg variables
bool verbose = false;
#define VERBOSE(msg) {if (verbose) cout << msg;}

void parseArgs(int argc, char** argv);
void runUnitTests();
void runCallbackTest();
bool test();
void assembleAndRun(string fileName);
void compileAndRun(string fileName, string dirPath);
bool process(std::ifstream& file, string filename);
void run(string path, std::ostream& out, bool verbose);
void inline replaceAll(string& str, const string& from, const string& to);
void executeDevCode();

int main(int argc, char** argv)
{
    // Parse command line arguments
    for (int i = 1; i < argc; i++)
    {
        if (strcmp(argv[i], "-t") == 0)
        {
            // Next argument is test directory
            VERBOSE("Running compliance against: " << argv[i+1] << endl);
            path = argv[++i];
            runUnitTests();
        }
        else if (strcmp(argv[i], "--auto-test") == 0) runUnitTests();
        else if (strcmp(argv[i], "-v") == 0) verbose = true;
        else if (strcmp(argv[i], "-a") == 0)
        {
            // We should assemble the next argument, and this is what we will execute
            assembleAndRun(argv[++i]);
        }
        else if (strcmp(argv[i], "--devtest") == 0) executeDevCode();
        else if (argv[i][0] == '-')
        {
            cout << "Unknown argument parameter: " << argv[i] << endl;
            return 1;
        }
        else run(argv[i], cout, verbose);
    }
    //logFile.close();
    return 0;
}

void executeDevCode()
{
    assembleAndRun("Tests/matrix");
}

void assembleAndRun(string fileName)
{
    string assemblyFileName = fileName + ".cass";
    string byteCodeFileName = fileName + ".stdc";
    system(("java -jar ChimeraAssembler1.1.jar " + string(verbose ? "-v" : "") + " \"" + assemblyFileName + "\"").c_str());
    run(byteCodeFileName, cout, verbose);
    std::remove(byteCodeFileName.c_str());
}

void compileAndRun(string fileName, string dirPath)
{
    string sourceFileName = dirPath + fileName + ".chi";
    string byteCodeFileName = dirPath + fileName + ".stdc";
    system(("java -jar ChimeraCompiler1.1.jar " + string(verbose ? "" : "-s") + " -a=\"-glm\" \"" + sourceFileName + "\"").c_str());
    run(byteCodeFileName, cout, verbose);
    std::remove(byteCodeFileName.c_str());
}

void runUnitTests()
{
    if (test())
    {
        VERBOSE("Implementation complies with Chimera Standard v1" << endl);
    }
    else cout << "Implementation failed standardisation tests" << endl;
}

bool test()
{
    bool all = true;
    std::stringstream allFiles;
    for (string testFile : files)
    {
        allFiles << " \"" << path << testFile << "\"";
    }
    system(("java -jar ChimeraAssembler1.1.jar " + allFiles.str()).c_str());
    for (string testFile : files)
    {
        std::ifstream file(path + testFile);
        if (file.is_open())
        {
            VERBOSE("Testing " << testFile << endl);
            if (not process(file, path + testFile))
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
                cout << "Test: " << testFile << " failed" << endl << endl;
                all = false;
            }
            else VERBOSE("Test: " << testFile << " succeeded" << endl << endl);
            file.close();
        }
        std::remove((path + testFile.substr(0, testFile.size()-5) + ".stdc").c_str());
    }
    return all;
}

bool process(std::ifstream& file, string filename)
{
    string expectedOutput;
    string line;
    while (std::getline(file, line) and line.compare(0, 1, ";"))
    {
        if (not line.compare("# Output")) continue;
        expectedOutput += line + "\n";
    }
    std::stringstream redirect;
    run(filename.substr(0, filename.size()-5) + ".stdc", redirect, false);
    ChimeraObject::objectId = 0;
    string actualOutput = redirect.str();
    if (not expectedOutput.compare(actualOutput))
    {
        return true;
    }
    replaceAll(expectedOutput, "\n", "\\n");
    replaceAll(expectedOutput, "\r", "\\r");
    replaceAll(actualOutput, "\n", "\\n");
    replaceAll(actualOutput, "\r", "\\r");
    cout << "Expected:\n" << expectedOutput << endl;
    cout << "Actual:\n" << actualOutput << endl;
    return false;
}

void runCallbackTest()
{
    byte** programMemory;
    byte* lineSizes;
    addr_c memorySize = ChimeraVirtualMachine::DEFAULT_MEMORY_SIZE;
    IStack<Frame*>* callStack = new LinkedStack<Frame*>();
    system("java -jar ChimeraAssembler.jar \"F:\\Documents\\Programming\\Java\\Civ5ModdedMultiplayer\\Chimeras\\callbacktest.cass\"");
    counter_c programSize = readChimeraStandardBinary("F:\\Documents\\Programming\\Java\\Civ5ModdedMultiplayer\\Chimeras\\callbacktest.stdc"
                                                      , programMemory, lineSizes, memorySize, callStack, false);
    ChimeraVirtualMachine vm(cout, programMemory, programSize, lineSizes, memorySize, callStack);
    //vm.interpret(false);
    // program has paused, run a callback
    clock_t startTime = clock();
    for (int i = 0; i < 100; i++)
    {
        Object returnVal = vm.callback(6, true, Object::make(10), Object::make(new string("Hello world")));
        //returnVal->print();
    }
    cout << "Program terminated in " << clock() - startTime << "ms" << endl;
    //vm.interpret(false);
}

void run(string path, std::ostream& out, bool verbose)
{
    byte** programMemory;
    byte* lineSizes;
    addr_c memorySize = ChimeraVirtualMachine::DEFAULT_MEMORY_SIZE;
    IStack<Frame*>* callStack = new LinkedStack<Frame*>();
    counter_c programSize = readChimeraStandardBinary(path.c_str(), programMemory, lineSizes, memorySize, callStack, verbose);
    ChimeraVirtualMachine(out, programMemory, programSize, lineSizes, memorySize, callStack).interpret(not verbose);
}

void inline replaceAll(string& str, const string& from, const string& to)
 {
    if (from.empty()) return;
    size_t startPosition = 0;
    while ((startPosition = str.find(from, startPosition)) != string::npos)
    {
        str.replace(startPosition, from.length(), to);
        startPosition += to.length(); // In case 'to' contains 'from', like replacing 'x' with 'yx'
    }
}
